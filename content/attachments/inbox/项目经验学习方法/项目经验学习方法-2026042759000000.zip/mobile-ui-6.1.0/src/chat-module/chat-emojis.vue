<template>
  <view class="chat-emojis">
    <swiper
      class="chat-emojis-swiper"
      indicator-dots
      indicator-color="#dddcdd"
      indicator-active-color="#87919c"
    >
      <swiper-item v-for="(item, index) in emojiSwiperList" :key="index" class="emoji-list">
        <view
          v-for="emojiId in item"
          :key="emojiId"
          :style="{backgroundImage: `url(${getEmojiPath(emojiId)})`}"
          class="item-emoji"
          @click="handleClickEmoji(emojiId)"
        />
        <view class="item-emoji delete-icon" @click="handleBackMessage" />
      </swiper-item>
    </swiper>
  </view>
</template>

<script>
import emojiMixin from './emojiMixin'
export default {
  name: 'chat-emojis',
  mixins: [emojiMixin],
  data() {
    return {
      emojiSwiperList: []
    }
  },
  mounted() {
    this.sliceEmojis()
  },
  methods: {
    /**
     * 将emoji按20个每组分割
     */
    sliceEmojis() {
      const emojis = this.emojis
      const array = []
      for (let i = 0; i < emojis.length; i += 20) {
        array.push(emojis.slice(i, i + 20))
      }
      this.emojiSwiperList = array
    },
    /***
     * 点击Emoji
     * @param emojiId
     */
    handleClickEmoji(emojiId) {
      this.$emit('click-emoji', emojiId)
    },
    /**
     * 删除消息
     */
    handleBackMessage() {
      this.$emit('back-message')
    }
  }
}
</script>

<style lang="scss" scoped>
.chat-emojis {
  width: 100%;
  height: calc(460rpx - 68rpx);
}
.chat-emojis-swiper {
  width: 100%;
  height: 390rpx;
  padding-top: 30rpx;
  box-sizing: border-box;
}
.emoji-list {
  padding: 0 12rpx;
  height: 300rpx;
  box-sizing: border-box;
  clear: both;
  .item-emoji {
    float: left;
    width: calc((100% - 24rpx) / 7);
    height: 100rpx;
    background-size: 55rpx 55rpx;
    background-repeat: no-repeat;
    background-position: center center;
    &.delete-icon {
      background-size: 60rpx 55rpx;
      background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAADX0lEQVRoQ+2ZXWvTYBTH/yebDt9Q/AruQlBEURRFcSiKoiisXdu57ksIE0WRDkVxsBvvVMSLpG36pMkck4midvsQ+hm8EgRhOF2PJEu1L2mSJ03tCutdyXn5/845ec5DS+jzD/W5fmwC9LqDmx3oqw6oRWOESHkOYLgHwpeIsDyRTkzX55YZIdJ06xPAIz0QX0v5OZtJHIwEoOnlaYDu91C8kzqbSTQUPVQHCsI6V63yx16LjwSQy+UGh/cfskfnTF8C5EvmA2bc2wjipTugFqwLpPD7jSJeCkAIsXW1OlABcKovAbSS+QiMOxtJfOgOqAXrEin8NpJ4RhmEZChfGVs3YOAxKoTY5o7OiVAi6oy4yunJG0lDK5oiEIJRzo4nUmqhPEYKlcLmCgTQSuYTMG6FDVizc8UL9zv5QrjiAbBtrxbKqbAQvgBq0bxChDey4kEksunRdJOfN0ST+JqPVrJKYE4F5W4LIITY+as6UGHgWFAQz+dhIDoU7/sSq3p5lkA3I4n/52RkM4nmKq53wr7HjDvPnLH5W3ndeTYWNq9nB9SieY0I82GDBNh5Qrg+HYn37IAQYrc7OkdiArDDeEE0hNckK19zbumAqpenCDQTo/haqLYQUcV7dqDvAV7Nze3Z8nOtAtDhGLvw/0bIFp3XjesM5XUcAAQYE60nkWfovG4KljiBfI/RvG7NMrijY5RAxkRmtGUZOUvKPkZblx3yuiUY3Nkxagd/OT+/a2jlt319PhqlE654exs3HpX1G7bNssvrVikshO9VQtONq4CyIA0gs2HDbGwfAcGXOd2aAXhKEoKhIJVNJcp/N6zf3aYJQhNmElXYGznwR4ZAgGcLC9t3/FitgHA8KkSoi5kLISPe9yVuvJ8YlwFlURLANmcQGWFulU5sIgF2XuDAyrfdxO1Earr1GODbESC66hI4QrXsTxcXh/Z+X7FH6WRXFUkGDw1gx9V04yKgvJPM0VVzKYB1COshwHe7qkoiuDRArlIZ3Pf1W4UIpyXydM1UGsDpQtE4D1I+dE2VROBIAO4oTQPcnz+vOwViJlW37FE6K1GwmE35SzaTPFAfNPQCsZ3cv5he9OYvJlpiXlueHB/LRQaIuZyxhJPqQCwZYw6yCRBzQaXDbXZAumQxO/wB1rd0QKOEGAgAAAAASUVORK5CYII=');
    }
  }
}
</style>
