<template>
  <view class="chat-item" :class="{'is-self': message['is_self']}">
    <image :src="userFace" class="chat-face" />
    <view class="chat-content" :class="message.type" @tap="handleClickMessage">
      <!-- 文字[emoji]消息 -->
      <view v-if="message.type === 'TEXT'">
        <rich-text :nodes="textMessage" class="rich-text"></rich-text>
      </view>
      <!-- 商品消息 -->
      <view v-else-if="message.type === 'GOODS'" class="goods-message">
        <image :src="message['goods_image']" class="goods-image" />
        <view class="goods-info">
          <text class="goods-name">{{ message['goods_name'] }}</text>
          <!-- <text class="goods-price">{{MixinUnitOfCurrency }}{{ message['goods_price'] }}</text> -->
		  <custom-price class="goods-price" :price="message['goods_price']" :size="28" textColor="#252525"></custom-price>
        </view>
      </view>
      <!-- 订单消息 -->
      <view v-else-if="message.type === 'ORDER'" class="order-message">
        <view class="order-info">
          <view>订单号: {{ message['order_sn'] }}</view>
          <view>下单时间: {{ formatDate(message['create_time'], 'MM-dd hh:mm') }}</view>
        </view>
        <view class="order-goods">
          <view v-for="goods in message.goods_list" :key="goods.goods_id" class="goods-message">
            <image :src="goods['goods_image']" class="goods-image" />
            <view class="goods-info">
              <text class="goods-name">{{goods['goods_name']}}</text>
            </view>
          </view>
        </view>
        <view class="order-footer">
          <!-- <text class="order-price">订单金额合计:{{ message['order_price'] | unitPrice }}</text> -->
          <custom-price class="order-price" :price="message['order_price']" :size="28" textColor="#252525"></custom-price>
          <text class="order-status">{{ message['order_status'] | unixOrderStatus }}</text>
        </view>

      </view>
      <!-- 图片消息 -->
      <view v-else-if="message.type === 'IMAGES'" class="image-message">
        <image :src="message.url" class="image" alt="" />
      </view>
      <!-- 视频消息 -->
      <view v-else-if="message.type === 'VIDEO'" class="video-message">
        <!-- 非H5端不直接显示video组件，使用canvas绘制封面代替，避免层级问题 -->
        <video :src="message.url" :id="`video-${message['msg_id']}`" class="video" @fullscreenchange="handlePauseVideo" />
        <!-- #ifndef H5 -->
        <canvas :canvas-id="`canvas-${message['msg_id']}`" type="2d" style="width:300rpx;height:300rpx;"></canvas>
        <!-- #endif -->
      </view>
    </view>
  </view>
</template>

<script>
import Cache, { Keys } from '@/utils/cache'

export default {
  name: 'chat-item',
  props: {
    message: {
      type: Object,
      required: true
    },
    sender: {
      type: Object,
      required: false
    },
    receiver: {
      type: [Object, String],
      required: false
    },
    avatar: {
      type: String
    },
    getEmojiPath: Function,
    formatDate: Function
  },
  data() {
    return {
      videoCtx: '',
      defaultFace: require('./icon-noface.jpg'),
      platformFace: require('./platform.jpg')
    }
  },
  computed: {
    user() {
      return this.message['is_self'] ? this.sender : this.receiver
    },
    textMessage() {
      const { text } = this.message
      if (!text) return
      return this.message.text.replace(/alt="(e\d+)"/g, this.getEmojiSrc)
    },
    userFace() {
      if (this.receiver && !Number(this.receiver.target_id) && !this.message['is_self']) {
        return this.platformFace
      } else if (!this.message['is_self']) {
        if (this.avatar && this.avatar !== 'undefined') {
          return this.avatar
        }
        return this.defaultFace
      }
      const user = Cache.getItem(Keys.user)
      return user.face || this.defaultFace
    },
  },
  mounted() {
    const { type, url } = this.message
    if (type !== 'VIDEO') return
    // #ifndef H5
    const ctx = uni['createCanvasContext'](`canvas-${this.message['msg_id']}`, this)
    this.drawRoundedRect(ctx, 0, 0, uni.upx2px(300), uni.upx2px(300), uni.upx2px(20))
    ctx.clip()
    ctx.drawImage(url, 0, 0, uni.upx2px(300), uni.upx2px(300))
    ctx.draw()
    this.videoCtx = uni['createVideoContext'](`video-${this.message['msg_id']}`, this)
    // #endif
  },
  methods: {
    /**
     * 获取emoji完整src
     * @param _
     * @param emojiId
     * @returns {string}
     */
    getEmojiSrc(_, emojiId) {
      return `alt="${emojiId}" src="${this.getEmojiPath(emojiId)}"`
    },
    /**
     * 点击了消息
     */
    handleClickMessage() {
      // #ifndef H5
      if (this.message.type === 'VIDEO') {
        this.videoCtx['requestFullScreen']({
          direction: 0
        })
      }
      // #endif
      this.$emit('handle-click', this.message)
    },
    /**
     * 暂停视频
     */
    handlePauseVideo() {
      this.videoCtx['pause']()
    },
    /**
     * Canvas绘制圆角
     * @param ctx
     * @param x
     * @param y
     * @param width
     * @param height
     * @param radius
     */
    drawRoundedRect(ctx, x, y, width, height, radius) {
      ctx.moveTo(x + radius, y)
      ctx.lineTo(x + width - radius, y)
      ctx.arc(x + width - radius, y + radius, radius, 1.5 * Math.PI, 2 * Math.PI)
      ctx.lineTo(x + width, y + height - radius)
      ctx.arc(x + width - radius, y + height - radius, radius, 0, 0.5 * Math.PI)
      ctx.lineTo(x + radius, y + height)
      ctx.arc(x + radius, y + height - radius, radius, 0.5 * Math.PI, Math.PI)
      ctx.lineTo(x, y + radius)
      ctx.arc(x + radius, y + radius, radius, Math.PI, 1.5 * Math.PI)
    }
  }
}
</script>

<style lang="scss" scoped>
.chat-item {
  display: flex;
  padding: 0 20rpx;
  box-sizing: border-box;
  width: 100%;
  margin-top: 30rpx;
  &.is-self {
    flex-direction: row-reverse;
    .chat-content {
      margin-left: 0;
      margin-right: 20rpx;
    }
  }
  .chat-face {
    width: 80rpx;
    height: 80rpx;
    border-radius: 20rpx;
    flex-shrink: 0;
  }
  .chat-content {
    margin-left: 20rpx;
    min-height: 80rpx;
    background-color: #ffffff;
    border-radius: 20rpx;
    max-width: 484rpx;
    padding: 20rpx;
    box-sizing: border-box;
    &.IMAGES,
    &.VIDEO {
      padding: 0;
      background-color: transparent;
    }

    ::v-deep .emoji-img {
      display: inline-block;
      width: 30rpx;
      height: 30rpx;
      font-size: 0;
      margin: 0;
      vertical-align: bottom;
    }
  }
  .rich-text {
    word-break: break-all;
  }
  .goods-message {
    display: flex;
    width: 444rpx;
    .goods-image {
      width: 160rpx;
      height: 160rpx;
      flex-shrink: 0;
    }
    .goods-info {
      display: flex;
      flex-direction: column;
      justify-content: center;
      width: 265rpx;
      margin-left: 20rpx;
    }
    .goods-name {
      width: 100%;
      height: 54rpx;
      font-size: 28rpx;
      line-height: 28rpx;
      display: -webkit-box;
      overflow: hidden;
      text-overflow: ellipsis;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
    .goods-price {
      font-size: 28rpx;
      margin-top: 56rpx;
      color: #252525;
    }
  }
  .order-message {
    display: flex;
    flex-direction: column;
    width: 444rpx;
    background-color: #ffffff;
    overflow: hidden;
    box-sizing: border-box;
    .order-info {
      width: 100%;
      font-size: 26rpx;
      color: #656665;
    }
    .order-footer {
      margin-top: 10px;
      font-size: 26rpx;
      color: #333;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .order-goods {
      padding: 14rpx;
      margin-top: 20rpx;
      background-color: #f4f4f4;
      box-sizing: border-box;
      border-radius: 8rpx;
      .goods-image {
        width: 140rpx;
        height: 140rpx;
      }
      .goods-info {
        display: flex;
        flex-direction: column;
        justify-content: center;
        width: 265rpx;
        height: 140rpx;
        margin-left: 20rpx;
      }
      .goods-name {
        width: 100%;
        height: 54rpx;
        font-size: 28rpx;
        line-height: 28rpx;
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .order-price-status {
        display: flex;
        justify-content: space-between;
        margin-top: 32rpx;
      }
      .order-price,
      .order-status {
        font-size: 28rpx;
        color: #252525;
      }
      .order-status {
        color: #9d9d9c;
      }
    }
  }
  .image-message {
    overflow: hidden;
    border-radius: 20rpx;
    .image {
      display: block;
      max-width: 300rpx;
      max-height: 300rpx;
      min-width: 100rpx;
      min-height: 100rpx;
      border-radius: 20rpx;
    }
  }
  .video-message {
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    overflow: hidden;
    border-radius: 20rpx;
    /* #ifndef H5 */
    background: rgba(0,0,0,.8);
    /* #endif */
    .video {
      display: block;
      height: 300rpx;
      border-radius: 20rpx;
      overflow: hidden;
      background-color: rgba(0,0,0,.5);
    }
    /* #ifndef H5 */
    .video {
      display: none;
    }
    &::after {
      content: '';
      position: absolute;
      width: 100rpx;
      height: 100rpx;
      background-size: 100% 100%;
      background-repeat: no-repeat;
      background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAQ/0lEQVR4Xu1dBbAsRxU9pygkOCEElwQnQHCN4AR3grsED4UFhwDBEkhwTSAECe7BEggaJMHd3d2hqEMd6IV9+3ZaZqZn5r3dWzX1/q/t6b59+8xtu0KsaaUlwJXu/brzWANgxUGwBsAaACsugRXv/loDrAGw4hJY8e6vNcAaACsuAQCSzgzgrAB2BvALAD8n+etVkMy21wCSdgCwK4DzLzxnDwPuQT/ZksH+VwCDAfFTAN9eeL5D8q9bHSTbEgCSrgTg6gBuBODKFQfpEwDeAeCDJE+o2E61qrcFACTtCOB6AK4ZBv581STWXPH3DAQAxwI4huRvRuChuMktC4C5QffA+zEIpkIe/GNmz5TBsOUAIMkq/W4Abj6xQW8Cn8HwZgCHk/SUMSnaMgCQdC0AdwVwu0lJsIyZ1wA4guQHyl6rV3ryAJB0DQAPBHCTemIYvOa3AXgOyeMGb3mhwckCQNIZADwawMMqCukvAP4A4I/h8b9PF57Tzv27FgvPBPAUkr+v1UCq3kkCQNK+AB4F4JKpDmT+7hX6ZwB8LTxf9V+SBkCSJF0MwG4AZn8vD6CvncYXABxE8ugkIxUKTAoAks4F4MAw13fp7vcBfBjA8f5L8ptdKlv2rqQLAtgLwN7h73k7tnEEgMeR/FHHeopenwwAJN3C6hDAhYt6sLHwWwAcPcbXFLSWNdfNOvD/dU97JN/UoY6iV0cHgKRThIF/aBHn/y/8YwCvDgN/Uss6entN0mUAGAi3B3DOlhUfHIDwj5bvZ782KgCCsA4FsGc2x/8v6K/l8LCt+mWL96u+IuksYSrzmUUbrfYRAPuTrArq0QAg6WoAXgXA834JWSAvDwM/+cuYcBnl84u7A7B2KCGvB+5I8kMlL5WUHQUAYfDfC8DqP5d8I2dtcSjJ6qoxl6nccmGq299fNQDfROaS+3rdWiAYHABh8H1pUkKzgffqfkuTJO8WZkAo6cvVa4BgUABIujiALxb02vO858H3FLyzJYpK2idotJL1wSVIfqnPDg4GAEleEZfscX1c+mCS3+2zw1OqS9IuAJ5deMx9LpLe+fRCgwBA0hnDSZytcnLoGSQfkVNwO5SR9HQAD8/siy2TLkfyd5nlo8WqA0DSycN16A0zGX4iySdklt02xSQ9HkBuv9/p63CS/+wqgCEA4K3eHTIZXcnBn8mmEARHkbxjplwbi1UFgCSr8adlMnlbkq/LLLtti0m6DYDXZnbwAJKePlpTNQBIssq3wWQOVdni5DQ8xTKFW+UbkfSU0IqqACCsbr11u1AGVzcl6RX/muYkIMkGMG/NEMo3AOzTdrdUCwC2gcu5Fbs/yedndHIli0i6H4DnZXT+LSRtI1lMvQNA0j0AvDSDk0NItr0BzKh+exSR5JvBh2T05p4kX5ZRbkORXgEg6WwAPho8cGK8+Cj42iTtfbOmiAQk2Wvp/cHfISYrnw/sQfJnJQLtGwA+s39QggEfYFyH5KdLGF3lspJsgvY+AD5Qi9FhJH3PkE29ASCYbRupKdqP5ItThda/b5SApHsDeFGGXKxZs83O+wRAzsLv1SRzD4Uy+rpaRSQdFSyNYh0vWhD2AgBJewCwBUuM7CGzJ8mvrNaw9dfbYJ1sOafc4Cxnr8WS1BcArNLvlWjtoSQPSXK0LhCVgCTvCLwziNFLSHrKSFJnAEjyffbnAJwq0tqxJO3ataYeJCDJc7w9oZvobwAuRdL2FFHqAwA25bYTR4w6HVemOrFqv2ces9vZxJ5V9QAg6TQAbKES85J5B8kbpxip8bsku3f57ryaUWUNvnPqlPT2EACjqbi9oS5O8s+x+jppAEl3sXXu1L7+4GFkV6urBN5sSewVtK9QJ2dCnjPgi2UytcBdSb6iJgDeBeD6kQYG//qD9a0vl2xzt0h2EfMR9LY4h8jQAu8meYMqAAinU59KoPcOJO21MxhJspHEkYkGfWBlINg0fcuSJHsfWbPF6AqxU9fWU4CkZyRct73vv+DQ4VEy+JoXli+tDITkanmKKAlhcqzVYucCzyTZaG/YBQBe/NlluolGOfWTlJqWFvl1PECfTxgIW9HhJHU6+GWSNsdfSq0AEAw+vjM19W9+JPmm0W5npXRiAEGuOVZp/VXKZ04DuzYZjLQFwG0BON5NEznihRsdPFRaBwDM+vJGAM+aYkCnZcIO04A/RkdUaaLbkVwK7LYASF37JlefVT6HbhpgniXNTQtF9+u1+hWrN2Paa7wmbgsAhztzNM4mcpCDg0YSRtspYBm79kry2mDSZmuSfBLrE9kmOoHk0oipbQHgLyRGlyH52W0AgFkXHM3L04IXmJMjSZcGEI0jQHLpWBcDQJIDN30+IoUfkyz1+e9NqD2sAWK8OCCFNcLkrrQl2e8yFpFkd5IOSLWB2gAgddDyRpK36m1ECyuqDABz4wXubNuYFWWssAutikt6A4BbRl6+E0l7aXUGgGPbxax5n0zysa160cNLAwBgxqWvwK0NUidxPfQqXYWkJwF4TKTkwSQ3xVxsowF8fHqdSEODH//O8zIgAGbN2nnDQMiywEkPZbsSGecB7yN53T40gLdFzq7RRJetHdgoJqIRADBjx1tjA6EkBkK70V7yVgi45cOsJnIWFJvtt58Cwk3b3xNcnyY3AmdvvZ+raEQAmIsfBBA8p0bfEsA/NYDo3T+AUy4edxdNAZLOBCB2uvcXkjYSGY1GBsCs345Sam1go43BSJIBYCA00Y4kfzv/YykAzh1Q3tTAz0iWRMDqXTgTAcCsX08g+cTeO9lQoSRHUtuk5ueKn4fkD7sA4KIAYnvgb5LM8QiuJpOJAcD9fB1J351UJ0n2FHYM4ya6GEkHyv4flWqAywGIuXSdRPKy1XsaaWCCADC3u5C0jV5VkuRFYCwY5eVJOmp6awD4mjUW4+9DJJ2tazSaKAAeQDLHzbuT3DL6vikQR6kGsJNizAzsRJLWEqNRhhDG4O1KJD9Zu2FJ/rpjGniTeVgpAJww4cuRjnyDZEngw95lMkEAfJJk7Oa0NxlIsmlbbA222+I9RikAzgMgFq71JyTbhkjvRRATA4D9Ee5CcpAQt5IcQPIcEUGel6TPKlqvAZxj91eRBv5I8vS9jGTLSiYEAFsW3Y2k8xENQpJmOY+a2ttpMSdyqQaw/180RHvTvfMgEujPIqgLu7aDsO3A4JdEklJ2GjuQtN9gOw3gtyQZ0Xa5aqKLknRyplFoRA1gzfgsx/5dFPIQgpB0EQAb9vgL7f6JpDOibaAiDRAA8LE5l6tlfbsZyZzwZlXkMhIAXhi++m9V6VRGpZJuCsA5k5ro4ySv2gcA3Nn9Ig09iuRTM3iuUmRgADhAo9V9af6D3vsu6ZFOPxep+EUk79MHADz4BkETHUnyzr33MLPCgQBgkzgPfMoFLZPr7sUkvRLAnSI13YfkphhDbaYAe9x6Gmiiz5O8VPcutauhMgDsReT4/h78SeUrkmQLpd0jUrsqyY/3oQG8AExtbc5J8ifthrDbWxUBYI9iD7wvXCZFkrz3TyWROB3JP3UGgCuQZBUYS+vqTFeDb4MCb336BbjKd4eBP3ZSoz7HjCRHXttk8DlX5Askl2qH4ikgCNmOEveNCORwkk6TNjj1qAFsQu0tXTTAwuAdXNKgJKfRc37CJnoBSccd3kRtAZBC3HdJ7jqGcHoAgC1mZvN8ysRqjC5ualOSfQOdf6iJGjVyWwCkLoXMyPVJHjO0hDoCwPECPM+PdpBVKi9J1wvTVOzVTZdAs8KtABCmgRTqnkvygaUd6lq+JQAMVKv7nFC3XVns9X1JNkB9QKTSqDbuAgAHh3KQqCb6FsmYeVKvgphVVhBe3a84yIUH3i5fW5IkOULIBSLMv4KkU9cupS4AcHColLPk4NOAJC+GvCiKkd27ZvN8aks7WWBkqv8bkPROpl8AhGnA1kG2Emqi7JClfUlZ0iUA+IjWtgvLyEkV/NVPzsGzVAaSUiF6P03yCrF6W2uAAAD7mjlYVIwcqDHmsVLa72R5SXZdW4wA5ouSF2/1yGCzzkuy6dcGA88lgnk4SftyNlJXADhCqOfRmDPI4FoggNP+CRaSbRRfRdIZNbYNZXz93sI6UmjUGrkTAIKgrVJThz6Da4FtM9JLOpL59b+cpPM3RakPAOwF4PhEO0eQjJ1Upfhc/z4nAUnetTSu7EPRvUnaRa0uAIIWcGjWVEDoW5N0EIM1dZCAJAffeH2iireTdN7BJHXWAAEAtwBgI8gY2VZur2U3Ukku1wX+I4EQ/dxftWMCxeiWJN+UI7ZeABCY813z0khUc4xkxbDPYXwVy0jKyc3wCZKzKOlJMfUJgJwDGDNUlNUq2YMVKVCQle3uJSebvQEgaIGczGEOZ+a8gbauWVOGBCTZH8N5A2OOn66pKGOYX+gbAD51cqyckyf69TKS98zo+7rIf+d+31KmtnT/DJlDUyH8N8i0VwAELXAggJwoYfcj+YL1CMclIMmGNzmRSp9E8nGl8qwBAJ8KOrddaqVqXtdbw8iIZW75XIN3WM4VWGzA0jsAghZwirj3AHDi4xRt8llPvbAKv0tKxWKYicEJuPcpSRc7L78qAAggcBJph07LoZ23SzKnnM6mykg6C4BfpMqF3/cneVhm2U3FqgEggCBn8TJj6vRDetK2FVjt9yTZf89evjnUeTFdGwB2FfdUkDogmnX2wlO0u88ZiT7KSHJwh9z8RQ7Zb9WfC5alLFYFQNAC3hracminTCGt5JqgYM63GO2JbEufoi3fMvlXB0AAwa0BOJFjLo3mWJLLYJ/lMhw7Fpvbl2TqQiiLxUEAEEDgbNabnBMjXI4adTxLej0UyojyvdjKfn0mvhwMAAEEjwDwtAK5+frYq9xR/AwL+CwuGvz5vEsqya1wAMmnFzcWeWFQAAQQ2FegZNtiFy3Huo/5vvUpk+p1heymzrkQ869c5ONBJHsPQj04AAIIcowaFgXgheShbQ88qo9qRgPhRm9/L+Ayis8XqXZiOgoAOoDAr9oG0fvf6oEXCwepsbikK4bLnNSFzrI6qg2+GxsNAHMg8IC2CS3npNS2NZyy2/Y1g+2ekzyXkvf396htRjcqAAII7FhiS5drl0oolLc94lEkUyZpLasvf02SkzfZgzrLLm9JC/ZRdO7FWGDucsaWvDE6AGY8Scq9Rm7quINW+KzhaJKpvMa9CG++Ekl2h983PLFQLam2W13rpipt+n0yAAjawIsjZ7/KuUpu6pNj99g1zEelx9fMXxTy9OwdjrpvCGCHtgMRrnQfO3RyykkBIIDAlyFOhXpAB2HOv+okTo7ZewIA+/1/jWQqns6mpsMN3W4AHBvBdxu+ru0rQabPRmwwO7ij6uQAMDclWMAGQtu1QQw/FrSjavpM3f/2gst/Z1FQDUI/Dojlvx54X9H2TZ7rPfAG6Cg0WQDMAeEhAB6cSIs6ivA6NGoNZA9lZyAdlSYPgDAt7By2UzY9HzUnUcfRcog5u3V5+5pr8NGxyfjrWwIAc9rA9ob2iTMQuiwUqwp1SeW22ZsNfLHdXk1mtxQA5gURomM4QJKfWIiUmvKL1e3A0Y49dMwYwbJyO71lAdAABgeGGDNlja157MAx6UGfl922AMACGOwX552Dj2H3zP0SOpSzCfxxHvhlsXg71DvIq9sOAAtg8DZuDwDnn3t8Yuf/lxza+HDJEUZ8wui/s+ejW93beVsDIPYJhTzI3l0sPl6db3gW8+0O8mkO1MjKAmAg+U6+mTUAJj9EdRlcA6CufCdf+xoAkx+iugyuAVBXvpOvfQ2AyQ9RXQbXAKgr38nX/m+EDIjMKOn8/wAAAABJRU5ErkJggg==');
    }
    /* #endif */
  }
}
</style>
