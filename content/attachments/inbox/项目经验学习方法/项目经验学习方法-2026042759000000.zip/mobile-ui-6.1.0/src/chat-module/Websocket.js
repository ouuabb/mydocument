var socketOpen = false
var tt
var lockReconnect = false

var websocket = {
  init: function(url, token) {
    var websocketUrl = url.replace('http://', 'ws://')
    websocketUrl = websocketUrl.replace('https://', 'wss://')
    uni.connectSocket({
        url: websocketUrl,
        protocols: [token]
    })

    uni.onSocketMessage(function(e) {
      heartCheck.start()
      if (e.data === '') {
        console.log('收到pong')
        return
      }
      uni.$emit('websocket-msg', e.data)
    })

    uni.onSocketClose(function() {
      console.log('连接关闭，开始重连')
      socketOpen = false
      reconnect(url)
    })

    uni.onSocketOpen(function(res) {
      console.log('连接成功，开始心跳')
      socketOpen = true
      heartCheck.start()
    })

    uni.onSocketError(function(res) {
      console.log('连接出错，开始重连')
      socketOpen = false
      reconnect(url, token)
    })
  },

  isOpen: function() {
      return socketOpen
  }
}

function reconnect(url, token) {
  if (lockReconnect) {
    return
  }
  lockReconnect = true
  tt && clearTimeout(tt)
  tt = setTimeout(function() {
    console.log('执行断线重连...')
    websocket.init(url, token)
    lockReconnect = false
  }, 4000)
}

/**
 * 心跳检测
 * @type {{timeoutObj: null, start: heartCheck.start, timeout: number}}
 */
var heartCheck = {
  timeout: 1000 * 20,
  timeoutObj: null,
  start: function() {
    this.timeoutObj && clearTimeout(this.timeoutObj)
    this.timeoutObj = setTimeout(function() {
      uni.sendSocketMessage({
        data: ''
      })
    }, this.timeout)
  }
}

export default websocket
