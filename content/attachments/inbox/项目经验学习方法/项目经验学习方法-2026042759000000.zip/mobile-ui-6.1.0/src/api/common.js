/**
 * 公共API
 */
import request,{Method} from '../utils/request'
import * as Config from '../config/config'
import Cache, { Keys } from '@/utils/cache.js';

const api = Config.api

/**
 * 获取验证方式
 */
export function getValidator() {
  return request.ajax({
    url: `${api.base}/base/validator`,
    method: Method.GET
  })
}


/**
 * 获取图片验证码URL
 * @param uuid
 * @param type
 * @returns {string}
 */
export function getValidateCodeUrl(uuid, type) {
  if (!uuid || !type) return ''
  let url = `${api.base}/base/captchas/${uuid}/${type}`
  url += `?r=${new Date().getTime()}`
  
  return url
}

/**
 * 获取站点设置
 */
export function getSiteData() {
  return request.ajax({
    url: `${api.base}/base/site-show`,
    method: Method.GET
  })
}
/**
 * 记录商品浏览量【用于统计】
 */
export function recordView(url) {
  return request.ajax({
    url: '/buyer/view',
    method: Method.GET,
    needToken: !!Cache.getItem(Keys.accessToken),
    params:{
      url,
      uuid: Cache.getItem(Keys.uuid)
    }
  })
}

/**
 * 获取base64图片
 * @param url
 */
export function getBase64(url) {
  return request.ajax({
    url: `${api.base}/base/net-image/base64`,
    method: Method.GET,
    params: {
      url
    }
  })
}

/**
 * 获取语言包
 * @param lang
 * @returns {*}
 */
export function getLang(lang) {
  return request.ajax({
    url: `${api.base}/base/lang`,
    method: Method.GET,
    params: {
      lang,
      type: 'mobile'
    }
  })
}

/**
 * 获取多语言支持列表
 * @returns {*}
 */
export function getLangCodes() {
  return request.ajax({
    url: `${api.base}/base/lang/codes`,
    method: Method.GET
  })
}
/**
 * 获取Stripe密钥
 * @returns {*}
 */
export function getStripeKey() {
  return request.ajax({
    url: `${api.base}/base/stripe/secret`,
    method: Method.GET
  })
}