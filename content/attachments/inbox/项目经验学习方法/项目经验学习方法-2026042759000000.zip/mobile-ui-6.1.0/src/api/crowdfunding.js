/**
 * Created by Andste on 2018/7/15.
 * 促销相关API
 */

import request,{Method} from '../utils/request'

/**
 * 分页列表
 * @param params
 */
export function getList(params) {
  return request.ajax({
    url: '/buyer/promotions/crowdfunding',
    method: 'get',
    params
  })
}

/**
 * 查询详情
 * @param id
 */
export function getDetail(id) {
  return request.ajax({
    url: `/buyer/promotions/crowdfunding/${id}`,
    method: 'get'
  })
}

/**
 * 立即购买
 * @param crowdfunding_id
 * @param num
 */
export function buy(crowdfunding_id, num) {
  return request.ajax({
    url: `/buyer/crowdfunding/buy`,
    method: 'get',
    params: { crowdfunding_id, num },
    needToken: true
  })
}

/**
 * 获取购物车
 */
export function getCart() {
  return request.ajax({
    url: `/buyer/crowdfunding/cart`,
    method: 'get',
    needToken: true
  })
}

/**
 * 提交订单
 */
export function createTrade() {
  return request.ajax({
    url: `/buyer/crowdfunding/trade`,
    method: 'post',
    needToken: true,
    params: { client: 'PC' }
  })
}