/**
 * 会员相关API
 */
import request,{Method} from '@/utils/request'

/**
 * 获取商品是否被收藏
 * @param good_id
 */
export function getGoodsIsCollect(good_id) {
  return request.ajax({
    url: `/buyer/members/collection/goods/${good_id}`,
    method: Method.GET,
    needToken: true
  })
}

/**
 * 获取店铺是否被收藏
 * @param shop_id
 */
export function getShopIsCollect(shop_id) {
  return request.ajax({
    url: `/buyer/members/collection/shop/${shop_id}`,
    method: Method.GET,
    needToken: true
  })
}


/**
 * 获取优惠券列表
 * @param params
 */
export function getCoupons(params) {
  return request.ajax({
    url: '/buyer/members/coupon',
    method: Method.GET,
    needToken: true,
    loading:true,
    params
  })
}

/**
 * 领取优惠券
 * @param coupon_id
 */
export function receiveCoupons(coupon_id) {
  return request.ajax({
    url: `/buyer/members/coupon/${coupon_id}/receive`,
    method: Method.POST,
    needToken: true
  })
}

/**
 * 获取当前会员积分
 * @returns {*}
 */

export function getPoints() {
  return request.ajax({
    url: '/buyer/members/points/current',
    method: 'get',
    needToken: true
  })
}

/**
 * 获取积分明细数据
 * @param params
 * @returns {AxiosPromise}
 */
export function getPointsData(params) {
  return request.ajax({
    url: '/buyer/members/points',
    method: 'get',
    needToken: true,
    loading:true,
    params
  })
}

/**
 * 获取我的评论列表
 * @param params
 * @returns {AxiosPromise}
 */
export function getComments(params) {
  return request.ajax({
    url: '/buyer/members/comments',
    method: 'get',
    needToken: true,
    params
  })
}

/**
 * 订单评论
 * @param params
 */
export function commentsOrder(params) {
  return request.ajax({
    url: '/buyer/members/comments',
    method: Method.POST,
    needToken: true,
    isJson: true,
    data: params
  })
}


/**
 * 获取统计数量
 * 包括但不限于【订单数量、收藏的商品数量、收藏的店铺数量】
 */
export function getStatisticsNum() {
  return request.ajax({
    url: '/buyer/members/statistics',
    method: Method.GET,
    loading: false,
    needToken: true
  })
}

/**
 * 获取当前登录的用户信息
 * @returns {AxiosPromise}
 */
export function getUserInfo() {
  return request.ajax({
    url: '/buyer/members',
    needToken: true,
    method: 'get'
  })
}

/**
 * 保存用户信息
 * @param params
 * @returns {AxiosPromise}
 */
export function saveUserInfo(params) {
  return request.ajax({
    url: '/buyer/members',
    method: 'put',
    needToken: true,
    loading:true,
    params
  })
}

/**
 * 登出 -- 执行解绑操作
 * @returns {AxiosPromise}
 */
export function logout() {
  return request.ajax({
    url: '/buyer/members/logout',
    method: 'post',
    needToken: true
  })
}

/**
 * 获取发票列表 参数 发票类型默认普通发票 存在电子发票- ELECTRO
 * @param type
 */
export function getReceipts(type) {
  return request.ajax({
    url: `/buyer/members/receipt/${type}`,
    method: 'get',
    needToken: true
  })
}

/**
 * 添加发票
 * @param params
 */
export function addReceipt(params) {
  return request.ajax({
    url: '/buyer/members/receipt',
    method: 'post',
    needToken: true,
    params
  })
}

/**
 * 修改发票
 * @param id
 * @param params
 */
export function editReceipt(id, params) {
  return request.ajax({
    url: `/buyer/members/receipt/${id}`,
    method: 'put',
    needToken: true,
    params
  })
}

/**
 * 删除发票
 * @param id
 */
export function deleteReceipt(id) {
  return request.ajax({
    url: `/buyer/members/receipt/${id}`,
    method: 'delete',
    needToken: true
  })
}

/**
 * 设置发票为默认
 * @param id
 */
export function setDefaultReceipt(id) {
  return request.ajax({
    url: `/buyer/members/receipt/${id}/default`,
    method: 'put',
    needToken: true
  })
}

/**
 * 获取店铺是否开启某种发票
 * @param params
 */
export function queryMembersReceipt(params) {
  return request.ajax({
    url: `/buyer/shops/check/receipt`,
    method: 'post',
    needToken: true,
    isJson: true,
    data: params
  })
}

/**
 * 获取会员开票历史记录信息列表
 * @param params
 */
export function queryReceiptInfoList(params) {
  return request.ajax({
    url: '/buyer/members/receipt/history',
    method: 'get',
    needToken: true,
    loading:true,
    params
  })
}

/**
 * 获取会员开票历史记录信息详情
 * @param params
 */
export function queryReceiptInfoDetail(history_id) {
  return request.ajax({
    url: `/buyer/members/receipt/history/${history_id}`,
    method: 'get',
    needToken: true
  })
}

/**
 * 获取商家可用优惠券列表
 * @param seller_ids
 */
export function getShopsCoupons(seller_ids) {
  return request.ajax({
    url: `/buyer/members/coupon/${seller_ids}`,
    method: 'get',
    needToken: true
  })
}


/**
 * 获取商品评论列表
 * @param goods_id
 * @param params
 */
export function getGoodsComments(goods_id, params) {
  return request.ajax({
    url: `/buyer/members/comments/goods/${goods_id}`,
    method: Method.GET,
    needToken: true,
    params
  })
}

/**
 * 获取我的足迹列表
 */
export function queryHistoryList(params) {
  return request.ajax({
    url: '/buyer/members/history/list',
    method: 'get',
    needToken: true,
    loading:true,
    params
  })
}

/**
 * 清空所有会员足迹
 */
export function clearHistoryList() {
  return request.ajax({
    url: '/buyer/members/history',
    method: 'delete',
    needToken: true
  })
}

/**
 * 根据id删除会员足迹
 * @param id
 */
export function deleteHistoryListId(id) {
  return request.ajax({
    url: `/buyer/members/history/${id}`,
    method: 'delete',
    needToken: true
  })
}
/**
 * 获取待追评列表
 * @param goods_id
 * @param params
 *
 */
export function getWaitAppendComments(params) {
  return request.ajax({
    url: '/buyer/members/comments/list',
    method: Method.GET,
    needToken: true,
    loading: true,
    params
  })
}

/**
 * 获取商品初评信息
 * @param goods_id
 * @param params
 */
export function getGoodsFirstComments(params) {
  return request.ajax({
    url: '/buyer/members/comments/detail',
    method:'get',
    needToken: true,
    params
  })
}

/**
 * 追加评论
 * @param params
 */
export function appendCommentsOrder(params) {
  return request.ajax({
    url: '/buyer/members/comments/additional',
    method: 'post',
    needToken: true,
    isJson: true,//判断传入的是否是json数据
    data: params
  })
}

/**
 * 获取评价详情
 * @param goods_id
 * @param params
 */
export function getCommentsDetail(comment_id) {
  return request.ajax({
    url: `/buyer/members/comments/${comment_id}`,
    method: 'get',
    needToken: true
  })
}


/**
 * 获取增票资质信息详情
 * @param params
 */
export function queryInvoiceInfo() {
  return request.ajax({
    url: '/buyer/members/zpzz/detail',
    method:'get',
    needToken: true
  })
}

/**
 * 会员增票资质申请
 * @param params
 */
export function ticketInformationApply(params) {
  return request.ajax({
    url: '/buyer/members/zpzz',
    method: 'post',
    params,
    needToken: true
  })
}
/**
 * 会员修改增票资质申请
 * @param params
 */
export function changeTicketInformation(params) {
  return request.ajax({
    url: `/buyer/members/zpzz/${params.id}`,
    method: 'put',
    params,
    needToken: true
  })
}

/**
 * 删除会员增票资质信息
 */
export function deleteInvoiceInfo(id) {
  return request.ajax({
    url: `/buyer/members/zpzz/${id}`,
    method: 'delete',
    needToken: true
  })
}

/**
 * 增加增票资质收票人地址
 * @param params
 */
export function ticketAdressApply(params) {
  return request.ajax({
    url: '/buyer/members/receipt/address',
    method: 'post',
    params,
    needToken: true
  })
}

/**
 * 获取增票资质收票人地址信息
 * @param params
 */
export function queryTicketAdress() {
  return request.ajax({
    url: '/buyer/members/receipt/address/detail',
    method: 'get',
    needToken: true
  })
}

/**
 * 修改增票资质收票人地址
 * @param params
 */
export function changeTicketAdress(params, id) {
  return request.ajax({
    url: `/buyer/members/receipt/address/${id}`,
    method: 'put',
    params,
    needToken: true
  })
}

/**
 * 获取我的咨询列表
 * @param params
 * @returns {AxiosPromise}
 */
export function getConsultations(params) {
  return request.ajax({
    url: '/buyer/members/asks',
    method: 'get',
    needToken: true,
    loading:true,
    params
  })
}

/**
 * 商品咨询
 * @param goods_id
 * @param ask_content
 */
export function consultating(goods_id, ask_content,anonymous) {
  return request.ajax({
    url: '/buyer/members/asks',
    method: Method.POST,
    needToken: true,
    params: { goods_id, ask_content,anonymous }
  })
}

/**
 * 获取商品咨询列表
 * @param goods_id
 * @param params
 */
export function getGoodsConsultations(goods_id, params) {
  return request.ajax({
    url: `/buyer/members/asks/goods/${goods_id}`,
    method: Method.GET,
    needToken: true,
    params
  })
}

/**
 * 获取资询详情
 * @param ask_id
 */
export function getAskDetail(ask_id){
  return request.ajax({
    url:`/buyer/members/asks/detail/${ask_id}`,
    method:'get'
  })
}

/**
 * 获取商品资询回复信息
 * @param ask_id
 * @param params
 */
export function getGoodsAskReplys(ask_id,params){
  return request.ajax({
    url:`/buyer/members/asks/reply/list/${ask_id}`,
    method:'get',
    params
  })
}

/**
 * 删除我的提问
 * @param ask_id
 * @returns {AxiosPromise}
 */
export function deleteAsk(ask_id) {
  return request.ajax({
    url: `/buyer/members/asks/${ask_id}`,
    method: 'delete',
    needToken: true
  })
}

/**
 * 获取我的回答
 * @param params
 * returns {AxiosPromise}
 */
export function getAnswers(params){
  return request.ajax({
    url:'/buyer/members/asks/reply/list/member',
    method:'get',
    needToken:true,
    loading: true,
    params
  })
}

/**
 * 删除我的回答
 * @param id
 * @returns {AxiosPromise}
 */
export function deleteAnswers(id) {
  return request.ajax({
    url: `/buyer/members/asks/reply/${id}`,
    method: 'delete',
    needToken: true
  })
}

/**
 * 回复商品咨询
 * @param ask_id
 * @param reply_content
 * @param anonymous
 */
export function replyAsk(ask_id, params) {
  return request.ajax({
    url: `/buyer/members/asks/reply/${ask_id}`,
    method: 'post',
    needToken: true,
    params
  })
}

/**
 * 获取会员等级信息
 * @returns {Promise<*>}
 */
export function getMemberLevels() {
  return request.ajax({
    url: `/buyer/members/get-level`,
    method: Method.GET,
    needToken: true,
    loading: false
  })
}
