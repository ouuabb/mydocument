/**
 * Created by Andste on 2018/7/15.
 * 促销相关API
 */

import request,{Method} from '../utils/request'

/**
 * 获取商品促销活动列表
 * @param goods_id
 */
export function getGoodsPromotions(sku_id) {
  return request.ajax({
    url: `/buyer/promotions/${sku_id}`,
    method: 'get',
    loading:true
  })
}

/**
 * 获取全部优惠券
 * @param goods_id
 */
export function getOwnCoupons(goods_id) {
  return request.ajax({
    url: '/buyer/promotions/coupons/goods-use',
    method: 'get',
    params: { goods_id }
  })
}

/**
 * 获取店铺优惠券
 * @param seller_id
 */
export function getShopCoupons(seller_id) {
  return request.ajax({
    url: '/buyer/promotions/coupons/shop-all',
    method: Method.GET,
    params: { seller_id }
  })
}


/**
 * 获取限时抢购时间线
 */
export function getSeckillTimeLine() {
  return request.ajax({
    url: '/buyer/promotions/seckill/time-line',
    method: Method.GET,
    loading: true
  })
}

/**
 * 获取限时抢购商品
 * @param params
 */
export function getSeckillTimeGoods(params) {
  return request.ajax({
    url: '/buyer/promotions/seckill/goods-list',
    method: Method.GET,
    loading:true,
    params
  })
}

/**
 * 获取全部优惠券
 * @param params
 */
export function getAllCoupons(params) {
  return request.ajax({
    url: '/buyer/promotions/coupons/all',
    method: Method.GET,
    params
  })
}


/** 获取拼团列表 */
export function getAssembleList(params) {
  return request.ajax({
    url: '/buyer/pintuan/goods/skus/uniapp',
    method: 'get',
    params
  })
}

/**
 * 获取拼团商品sku的详细
 * @param sku_id
 */
export function getAssembleDetail(sku_id) {
  return request.ajax({
    url: `/buyer/pintuan/goods/skus/${sku_id}`,
    method: 'get'
  })
}

/**
 * 获取此商品sku_id待成团的订单
 * @param goods_id
 */
export function getAssembleOrderList(goods_id, params) {
  return request.ajax({
    url: `/buyer/pintuan/goods/${goods_id}/orders`,
    method: 'get',
    params
  })
}

/***
 * 获取当前商品所有参与拼团的sku规格列表
 * @param goods_id
 */
export function getAssembleSkuList(goods_id, pintuan_id) {
  return request.ajax({
    url: `/buyer/pintuan/goods/${goods_id}/skus`,
    method: 'get',
    params: { pintuan_id }
  })
}

/**
 * 获取店铺优惠券
 * @param {*} params
 * @returns
 */
export function getShopAllCoupons(params) {
  return request.ajax({
    url: '/buyer/promotions/coupons/shop-all',
    method: 'get',
    params
  })
}
/**
 * 获取新人优惠券
 * @returns
 */
export function getNewcomerCoupon() {
    return request.ajax({
      url: '/buyer/promotions/coupons/newcomer-coupon',
      method: 'get'
    })
}
/**
 * 获取签到活动
 * @param {*} params
 * @returns
 */
export function getSignActivity() {
  return request.ajax({
    url: '/buyer/promotions/sign/activity',
    method: Method.GET,
		needToken: true
  })
}

/**
 * 签到
 * @returns
 */
export function signActivity() {
  return request.ajax({
    url: '/buyer/promotions/sign/activity',
    method: Method.POST,
		needToken: true
  })
}