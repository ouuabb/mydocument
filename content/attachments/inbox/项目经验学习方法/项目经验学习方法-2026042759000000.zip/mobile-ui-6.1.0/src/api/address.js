/**
 * 收货地址相关API
 */

import request,{Method} from '../utils/request'
import { api } from '@/config/config'

/**
 * 获取收货地址列表
 * @returns {AxiosPromise}
 */
export function getAddressList() {
  return request.ajax({
    url: '/buyer/members/addresses',
    method: Method.GET,
    loading: true,
    needToken: true
  })
}

/**
 * 添加收货地址
 * @param params 地址参数
 * @returns {AxiosPromise}
 */
export function addAddress(params) {
  return request.ajax({
    url: '/buyer/members/address',
    method: Method.POST,
    loading: true,
    needToken: true,
    params
  })
}

/**
 * 编辑地址
 * @param id 地址ID
 * @param params 地址参数
 * @returns {AxiosPromise}
 */
export function editAddress(id, params) {
  return request.ajax({
    url: `/buyer/members/address/${id}`,
    method: Method.PUT,
    loading: true,
    needToken: true,
    params
  })
}

/**
 * 删除收货地址
 * @param id
 */
export function deleteAddress(id) {
  return request.ajax({
    url: `/buyer/members/address/${id}`,
    method: Method.DELETE,
    needToken: true
  })
}

/**
 * 设置默认地址
 * @param id
 */
export function setDefaultAddress(id) {
  return request.ajax({
    url: `/buyer/members/address/${id}/default`,
    method: Method.PUT,
    needToken: true
  })
}

/**
 * 获取某个地址详情
 * @param id
 */
export function getAddressDetail(id) {
  return request.ajax({
    url: `/buyer/members/address/${id}`,
    method: Method.GET,
    loading: true,
    needToken: true
  })
}

/**
 * 获取地区列表
 * @param id
 */
export function getAreas(id) {
  const _api = `${api.base}/base/regions/@id/children`
  return request.ajax({
    url: _api.replace('@id', id),
    method: Method.GET
  })
}

/**
 * 获取国家列表
 */
export function getCountries() {
  return request.ajax({
    url:`${api.base}/base/countries`,
    method: Method.GET
  })
}

/**
 * 获取国家下的省
 */
export function getRegions(country_code) {
  return request.ajax({
    url:`${api.base}/base/countries/${country_code}/states`,
    method: Method.GET
  })
}

/**
 * 查询省下的市
 */
export function getCities(state_id) {
  return request.ajax({
    url:`${api.base}/base/countries/${state_id}/cities`,
    method: Method.GET
  })
}