/**
 * 订单相关API
 */

import request, { Method } from '../utils/request'

/**
 * 获取订单列表
 * @param params
 */
export function getOrderList(params) {
  return request.ajax({
    url: '/buyer/trade/orders',
    method: 'get',
    needToken: true,
    loading: true,
    params
  })
}

/**
 * 获取订单详情
 * @param order_sn 订单编号
 */
export function getOrderDetail(order_sn) {
  return request.ajax({
    url: `/buyer/trade/orders/${order_sn}`,
    method: 'get',
    needToken: true,
    loading: true
  })
}

/**
 * 取消订单
 * @param order_sn 订单编号
 * @param reason   取消原因
 */
export function cancelOrder(order_sn, reason) {
  return request.ajax({
    url: `/buyer/trade/orders/${order_sn}/cancel`,
    method: 'post',
    needToken: true,
    params: { reason }
  })
}

/**
 * 确认收货
 * @param order_sn 订单编号
 */
export function confirmReceipt(order_sn) {
  return request.ajax({
    url: `/buyer/trade/orders/${order_sn}/rog`,
    method: 'post',
    needToken: true
  })
}

/**
 * 获取订单状态数量
 */
export function getOrderStatusNum() {
  return request.ajax({
    url: '/buyer/trade/orders/status-num',
    method: 'get',
    needToken: true
  })
}

/**
 * 根据交易单号查询订单列表
 * @param trade_sn
 */
export function getOrderListByTradeSn(trade_sn) {
  return request.ajax({
    url: `/buyer/trade/orders/${trade_sn}/list`,
    method: 'get',
    needToken: true
  })
}

/**
 * 获取某个拼团订单的详情
 * @param order_sn
 */
export function getAssembleOrderDetail(order_sn) {
  return request.ajax({
    url: `/buyer/pintuan/orders/${order_sn}`,
    method: 'get',
    needToken: true
  })
}

/**
 * 拼团猜你喜欢
 * @param order_sn
 */
export function getAssembleGuest(order_sn, num = 6) {
  return request.ajax({
    url: `/buyer/pintuan/orders/${order_sn}/guest`,
    method: 'get',
    needToken: true,
    params: { num }
  })
}

/**
 * 获取虚拟订单核销信息
 * @param order_sn
 */
export function getOrderVirtual(order_sn) {
  return request.ajax({
    url: `/buyer/trade/orders/${order_sn}/virtual`,
    method: 'get',
    needToken: true
  })
}


/**
 * 虚拟商品核销
 * @param params
 */
export function virtualGoodsVerification(params) {
  return request.ajax({
    url: '/buyer/trade/orders/use/virtual',
    method: 'put',
    needToken: true,
    params
  })
}

/**
 * 根据模板类型获取微信小程序订阅通知模板信息
 * @param {*} types
 * @returns
 */
export function getWechatSubscribeNoticeList(types) {
  return request.ajax({
    url: `/systems/wechat-subscribe-notice/list/${types}`,
    method: 'get',
    needToken: true
  })
}

/**
 * 获取小程序订阅通知消息模板ID信息
 * @param data_type
 * @param sn
 * @returns
 */
export function getWechatListTmpId(data_type, sn) {
  return request.ajax({
    url: `/systems/wechat-subscribe-notice/list-tmp-id`,
    method: 'get',
    needToken: true,
    params: { data_type, sn }
  })
}