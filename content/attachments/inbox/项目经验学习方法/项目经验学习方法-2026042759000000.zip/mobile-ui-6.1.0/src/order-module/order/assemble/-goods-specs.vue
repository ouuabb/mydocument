<template>
	<view class="specs">
        <!-- 商品规格弹出层 -->
        <u-popup v-model="specsShow" mode="bottom" length="70%" closeable close-icon-size="20" border-radius="20" class="goods-popup-header">
            <view class="specs-headr u-p-20">
                <u-image width="200rpx" height="200rpx" :src="selectedSpecImg.thumbnail || selectedSku.thumbnail"></u-image>
                <view class="price-header">
                    <view class="price-text">
                      拼团价：
					  <!-- {{ sales_price | unitPrice }} -->
					  <custom-price class="value" :price="sales_price" fontWeight="bold" :size="45"></custom-price>
                    </view>
                  <!-- <text class="old-price">{{ selectedSku.price | unitPrice }}</text> -->
                    <custom-price class="old-price" :price="selectedSku.price" textColor="#333"></custom-price>
                    <view class="u-m-t-10">
                        <text class="specs-name">已选</text>
                        <text class="specs-value">{{selectedSku ? selectedSpecVals.join('-') : '未选规格'}} {{buyNum}}个</text>
                    </view>
                </view>
            </view>
            <scroll-view scroll-y="true" class="specs-body" >
                <view class="specs-list u-p-20" v-for="(spec, specIndex) in specList" :key="specIndex">
                    <view>
                        <text class="bold-text">{{spec.spec_name}}</text>
                    </view>
                    <view class="u-p-t-30">
                        <u-button
                            v-for="(spec_val, index) in spec.valueList"
                            :key="index"
                            size="mini"
                            class="u-m-r-30"
                            shape="circle"
                            :plain="true"
                            hover-class="none"
                            :type="spec_val.selected ? 'error' : 'default'"
                            @click="handleClickSpec(spec, specIndex, spec_val)"
                            throttle-time="10"
                            :custom-style="specStyle"
                        >
                            {{spec_val.spec_value}}
                        </u-button>
                    </view>
                </view>
                <view class="u-padding-20 u-flex u-row-between">
                    <text class="bold-text">数量</text>
                    <u-number-box v-model="buyNum" :min="1" :max="selectedSku.enable_quantity" @change="handleBuyNum"></u-number-box>
                </view>
            </scroll-view>
            <view class="specs-footer u-flex">
                <view class="buy btn u-line-1 u-text-center u-flex-1" @click="$emit('to-assemble-buy-now')">立即参团</view>
            </view>
        </u-popup>
	</view>
</template>

<script>
    import * as API_Goods from '@/api/goods.js'
    import * as API_Promotions from '@/api/promotions.js'
    import { Foundation } from '@/app-utils/index.js'
	export default {
		data() {
			return {
                specsShow: false,
                // 购买数量
                buyNum: 1,
                // skuMap
                skuMap: new Map(),
                // 规格列表
                specList: [],
                // 被选中规格
                selectedSpec: [],
                selectedSpecVals: [],
                // 规格组合列表
                skusCombination: [],
                // 被选中sku
                selectedSku: '',
                // 被选中的规格图片【如果有】
                selectedSpecImg: '',
                // 没有选中sku，初始化为false
                unselectedSku: false,
                specStyle: {
                    fontSize: '28rpx',
                    padding: '20rpx 40rpx',
                    fontWeight: 600,
                }
			};
		},
        props: {
            goodsId: {
                type: String,
                default: ''
            },
            skuId: {
                type: String,
                default: ''
            },
            pintuanId: {
                type: String,
                default: ''
            },
            show: {
                type: Boolean,
                default: false
            },
            sales_price: {
                type: String,
                default: ''
            }
        },
        watch: {
            show(newVal) {
                this.specsShow = newVal
            },
            specsShow(newVal) {
                this.specsShow = newVal
                this.$emit('close', newVal)
            },
            selectedSku(newVal) {
                this.$emit('sku-changed', newVal)
            },
            buyNum(newVal) {
                this.$emit('num-changed', newVal)
            },
            pintuanId() {
                this.goodsId && this.pintuanId && this.GET_AssembleSkuList()
            }
        },
        methods: {
            GET_AssembleSkuList() {
                API_Promotions.getAssembleSkuList(this.goodsId, this.pintuanId).then(response => {
                    const specList = []
                    response.forEach((sku, skuIndex) => {
                        const { spec_list } = sku
                        const spec_value_ids = []
                        let _combination = []
                        if (spec_list) {
                            spec_list.forEach((spec, specIndex) => {
                                const _specIndex = specList.findIndex(_spec => _spec['spec_id'] === spec.spec_id)
                                const _spec = {
                                    spec_id: spec.spec_group_sn,
                                    spec_name: spec.spec_group_name,
                                    spec_type: spec.spec_type
                                }
                                const _value = {
                                    spec_value: spec.spec_value_name,
                                    spec_value_id: spec.spec_value_sn,
                                    spec_value_index: skuIndex,
                                    spec_value_img: {
                                        original: spec.spec_value_image,
                                        thumbnail: spec.thumbnail
                                    }
                                }
                                _combination.push({..._value})
                                spec_value_ids.push(spec.spec_value_sn)
                                if(_specIndex === -1){
                                    specList.push({..._spec, valueList: [{..._value}]})
                                }else if(specList[_specIndex]['valueList'].findIndex(_value => _value['spec_value_id'] === spec['spec_value_id']) === -1) {
                                    specList[_specIndex]['valueList'].push({ ..._value })
                                }
                            })
                            this.skusCombination.push(_combination)
                            this.skuMap.set(spec_value_ids.join('-'), sku)
                        } else {
                            this.skuMap.set('no_spec', sku)
                        }
                    })
                    this.specList = specList
                    // 如果有sku信息，初始化已选规格
                    if (this.skuId) {
                      this.initSpec()
                    } else if(this.specList) {
                        //默认选中第一个sku
                        const _selectedSpecVals = [];
                        this.specList.forEach((spec, specIndex)=> {
                            if (Array.isArray(spec.valueList)) {
                                spec.valueList.forEach((val, specValIndex) => {
                                    if (specValIndex === 0) {
                                        val.selected = true
                                        this.selectedSpec[specIndex] = val.spec_value_id
                                        _selectedSpecVals.push(val.spec_value)
                                    }
                                })
                            }
                        })
                        this.$set(this, 'selectedSpecVals', _selectedSpecVals)
                        this.handleSelectedSku()
                    }
                    // 如果没有规格，把商品第一个可选sku给已选择sku
                    if (!specList.length) {
                      this.selectedSku = this.skuMap.get('no_spec')
                    }
                })
            },
            //初始化规格
            initSpec() {
                let selectedSpecs = ''
                if (this.skuId) {
                    this.skuMap.forEach((value, key) => {
                        if (value.sku_id === this.skuId) {
                            selectedSpecs = key.split('-')
                        }
                    })
                }
                const _selectedSpecVals = []
                this.specList.forEach((spec, specIndex)=> {
                    if (Array.isArray(spec.valueList)) {
                        spec.valueList.forEach((val, specValIndex) => {
                            if (selectedSpecs) {
                                const spec_value_id = val.spec_value_id
                                if (selectedSpecs.indexOf(String(spec_value_id)) !== -1) {
                                    val.selected = true
                                    this.selectedSpec[specIndex] = val.spec_value_id
                                    _selectedSpecVals.push(val.spec_value)
                                }
                            } else if (specValIndex === 0) {
                                val.selected = true
                                this.selectedSpec[specIndex] = val.spec_value_id
                                _selectedSpecVals.push(val.spec_value)
                            }
                        })
                    }
                })
                this.$set(this, 'selectedSpecVals', _selectedSpecVals)
                this.handleSelectedSku()
            },
            //选择规格
            handleClickSpec(spec, specIndex, spec_val) {
                if (spec.spec_type === 1 ) {
                    this.selectedSpecImg = JSON.parse(JSON.stringify(spec_val.spec_value_img))
                }
                if (spec_val.selected) return
                spec.valueList.map(item => {
                    item.selected = item.spec_value_id === spec_val.spec_value_id
                    return item
                })
                this.$set(this.specList, specIndex, spec)
                this.selectedSpec[specIndex] = spec_val.spec_value_id
                this.selectedSpecVals[specIndex] = spec_val.spec_value
                this.handleSelectedSku()
            },
            //根据已选规格选出对应的sku
            handleSelectedSku() {
                let sku
                if (this.selectedSpec.length) {
                    const spec_vals = []
                    this.selectedSpec.forEach(item => spec_vals.push(item))
                    sku = this.skuMap.get(spec_vals.join('-'))
                } else {
                     sku = this.skuMap.get('no_spec')
                }
                if (sku) {
                    this.selectedSku = sku
                    this.unselectedSku = false
                    this.goodsInfo = { ...this.goodsInfo, ...sku }
                    this.buyNum = sku.enable_quantity === 0 ? 0 : 1
                }
            },
            //购买数量
            handleBuyNum(e) {
                this.buyNum = e.value
            }
        }
	}
</script>

<style lang="scss" scoped>
    .specs{
        border-radius: 15rpx;
        margin-top: 23rpx;
        background-color: #FFFFFF;
        .specs-view {
            padding: 30rpx;
            display: flex;
            align-items: center;
            padding-bottom: 20rpx;
            .left-view {
                margin-right: 20rpx;
            }
            .bold-text {
                font-weight: bold;
            }
            .content-view {
                flex: 1;
            }
        }
        //规格选择器弹出框
        .goods-popup-header {
           .specs-headr {
               display: flex;
               flex-direction: row;
               background-color: #FFFFFF;
               height: 240rpx;
               width: 100%;
               .price-header {
                   margin-left: 30rpx;
                   margin-top: 80rpx;

                   .price-text {
                       font-size: 45rpx;
                       font-weight: bold;
                       color: #FF0000;
                       margin-top: 20rpx;
					   display: flex;
                   }
                   .old-price {
                   text-decoration: line-through;
                   }

                   .specs-name {
                       color: #909399;
                       margin-right: 10rpx;
                   }

                   .specs-value {
                       font-weight: 400;
                   }
               }
           }
           .specs-body {
               // height: calc(100vh - 750rpx);
               height: 570rpx;
               // #ifdef MP
               height: 500rpx;
               // #endif
               overflow-x: hidden;
           }
           .specs-footer {
               width: 100%;
               position: fixed;
               left: 0;
               bottom: 0;
               z-index: 999;
               color: #FFFFFF;
               border-top: 2rpx solid #f3f4f6;
               font-size: 28rpx;
               padding: 0rpx 20rpx;
               padding-bottom: 60rpx;
               padding-top: 10rpx;

               .btn {
                   line-height: 80rpx;
                   padding: 0 30rpx;
                   text-align: center;
               }
               .cart {
                   border-top-left-radius: 40rpx;
                   border-bottom-left-radius: 40rpx;
                   background: linear-gradient(to right, #FFCA1E 0%, #FF8B18 100%);
               }
               .buy {
                   border-radius: 40rpx;
                   background: linear-gradient(to right, #FD5632 0%, #EF0D25 100%);
               }
           }
        }
    }
</style>
