<template>
    <view>
        <view v-for="(item, index) in params.comments" :key="index" class="goods-item">
            <view class="u-flex">
                <u-image width="100rpx" height="100rpx" :src="item.goods_image"></u-image>
                <view class="cm-grade">
                    <view class="u-flex item-flower praise" :class="[item.grade === 'good' && 'active']" @click="handleComments('good', index)">
                        <text class="txt"></text>
                        <view>好评</view>
                    </view>
                    <view class="u-flex item-flower average" :class="[item.grade === 'neutral' && 'active']" @click="handleComments('neutral', index)" >
                        <text class="txt"></text>
                        <view>中评</view>
                    </view>
                    <view class="u-flex item-flower bad-review" :class="[item.grade === 'bad' && 'active']" @click="handleComments('bad', index)">
                        <text class="txt"></text>
                        <view>差评</view>
                    </view>
                </view>
            </view>
            <view class="context u-margin-top-20">
                <u-input v-model="item.content" type="textarea" height="150"
                    :placeholder="item.grade === 'good' ? '宝贝满足您的期待吗？说说它的优点和美中不足的地方吧' : '可以告诉我们您遇到了什么问题吗？'" />
            </view>
            <view class="comments-images">
                <u-upload ref="uUpload" :action="action" :header="header" :index="item.sku_id" max-count="5"></u-upload>
            </view>
        </view>
        <view class="goods-item">
            <view>
                <u-icon size="42" name="shop" custom-prefix="custom-icon"></u-icon>
                <text class="u-m-l-15">店铺评分</text>
            </view>
            <view class="u-flex u-margin-top-25 goods-title">
               <view class="goods-t">
                    <view>描述相符：</view>
                    <u-rate v-model="params.description_score" gutter="12" size="34" min-count="1"></u-rate>
                    <view class="u-m-l-10">{{ countGradeText(params.description_score) }}</view>
                </view>
                <view class="goods-t">
                    <view>服务态度：</view>
                    <u-rate v-model="params.service_score" gutter="12" size="34" min-count="1"></u-rate>
                    <view class="u-m-l-10">{{ countGradeText(params.service_score) }}</view>
                </view>
                <view class="goods-t">
                    <view>物流服务：</view>
                    <u-rate v-model="params.delivery_score" gutter="12" size="34" min-count="1"></u-rate>
                    <view class="u-m-l-10">{{ countGradeText(params.delivery_score) }}</view>
                </view>
            </view>
        </view>
        <view class="order-footer" >
            <u-button type="error" @click="handleSubmit">发表评论</u-button>
        </view>
    </view>
</template>

<script>
import { api } from '@/config/config.js'
import * as API_Member from '@/api/members.js'
import Cache,{Keys} from '@/utils/cache.js'
export default {
    data() {
        return {
            sku_list: [],
            order_sn: '',
            action: `${api.buyer}/buyer/uploaders`,
            header:  { Authorization: Cache.getItem(Keys.accessToken) },
            count: 5,
            grade: '',
            params: {
                order_sn: '',
                delivery_score: 5,
                description_score: 5,
                service_score: 5,
                comments: [],
            },
            isSubmitForm: true
        };
    },
    onLoad(options) {
        this.order_sn = options.order_sn;
        this.params.order_sn = options.order_sn;
        const _sku_list = JSON.parse(decodeURIComponent(options.sku_list));
        _sku_list.forEach(res => {
            let _sku = {
                content: '',
                grade: 'good',
                images: [],
                sku_id: res.sku_id,
                name: res.name,
                goods_image: res.goods_image,
                count: 5,
            }
            this.params.comments.push(_sku);
        })
    },
    methods: {
        countGradeText(val) {
            switch (val) {
                case 5: return '非常好'
                case 4: return '好'
                case 3: return '一般'
                case 2: return '差'
                case 1: return '非常差'
                default: return '非常差'
            }
        },
        // 评论
        handleComments(type, index) {
            this.params.comments[index].grade = type
        },
        handleSubmit(){
            this.params.comments.forEach(res => {
                this.$refs.uUpload.forEach((item => {
                    if(res.sku_id === item.index) {
                        res.images = []
                        item.lists.forEach(key => {
                            key.response && res.images.push(key.response.url)
                        })
                    }
                }))
            })
            const params = JSON.parse(JSON.stringify(this.params))
            const result = params.comments.some(key => (key.grade !== 'good' && !key.content))
            if(result) {
                this.$u.toast('请告诉我们您不满意的原因，我们愿尽最大的努力！');
                return
            }
            API_Member.commentsOrder(params).then(()=>{
                this.$u.toast('发布成功')
                uni.navigateBack()
                uni.$emit('back')
            }).catch(() => {
                this.$u.toast('发布失败')
            })
        }
    }
}
</script>

<style lang="scss">
.goods-item {
    background-color: #FFFFFF;
    margin: 15rpx;
    padding: 20rpx;
    border-radius: 10rpx;
}
.goods-title {
    color: #999;
    display: flex;
    margin-bottom: 15rpx;
    flex-direction: column;
}
.u-flex {
    -webkit-box-align: unset;
    -webkit-align-items: unset;
    align-items: unset;
}
.goods-t {
    display: flex;
    margin-bottom: 20rpx;
    flex-direction: row;
}
.cm-grade {
    display: flex;
    width: calc(100% - 170rpx);
    margin-left: 60rpx;
    .item-flower {
        display: flex;
        align-items: center;
        width: 160rpx;
        height: 100rpx;
        position: relative;
        .input {
            position: absolute;
            width: 100%;
            height: 100%;
            opacity: 0;
        }
        .txt {
            display: inline-block;
            width: 46rpx;
            height: 50rpx;
            margin-right: 10rpx;
        }
        &.praise .txt {
            background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAGxUlEQVRoQ81aaWwVVRQ+Z0ofP1xKYohEIhjRREVxR0hERBSioomyKIkiqBFt896cKVaif6j+kNTKm3PfS6s0ahETFzYTixoRBJcElM2tooliZFNDTNxCwiudY+7LTDO9nbcPhkmapvee7bv33HvPUoSYvlQqdb1lWbcBwGhEHO15Xv63Fi8ihy3LOqx/A8Bhz/Pey2Qyn8WhGmsR4jjODBG5BQDmAcCYCmUdAIA1iPih67qbKuQdIK8YQGNj4+mJRGIRIi4SkSurVRzmQ8S9ItKdy+W6Ozs7/61EZtkAWlpaRvX19S0CgAcB4IIIJfsB4F0A2AcABxDxQCKR0KsMuVxujIjoHdI/FwPA7QBwfoSMHwHglfr6+u729vbfygFSFgAi0go5wvDdALBRRN5XSn1ejsKAxrbt6xDxVgCYBQBXG7waCDGzXpCiX0kAjuM8JCIvGVK04V3M3FVKQTnzRPQIAOifQUAQ8WHXdV8uJqMoACJ6AgDaDAGL4zLcNMwHstIYX8rMzxUCURCAbdtzEXFNmFFE5iml1pazqtXSVKo3EoDjOJeJyNeG8ZcrpQaNVWtkKT7bticg4lfGTTXBdd1vTN4hAJqams6qr6//GADGB8TMXPKslDKqmnkikhBfb19f39SOjo4/BgEzBTuOs05EZgfjnueNzWQy+evw//5SqdQYy7J+CfQi4nrXdecUBGDb9mxEXBcyfkpcT3614P0Q5dOAX0TmKKXWD4AKC7Zt+yNEnOaPnbTbplIw4dtJRLYqpW4aAsBxnAdEZJU/sZuZr6lU0cmkJ6JdwTuBiAtd131V6xs4nET0BQBce6qtfrAoxhuxk5knDgBobm6e5Xlez6m6+iEQA7tgWdYd6XR6Y34HiEi/fvop199yZn4qyh38R2a8iOxRSr0Tp8uEZPcWeiyJ6FkAeNLXq0OZxQEAnWic409MY+ZtpnFEFKbR09uYOTjwNWEhIv3izw0JOcLM+WQo/BHRjQCw1R/L02AqlZpuWdZmf/AgMw9JTCIUBHKfZubWWqwnIs2/LELGWmbWiZIJQr9J5+pBz/NuxvC2iEinUqopgknH5mdHKNnAzAOPXjVAiOh1AJgfwfs7M48yx23b7kDExsDdNQB9HS3wBxqZ+YUIAD8DwHkRSlYxs05yqv6IqBsAFkYIOMTM+ZU23OgxAOj0x1aj4zibRWS6PzArKokwDnlYXs2PXYEQWuuIdE8/udqoCRBxC9q2vQ8RL/IHIiM+PWf6apyhdUQI3cPMd0ZtazhSFpHvtQv9DQBnaOLhw4ePaGtr+6uQPziOM1pELuzv7+/NZrNHq/abCMZkMjmyrq5OR8A/MPOvhWQvXbq04fjx43/68/9UBCBOg6uVNQRAuS5UrcK4+Ya4UDmHOG4japE35BCXc43WojBuXiIafI0a8UWWmVNxK41THhFlACDpy1yuQwldlA0ynv3MPC5OhXHLIqKfgqqe53lTgmBO5535GEhEJlVaZYvbyELy/GreDn/+ADOPDQC0A8Dj/kTNAdrJAmQ8ps8zc0segF8m/8BXfMqlk8GCGGnlTF2WH0gpbdvejoiTfOKiMU4ymZxkWVYizpWuq6vLpdPpwD2GiDYS+x1KqcmaKAzgHkR8s5xdMApOseE4duxYoqurqy9KYHj1ReRepdRbgwDoP2zb3oCId5XaBeMujgWAiDyqlDILu3nZxuq/rZS6O1A6qGRo2/YNiKjLivmvWMTpnxtd6D2zRgS7LMtKFnIfM1IVkalKqU8iAfhoXQ06BKJgUZeIRohIWrebqgEhIsuUUs8UuTbNIi8zsxOmjyzaEtFeALgiICxV3CWiySJyXyjVK4ZH98Be7O/vV9ls9lAxQuOsfcnMQ3pykQCWLFlyiY75w8JFpKzyOhFp4BMRUZdf9Kt+GgAcFZHtlmX1NjQ0bG5tbfWKGR5VXte5wooVK74z+QqWzQu0lhYw82vVuEu5PER0PwCsHuQmRVpNRev+BbolnYlEIt3e3q5jkti+lpaWcblcrtl0w1Kpa8nGhZ9AvBFueGiXQMT0iRMn3Gw2e7wWFMlkcviwYcMcEWkGgJEhWb2IOD+qK1PyEJsG6a5NIpFYGW58+DR7AECHIJuiqnklDqiuss0AgJkAcJXhMutzudxisxsTJa/kDoSZdAMEAJpCPYTw9EER6UHEb4s1ukXkUkS8I6iuGReFLht2hBsYpXa3IgCBML+XoCt4QTm+lJ5S8zsRsSOo+ZcirtiFCgn0y/J6NXW3PSgOl6v/iO7yW5bVo8vk5TKVfY1WKtAvEusKXzn/brMlk8lsqVRHFP1/RQgw6YJ2T1oAAAAASUVORK5CYII=") no-repeat center;
            background-size: 85%;
        }
        &.praise.active .txt {
            background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAFFklEQVRoQ8VaS2zcVBQ914lnAoIVLKChsKkApVCB/OwAorQQChI0i9K0UJCAAKKLsigSH7GisKCCIlFUdVEEhCJRQtrCogWJT1p+EmSeraLShI+CBIEUFoUFINoZJ77IJjNMPGP72ZlxR5pF5HPPuee9+2zPvSG06OMaxrXQcAszdYPQDdS+vsJ08GVME/E0PLynO87nrZCmhZCcMoybSMMqAq0HcGFKrikGj7CHD7sc54OUsTV4agO8sucs958zBsE0CODKrMKhuCMgHtLPPDlEH0/8nYZT2QCb5nkzwKDHfB8RlqQRUcUyY1IjerUTGCIpf1OJUzIwYxm3eqDt4PYk3pAoYVIDb+4sOe8mmUg0ULHE/WC8nETUluuEBwol+5U47lgDriUeY8azbUlOkZQIj+sl+7koeKSBsmWsI6YRRZ22wph4fbHk7G0m0tRA2TAuJ42OtjWrlOTs8bKi43wdDmswwJZ1jsveJwCWptRoN3xcJ20FlUq/1ws1GHBNsY+Bte3OJgs/Aft1aQ9EGigLsZYI+7KQ5xXDjIGibe+v6s3bgYoQh0C4Pq9kMukwDhds+4YGAxXLuAdMr2UizTuI+N5Cydnty9Z2oGKKEgAz71wy6smCtK2agRnLWu2xdyAj2WkJ00jr7yyVDgY7UDHFLgAPJmfCbzDTpAb0MGFdMl4dQYy9HjBBxEsAuksh8qWCtDcGBlxTTDOwKC5I1zqW0tjYRBXTyid1+EnLvb09rjc7HpcPAcd1aXeTa5p9DP4oDlzdrjCmLMQWIjypsFqREGY8VbTtLWGASlkT6EZyTeMZBj0Ru/oeLyLH+bXBgCU2EGPPggwQ7iyW7DfDHGwY57saHY/fBd5KFSF2g3B3QvksprGxXxoNLPyFL+pFjXt7L3C92Z9jF4fxOlVM4ZdPXxwwaptdIUYWepj9w6vbtv+bet5HsTxHfQPfALg0qQzC50BRIIk2uB5eIJX6nyP+1jfwJ4CzVZT8k8/A9wRcxsC5KjGqGAJOMHCMgIuT7oh1nH+lMqCaTI64wIBSCeWYVBqpoIQSD3Eaxpyxo0q30ZyTUpfzb6MqDzJ1xnyRBN5KflOWNfosX+nWqJHHy6tvoz9laM62JovsLFMFaV8UGCibxjYCPZKdK/9IBj9flM6jgQG/Ta5p9H7+aWRX9Dy+2W/L1/2kNL8A+ColSsZREP5QwqYDrVSD05cFKa/2sTUDZdO8ncDDKgQFaSc2hVV4wpiKKVgljkF3FKV8a54B/w/XNN9m8Jokkmr9JeHSXK9YYgcYDyXFEOgdXcrbqrh5K+ma5nUM9tuKCh/a4zE/3WXb3ymAIyGnhLikg7CDgVUqPARaoUv5aVMD/+2CeIGBzWpkOOExthXt6PZ3HM+MZa2ZZe9FAhYr6m3Xpf1wPbZpLVdMcQTAFSqkc5hjRBieneXhLsf5IS7ONc1rAPQzuD9lA/mrgrQbZnJNDah0BSKSPMmMQ0Q0RcQ/ekyTHnNwt+ogDICxHIRlKRamBg13RSJLqHrhtI6Wwg5jRk2xt8NW9n6yrLofEzedabiNNhOZm9b4bY+8Bx7j7PGGZlOZxEMcNuJPbWbY25XX4MMfZHSStjE8jWm2wKmeqMEABNjUthkC4zADO+sHGEmll8rA/wc8mCVsamE7XoJ4Z7Xnn5R06hKKIpzr3/QTsDpFKySgm2vRHNRIO+C3ydMk3TID9UR+kxjw+pT+3QbaqC7laNak6+P+BZqx/Lnt0mr1AAAAAElFTkSuQmCC") no-repeat center;
            background-size: 85%;
        }
        &.average .txt {
            background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAG+klEQVRoQ81aa2wVRRQ+Z9ve/tFIYogoEVQ0QVF8KyYiIgpRgUR5KD9E8EFjm96ZLdZGY6L+kdRC98xtWgM+QEx8UMBoUSOCoJiIIuCroolCLBQ1hMTXn97SPWZuZuve7e7dvQ8MmzQ3zMx5fDNnHuc7IFToS6fTN1qWdQcAjEXEsa7r5n61embutyyrX/8CQL/ruu9lMplPK2Eay1Fi2/ZMZr4NABYCwLgidfUBwAZE/NBxnK1Fyg4PLxpAfX39aalUaikiLmXmK0s17JdDxP3MvDabza7t6ur6pxidiQE0NzePGRwcXAoADwDAhSFGDgLAuwBwAAD6ELEvlUrpWYZsNjuOmfUK6b+LAeBOALggRMdPAPByTU3N2ra2tt+SAEkEQEqpDVKI43sBYAszv6+U+jyJQW+MEOJ6RLwdAGYDwNUBWQ1EEpGekIJfLADbth9k5hcDWrTja4hoTZyBJP1SymUAoP/ygCDiQ47jvFRIR0EAUsrHAKA1oKCuUo4HHTNAVgfaW4jouSgQkQCEEAsQcYNfkJkXKqW6k8xqqWOKtRsKwLbty5j5m4Dzlyul8tpKdTJOTggxGRG/DpxUkx3H+TYoOwJAQ0PDmTU1NR8DwCRvMBHF7pU4p0rpl1KyT653cHBwWmdn5/E8YEHFtm1vZOZ5XrvruuMzmUzuOPy/v3Q6Pc6yrF88u4i4yXGc+ZEAhBDzEHGjz/mplbrySwVvnii7PHlmnq+U2jQMyq9YCPERIk43bSfttCkWjP90YuYdSqlbRgCwbft+Zl5nOvYS0TXFGjqZ46WUX3r3BCIucRznFW1veHNKKb8AgGtPtdn3JiVwR+whouuGATQ1Nc12XbfnVJ19H4jhVbAsa057e/uW3ApIKfXtp69y/a0goifCwsFcMpOYeZ9S6p1KhoxPd2/UZSmlfBYAHjd29VOmzgOgE41zTMd0ItoZdE5K6R+ju3cSkbfhy8IipdQ3/gKfkqNElEuG/J+U8mYA2GHacmMwnU7PsCxrm2k8TEQjEpMQA57eZ4jo6XK8l1Jq+adCdHQTkU6UgiD0nXSubnRd91b0LwszdymlGkKE9Nv8rBAjm4lo+NIrBYiU8jUAWBQi+zsRjQm2CyE6EbHeC3cNQB9Hi01DPRE9HwLgEACcF2JkHRHpJKfkT0q5FgCWhCg4QkS5mQ6E0SMA0GXa1qNt29uYeYZpmB2WRAQ2uV9f2ZddxBNa2wgNT5NcbdEDEHE7CiEOIOJE0xD64tN9wVit5NM65AndQ0Rzw5bV/1Jm5h90CP0FAKfrwbW1taNaW1v/jIoH27bHMvNFQ0NDvR0dHcdKjpsQwcbGxtFVVVX6BfwjEf0apbulpeWMgYGBP0z/30UBqKTDpeoaASBpCJVqsNJyI0IoySautBPl6BuxiZMco+UYrLSslDL/GA28LzqIKF1po5XUJ6XMAECj0blCPyU0KetlPAeJaEIlDVZal5TyZ4/Vc113qveY03ln7g3EzFOKZdkq7WSUPsPm7Tb9fUQ03gPQBgCPmo6yH2gnC1DgMl1JRM05AIYm/8AYTpROCiE03ThQXV3duWrVqu9LcXr58uWXDA0NPYmIxx3H8eI6UlUgrZylafnhlFII8RkiTjHSBd84gZnoraqqWlgsCOO8zgM8/qngygcS+91KqRu0r34A9yDiG0lWQQgxFxHf9k1VUSBCnNd7ryBt6Z99Zr5XKfVmHgD9DyHEZkS8K8kqCCHaEdH2gTgCAKq/vz/T3d2dDYsDKeXZAFAHAA/7MkA9tJmIVkbFTmD231JK3e2NzaMMhRA3IaKmFXNf3KyEEbEAsA8AvgOAQ8ysV8Z1XXciM1+CiDol9FJXz8YypdQLBU6ePJKZmacppT4JBaAbpZSO/vGBKEjqGhAtIUWKuH3dY1nWGs0sFHA+SPISEflX/b894FcipdwPAFd4bUnI3agiRYhzsY57MgFy9ysiGlGTC2WdzSbr9Rtn5kT0uuaY9E3puu75Jg0dZfRo0nhXEoo+jF7XuULYSRdJm0eUlhYT0atxsVFOv5TyPgBY79dRqNRUkPePqJZ0pVKp9ra2Nv0mqdjX3Nw8IZvNNvkYh0QHSWzhwiQQr/sLHgBwDBHbT5w44XR0dAyUg6KxsbG2urraZuYmABjt09WLiIvCqjJ5q5PEuK7apFKp1f7Ch5HTR6Z+gmwNY/MK6TYs20wAmAUAVwVCZlM2m60LVmPC9MWugF9IF0AAoMFXQ/B3H2bmHkTUd0BkoZuZL0XEOR67FjgoNG3Y6S9gxE1wUQA8ZaaWoBk8j46PsxPXvwcROz3OP25w0SEUpdDQ8no29dGZd8MmcOKorvJbltVT6DKL01PSCoQpNSSxZviS/Heb7ZlMZnucc0n6/wWrb1bpdt6mGgAAAABJRU5ErkJggg==") no-repeat center;
            background-size: 85%;
        }
        &.average.active .txt {
            background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAFSElEQVRoQ8VaSWwcRRR9r+2egQhOcIA4wMUC5EAU6O4xSIQAZpEgPkAWCEhAICSHSCFILEIcCAeIWCSCUA4xSwiILQsckiCxmLBJ4OluggCbCPkAAQcOwAGQwdNOfdTNjDXuWbq6PTNpaU79//vvVf3qqvp/iBY9gWVdAgPXirAHRA8w8wsjTEQ/wQQpE1B4x/T9z1oRmnMB+deyrqaBqwiuAnBmSqwjAtklCu+f4PvvpfSdMU8tQC7rOymYPHENhGsAXJA1cMzvECg7zHn/7OBHY3+nwdQWII5z2jSwRoncQaI3TRBdWxGMG+SL3cAOuu6vOn5aAqYL1nUK3AppD/EaosS4AdnUXfQPJIlIFFAq2HdC8HwSUFveE2tzRe+FZthNBQQF+34RPN4WcpqgJB4wi94TjcwbCpgqWCsp3KUZp61mQlmVL/q76wWpK2DKss6nwa/byioluChZlPf9b+JuNQKkUDglEPUxgIUpY7TbfNSksZTF4u/VgWoEBI69R4Dl7WaTBZ/AXtP1VjQUMGXby0nsyQLeKR8RrMh73t5KvFkzULLtD0Fc3ikymeIIDuY874oaAaWCdRuEL2UC7bQT5fZc0d8Zhp2ZgZJjFwE4neaSMZ6bc73CjIDpQmGZErUvI9hxcTNoDHYXi/ujGSg59nYA65KZyKsiHDeAPiFWJtvrW1CwWwFjpPQCvEXDcyjneusjAYFjTwgwv5mTaXQt5MjIWMWmlTt1fKeV/v6+QB0bbcaHwFHT9XoYOM6AQD5oZlyZrrjNlG1vJvGwxmg1NBHBI3nP2xw30ElrglcycKzHBHyw6egrmU/f/6VGQMFeTcFrcxJA3Jwveq/HMcSyTg8MHm0+C7KFJdveCeLWhPQ5gyMjP9cKmPuBr9FBTfr7FwTq2E9NB0fwMkuOHabPQDPDRtMc2PauuS7mcPGanhfeqWc9muk5HAr4DsC5SWkQXweaAZJgo/fxAdLJ/zLw4VDAnwBO1okUrnwBvidwngCn6vjo2hD4TYBvCZyd9EWswvwrlQBdMh20iwRopVAHSaUJFaVQ4iJOg9hh22Gtz2iHSemHCz+jOhuZPmJnLQnZwrAoKwY/7Wzo1kSjkiWV0+iPGYqzrWGRHeVIzvXOigRMOdaTBO/NjtV5T4E8lXf9+yIBYZncMPhuKhrEWgEmKXhoDiWYUSEeJTAvbflSKbkmLMtXXSmdzwG5SEdE9dZfPruHFby0daRR0+haVbljpDua8Iuc614ccp0RMOU4NxLyho6A+AEsg4hZ5MOYaQ6GAt6Ud903ZwmIQBznLYFcryMCgmdznrexYjvZ37+gS03fbYAbBcjVwwjPUkrwXE5ke/X9Is0aJPi26bo3VPBn1YUCx7lUIGFZUeupd8wuWdaFIBcLcI5B9CpADOIwIWNdx3AwfjEqOdYQwLu0AkYpw6Wm635SV8D/s2A/LcAmXUAQr4DqmdzIl762D4DwyCyi1gkwqOtHYKvpevdU29etTpcc+xCAxbrAZbshGGooSUgW4mX8r3KuV9OTqytApyrQSJwIDpA8QsoPSjiuRP4IbbuIFRAsAbEo5cBE5vGqSMMUqrw4rq2luMImraamLaZW1n6yjHro06w7U/MZrRek3K0Jyx5pN6qsnCt+o6Jkdb2uTOIijkcOuzbTorZ3qvERNjK6aayPd2Ma7C36AxU1QIANbeshCA4KsK26gZHELrFPXA+g3EvY0MJyvAvKtkrNP4l06hRqBFiu3wwSWJaiFBLBlUs0+w0a+8IyeRrSLRNQDRQWiQE1oPV3GxjDpusOZyVd7fcfz78wyG+ppQsAAAAASUVORK5CYII=") no-repeat center;
            background-size: 85%;
        }
        &.bad-review .txt {
            background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAG9ElEQVRoQ81aaWhcVRQ+5yWZ/lEsiLgU61KFutV9A2ut1Ra1Cmqt+kNt3YoJmXtfagyKoP6x1LR5505IxLq0Krg0tqKpikutG7jvxgVcsBoXpOD2J5PmHTnDffHNmzuZeTOv4oMw9N57lu+u53ynCBl9+Xz+NM/zzgWAGYg4IwzD0q+oZ+ZRz/NG5RcARsMwfLZQKLyRhWlsRonv+wuZ+WwAWAoAM1Pq2g4AGxHxxSAIXkgpOzk8NYD29vbdcrncckRczszHNmo4LoeIHzLz+mKxuH5wcPDvNDrrBtDd3b3P+Pj4cgC4GgAOcRj5FgCeAYAvAGA7Im7P5XIyy1AsFmcys6yQ/B0GAOcBwMEOHV8DwANtbW3re3t7f6kHSF0AtNZikByOvw8AW5j5OWPM2/UYjMYopU5GxHMAYDEAHJ+QFSCaiGRCpvxqAvB9/xpmvi+hRRxfR0Trahmop19rfT0AyF8ZEES8NgiC+6fSMSUArfVNALA6oWBFVo4nHbNA7km09xDRXdVAVAWglLoEETfGBZl5qTFmqJ5ZbXRMWrtOAL7vH8XMnyScP9oYU9bWqJO15JRScxDx48RNNScIgk+TshUAOjo69mxra3sVAI6IBhNRzbNSy6lG+rXWHJMbGR8fnzcwMLCjDFhSse/7TzDzxVF7GIYHFAqF0nX4X3/5fH6m53nfR3YRcVMQBEuqAlBKXYyIT8Scn5vVk98oeBuivB7JM/MSY8ymSVBxxUqplxFxvm3bZbdNWjDx24mZtxljzqwA4Pv+Vcy8wXa8T0QnpDW0K8drrd+L3glEXBYEwYNib/Jwaq3fAYAT/2+zH01K4o14l4hOmgTQ1dW1OAzD4f/r7MdATK6C53nn9/X1bSmtgNZaXj95yuVbRUS3uLaDfWSOYOYPjDFPZ7llYrpHqj2WWus7AeBma1dCmRURAEk09rMd84nolaRzWuv4GOl+hYiiA98UFq21vPiXxJT8RESlZCj+aa3PAIBttq00BvP5/ALP816yjT8QUUVi4jAQ6b2DiG5vxnuttcjf5tAxRESSKCVByJu0vzSGYXgWxpeFmQeNMR0OIYnN93YY2UxEk49eI0C01o8AwOUO2V+JaJ9ku1JqABHbo+0uAOQ6utI2tBPR3Q4A3wHAgQ4jG4hIkpyGP631egBY5lDwIxGVZjqxjW4AgEHb9hD6vv8SMy+wDYtdSUTikMf1Nf3YVQmhxYZze9rkaosMQMStqJT6AhFn2wZnxCd9yb2aZWjtCKGHiegC17LGI2Vm/lK20J8AsLsMnjZt2vTVq1f/UW0/+L4/g5kPnZiYGOnv7/+t4X3jEOzs7NyrpaVFIuCviOjnarp7enr2GBsb+932/5UKQJYON6qrAkC9W6hRg1nLVWyheg5x1k40o6/iENdzjTZjMGtZrXX5NZqIL/qJKJ+10Sz1aa0LANBpda6SUEJI2Sjj+ZaIZmVpMGtdWutvIlYvDMO5UTAneWcpBmLmU9KybFk7WU2fZfPesv3bieiACEAvANxoO5oO0HYVoMRjuoaIuksALE3+vDXcVDopyZEscRiGB9n4abrVK2zH681wS4m0cpHQ8pMppVLqTUQ8xRpLHeNU4zcdqzHsed46yabSrFQisX/LGHOqyMcBXIqIj6VdBRvH9DgY5lr+pQISn31mvswY83gZAPmHUmozIl5Y7yq4eEwA+AAAPgOA75h5pKWlJQzDcDYzH46IklFFmV/JDDNfb4y5dyq0idl/0hhzUTS+jDJUSp2OiEIrRsqrkrlKqT5E9GOGfwQAMzo6WhgaGiq6HNJa7wsAKwDgugSQbiJa45JJThIzzzPGvOYEII1a60B+YiAqSF2l1AWI+FTMoMz00rVr135ea99I/8qVKw+fmJiQPHiSf3WF5w6Sl4goPmn/noG4Ya31hwBwTNSWJHcT11kq5yOdDhAV13eC3P2IiCpqck7W2SofiYNi5rKVUEpJ1WastbV1oN6ZT66OtXMrIu4IgiAKD+QsVtDrkiu47FSlzauUlq4koofr2SaNjtFaXwEAD8Xlpyo1Tcn7V6mWDOZyub7e3l6JSTL7uru7ZxWLxa4Y41DzIpEBNQsXNoF4NH7gAOA3ROzbuXNn0N/fP9YMis7Ozmmtra0+M3cBwF7xiwERL3dVZcpWpx7jUrXJ5XL3xAsfVk7ufAlBXnCxeVPptizbQgBYBADHJbbMpmKxuCJZjXHpq7kCcSEpgABAR6yGEO/+gZmHEVEesaqFbmY+EhHPj9i1xEUhtOFAvIBRa4JTAYiU2VqCMHgRHV/LTq3+dxFxIOL8aw1OvYWqKbS0vMymRKBlIUIdTvwkVX7P84bTBnaZAYgrsiSxMHz1/HebrYVCYWsdIGsO+QdX61bpEpb2WAAAAABJRU5ErkJggg==") no-repeat center;
            background-size: 85%;
        }
        &.bad-review.active .txt {
            background: url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAFVUlEQVRoQ8VabYwdUxh+3rM7cxF+8YNu8UMjsotgztwlQVGthC6h7VIStKRNNKjGR/xSfzT1kTaRSlpqVeJr+yG0JD5WKQl7Z0ZFbYlspMqWHySClL2ze145172bu3PvnTkze+/tJPfHZt73ed7nnPecOed9l9CkJ3ScSyFwLTN1gdAFTP00w1jpxxgj4jEovGsFwWfNoKaZgPzrOAtIYD6B+gGckRLrMIMHWeGD44Lg/ZS+U+apBfAV3SeGR49fBqZlAC7MShzx2w/iAeuEfwbo44N/p8E0FsCue+oEsEwxLyfCnDQkprbMGBVEL3YCA+R5v5r4GQmYyDvXKdBGcGsCrwmUMCrAqzsLwTtJIhIFFPPyLjBeSAJqyXvC3XbB3xqHHSsgzMuHmbG+JcEZghLhEavgP9nIvKGA8byzhJgGDXlaasbE/blCsL0eSV0B445zHgn6uqVRpQRnxefnguBA1K1GAOfzJ4esPgHQk5Kj1eYjFom5VCj8Xk1UIyB05Q4GFrU6miz4BOy0PH9xQwHjUi4iwo4s4O3yYcbinO/vrPBNm4GilB+BcGW7gsnEw9hr+/5VNQKKeecOML2UCbTdTsR32oVgm6admoGiKwsA3HbHkpHPsz0/PyVgIp9fqFjtzgh2TNwEib7OQmFPaQaKrtwMYEVyJPwKM40KoJsJS5LtzS2IsV0BB4l4DkC3GXhusT1/ZUlA6MoxBmbFOVmio4eGhw9WbJr5pY5+abm3tztUkyNx8RBwxPL8Lgpddx6DP4wzrkxX1GZcyrVEeMxgtBqaMOPxnO+vjRqYpDWBrqbQdZ5g0KOxo694FgXBLzUC8nIpMV6dkQDCrbmC/1oUgx3ntFDQkfhZ4HVUlHIbCLcnpM/pNDz8c62AmR/4Gh3UuLd3dqgmf4odHMbLVHSlTp95cYaNpjmUcnCmi1kvXsv39Z162mOYnkNawLcAzklKg+g6MCRIgi29jw6QSf6Xgb/TAv4EcJIJk175DHxPwLkMnGLiY2pDwG8MfEPA2Uk7YhXmX6kEmAbTRruSAKMUamNQaahKKZS4iNMgttl2yGgbbXNQ5nR6GzX5kJkjtteSwOtIF2VZ0KftpW4OGym+rHIa/TFDcbY5UWRHOWx7/pklAeOu8xSBHsyO1X5PBj+d84KHSgJ0mVwIeq8ZYRCwG+AfJpkOkeBDStEfGrdTYD4zFgCQzeBRiq/RZfmqK6X7OcAXzwB8C4TaYg9/GcRh6GMCs1rBQF92LvrC9rxLtP+UgHHXvZnAr6cF1Ycx7lDrkwKP4s5ECINuyXneG9ME6D9C193F4BtNRdQ7SRYd5yJB1DMJnFW+eioiHFBMo7ZS+6L3imJebgVjuTEn6E3L826q2E+rC4WuezmDdVkx+SGssQv+horh0d7e2R1q4n4Buo8Bux6APgwqxvM28+ZqIUUpnwFhTTKpThmaa3nevroC/p8FuYGB1XFgDLyd8/wbKjblO6yuZJvWU0cs0dE/7Y7tyrcIuD6Ol4CNluc/UG1TtzpddOV+ABc0Aqs+v2cIvgI7TYTB/eIr2/NrenJ1BZhUBcC4F0QK4HtSjHx0TEYAeg7MAoRn40Y/WhVpmEKVF8e0tRRVEtNqim0xNbP2Y7JA69nEdWdqttF6AOVujS57mC7QrLHWpBcrXlqvK5O4iKNIumszwWpzuxofupHRSWJltBvTYGs2H7BSAwRY1bIeAmMvA5uqGxhJ0SX2iesBlHsJq5pYjvdAvKlS808KOnUKNQIs12/6CFiYohRSgiuXaPYIErt1mTxN0E0TUA2ki8SAmmf07zYQQ5bnDWUNutrvP0e/McizDZK+AAAAAElFTkSuQmCC") no-repeat center;
            background-size: 85%;
        }
    }
}
</style>
