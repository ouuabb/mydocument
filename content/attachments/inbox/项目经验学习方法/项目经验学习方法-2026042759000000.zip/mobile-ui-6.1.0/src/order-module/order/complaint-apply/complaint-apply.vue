<template>
  <view class="apply-wrap">
    <view class="form-wrap">
      <view class="goods-content">
        <view class="title">相关商品交易信息</view>
        <view class="goods-item">
          <image class="goods-img" :src="skuData.goods_image" alt=""/>
          <view>
            <view class="goods-name">{{skuData.name}}</view>
            <view class="goods-price">
			<!-- {{order.goods_price | unitPrice}} -->
			<custom-price :price="order.goods_price" textColor="#666" :size="24"></custom-price>
			</view>
          </view>
        </view>
        <view class="order-info">订单编号：{{ order.sn }}</view>
        <view class="order-info">下单时间：{{ order.create_time | unixToDate }}</view>
        <view class="order-info">支付方式：{{ order.payment_type === 'ONLINE' ? '在线支付' : '货到付款' }}</view>
      </view>

      <view class="form-content">
        <u-form :model="complaintForm" ref="complaintForm">
          <u-form-item
            labelPosition="top"
            label="选择投诉主题：">
            <u-radio-group v-model="complaintForm.complain_topic" placement="column">
              <u-radio
                v-for="item in radioTypes"
                :key="item.topic_id"
                activeColor="#DF3A01"
                :name="item.topic_name">
                <view class="label">{{ item.topic_name }}</view>
                <text>{{ item.topic_remark }}</text>
              </u-radio>
            </u-radio-group>
          </u-form-item>
          <u-form-item
            required
            labelPosition="top"
            label="投诉内容：">
            <u-input
              v-model="complaintForm.content"
              type="textarea"
              height="150"
              placeholder="请填写投诉内容，字数限制200字内"/>
          </u-form-item>
          <u-form-item
            labelPosition="top"
            label="上传凭证："
            :borderBottom="false">
            <u-upload
              :action="action"
              :header="header"
              max-count="3"
              @on-list-change="onListChange">
            </u-upload>
          </u-form-item>
          <text class="tips">凭证限定3张图片</text>
        </u-form>
      </view>
    </view>
    <view class="btn-content">
      <u-button class="btn" type="error" @click="submitEvent">提交</u-button>
      <u-button class="btn" @click="cancelEvent">取消</u-button>
    </view>
    <u-toast ref="uToast" />
  </view>
</template>

<script>
import * as API_Complaint from '@/api/complaint.js'
import * as API_Order from '@/api/order.js'
import { Foundation } from '@/app-utils/index.js'
import { api } from '@/config/config'
import Cache,{Keys} from '@/utils/cache.js'

export default {
  data() {
    return {
      action: `${api.buyer}/buyer/uploaders`,
      header:  { Authorization: Cache.getItem(Keys.accessToken) },
      Foundation,
      // 订单编号
      orderSn: '',
      // 投诉商品ID
      skuId: '',
      //投诉主题
      radioTypes: [],
      // 订单详情
      order: {},
      // 商品数据
      skuData: {},
      // 申请表单
      complaintForm: {
        // 投诉主题
        complain_topic: '',
        // 投诉内容
        content: ''
      },
      images: []
    };
  },
  onLoad(options) {
    if (options.sn) {
      this.orderSn = options.sn
      this.skuId = options.skuId
      this.getComplaintTheme()
      this.getOrderDetail()
    }
  },
  methods: {
    cancelEvent() {
      uni.navigateBack()
    },
    /** 投诉提交 */
    submitEvent() {
      const { complaintForm, images, orderSn, skuId } = this
      if (!complaintForm.content) {
        this.$u.toast('请填写投诉内容')
        return
      } else if (complaintForm.content.trim().length > 200) {
        this.$u.toast('投诉内容不得超过200字数')
        return
      }
      if (images.length) {
        complaintForm.images = images.map(item => item.response && item.response.url)
      }
      complaintForm.order_sn = orderSn
      complaintForm.sku_id = skuId
      API_Complaint.appendComplaint(complaintForm).then(response => {
        this.$refs.uToast.show({
          title: '提交成功',
          type: 'success'
        })
        setTimeout(() => {
          uni.navigateBack()
        }, 1500)
      }).catch(() => {
        this.$u.toast('投诉申请提交失败！')
      })
    },
    onListChange(lists,name){
      this.images = lists
    },
    /** 获取订单详情 */
    getOrderDetail() {
      API_Order.getOrderDetail(this.orderSn).then(response => {
        this.order = response
        this.skuData = response.order_sku_list.find(v => {
          return v.sku_id === this.skuId
        })
      })
    },

    /** 获取投诉主题列表 */
    getComplaintTheme() {
      API_Complaint.getComplaintTheme().then(response => {
        if (Array.isArray(response) && response.length) {
          this.radioTypes = response
          this.complaintForm.complain_topic = response[0].topic_name
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep {
  .u-radio-group  {
    width: 100%;
  }
  .u-radio {
    width: calc(100% / 2) !important;
    margin-bottom: 14rpx;
    .u-radio__label {
      font-size: 26rpx;
    }
  }
}

.apply-wrap {
  .btn-content {
    border-radius: 8rpx;
    background: #fff;
    padding: 30rpx 40rpx;
    display: flex;
    justify-content: center;
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 9;
    .btn {
      width: 45%;
      margin: 0 10rpx;
    }
  }

}
.form-wrap {
  padding: 20rpx 20rpx 120rpx 20rpx;
  .goods-content, .form-content {
    font-size: 27rpx;
    color: #666;
    width: 100%;
    background: #fff;
    padding: 30rpx 40rpx;
    border-radius: 8rpx;
    margin-bottom: 20rpx;
  }

  .form-content {
    .tips {
      font-size: 24rpx;
      color: #666;
      margin-left: 20rpx;
    }
  }
  .goods-content {
    .title {
      color: #333;
      font-weight: 500;
    }
    .goods-item {
      border-top: 2rpx solid #efefef;
      border-bottom: 2rpx solid #efefef;
      margin: 20rpx 0;
      display: flex;
      align-items: center;
      padding: 20rpx 0;
      font-size: 24rpx;
      color: #666;
      .goods-img {
        width: 120rpx;
        height: 120rpx;
        margin-right: 10rpx;
      }
    }
    .order-info {
      margin-bottom: 10rpx;
    }
  }

}
</style>
