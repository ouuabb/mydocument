<template>
  <view class="wrap">

    <view v-if="!isVirtualOrder" class="address-view">
      <view class="no-address u-m-20 u-flex u-row-between" v-if="!address" @click="handleCheckoutAddress">
        <view class="">
          新建或选择收货地址以确保商品顺利送达
        </view>
        <view class="">
          <u-icon name="arrow-right"></u-icon>
        </view>
      </view>
      <addr v-else :name="address.name" :mobile="address.mobile" :addr_id="address.addr_id" :addr="address.addr"
        :addrs="MixinFormatRegions(address)"
        :def_addr="address.def_addr" :tag_name="address.ship_address_name" left_icon="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/address.png"
        :right_icon="'arrow-right'" @checkoutAddress="handleCheckoutAddress"></addr>
    </view>
    <view class="goods-list-view">
      <view class="shop-list" v-for="(shop, shopIndex) in inventories" :key="shopIndex">
        <seller-goods-item :shop="shop" @couponChange="getCarts" :way="way"></seller-goods-item>
      </view>
    </view>
    <view class="other-view">
      <view class="other-info-view" @click="handlePayment">
        <view class="other-left">支付{{isVirtualOrder ? '方式' : '配送'}}</view>
        <view class="other-middle">
          <view>
            {{ params.payment_type === 'ONLINE' ? '在线支付' : '货到付款'  }}
          </view>
          <view v-if="!isVirtualOrder">
            {{ params.receive_time | formatReceiveType }}
          </view>
        </view>
        <view class="other-right" v-if="!isVirtualOrder">
          <u-icon name="more-dot-fill"></u-icon>
        </view>
      </view>
      <view class="other-info-view" @click="handleShowReceiptPopup">
        <view class="other-left">发票</view>
        <view class="other-middle u-line-1" v-if="!params.receipt || !params.receipt.receipt_title">不开发票</view>
        <view class="other-middle u-line-1" v-else>
          {{params.receipt.receipt_type === 'VATORDINARY' ? '普票' : (params.receipt.receipt_type === 'ELECTRO' ? '电子' : '专票')}}
          ({{ params.receipt.receipt_content }} - {{ params.receipt.receipt_title }})
        </view>
        <view class="other-right">
          <u-icon name="more-dot-fill"></u-icon>
        </view>
      </view>
      <view class="other-info-view" @click="couponsShow = true" v-if="isShowfp && !crowdfundingShowFlag">
        <view class="other-left">平台优惠券</view>
        <view class="other-middle" v-if="amount">
          <!-- {{ '-' + MixinUnitOfCurrency + amount }} -->
          <custom-price :price="amount" isNeg :size="24" row></custom-price>
        </view>
        <view class="other-middle" v-else>{{ (availableCoupons.length ? availableCoupons.length + '个可用' : '无可用') }}
        </view>
        <view class="other-right">
          <u-icon name="more-dot-fill"></u-icon>
        </view>
      </view>
      <view class="other-info-view">
        <view class="other-left">订单备注</view>
        <view class="other-middle">
          <u-input v-show="hideInput" type="textarea" height="40" input-align="right" placeholder=" " />
          <u-input v-show="!hideInput" v-model="params.remark" type="textarea" height="40" input-align="right"
            placeholder="请输入订单备注内容" />
        </view>
      </view>
    </view>
    <view class="order-price-view">
      <u-cell-group :border="false" v-if="orderTotal">
        <u-cell-item title="商品金额" :arrow="false" :border-bottom="false">
          <!-- <text class="order-price-value">{{ orderTotal.original_price | unitPrice }}</text> -->
		  <view class="order-price-value"><custom-price :price="orderTotal.original_price" fontWeight="600" row></custom-price></view>

        </u-cell-item>
        <view v-for="(discountList, index) in orderTotal.discount_detail_list" :key="index"
          v-if="orderTotal.discount_detail_list">
          <u-cell-item :title="discountList.promotion_type_name" :arrow="false" :border-bottom="false">
            <!-- <text class="order-price-value">-{{ discountList.discount_price | unitPrice }}></text> -->
			<custom-price class="order-price-value" isNeg :price="discountList.discount_price" fontWeight="600" row></custom-price>
          </u-cell-item>
        </view>
        <u-cell-item title="优惠券抵扣" :arrow="false" :border-bottom="false" v-if="orderTotal.coupon_price">
          <!-- <text class="order-price-value">-{{ orderTotal.coupon_price | unitPrice }}</text> -->
		  <custom-price class="order-price-value" isNeg :price="orderTotal.coupon_price" fontWeight="600" row></custom-price>
        </u-cell-item>
        <u-cell-item title="返现金额" :arrow="false" :border-bottom="false" v-if="orderTotal.cash_back">
          <!-- <text class="order-price-value">-{{ orderTotal.cash_back | unitPrice }}</text> -->
		  <custom-price class="order-price-value" isNeg :price="orderTotal.cash_back" fontWeight="600" row></custom-price>
        </u-cell-item>
        <u-cell-item title="积分抵扣" :arrow="false" :border-bottom="false" v-if="orderTotal.paid_point != 0">
          <text class="order-exchange-value">-{{ orderTotal.paid_point }}积分</text>
        </u-cell-item>
        <u-cell-item title="运费" :arrow="false" :border-bottom="false">
          <!-- <text class="order-price-value">{{ orderTotal.freight_price | unitPrice }}</text> -->
		  <custom-price class="order-price-value" :price="orderTotal.freight_price" fontWeight="600" row></custom-price>
        </u-cell-item>
      </u-cell-group>
    </view>

    <view class="settlement">
      <custom-price :price="orderTotal.total_price" :size="50" :fontWeight="600"></custom-price>
      <view>
        <u-button shape="circle" size="medium" :custom-style="customStyle" @click="handleCreateTrade">提交订单</u-button>
      </view>
    </view>
    <!-- 赠品详情 -->
    <u-popup v-model="giftShow" mode="bottom" length="80%" border-radius="20" :safe-area-inset-bottom="true" closeable
      close-icon-size="20">
      <view class="u-m-30 u-text-center" style="font-weight: 600;">
        赠品详情
      </view>
      <view class="act-item u-flex u-m-l-50" v-for="(coupon, index) in giftDetails.gift_coupon_list" :key="index">
        <view class="">
          <image style="width: 100rpx;height: 100rpx;" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-color-coupon.png"></image>
        </view>
        <view class="act-name" style="display: flex;">
          价值 <!--<text class="order-price-value u-m-l-10 u-m-r-10">{{ coupon.amount | unitPrice }}</text>--><custom-price class="order-price-value u-m-l-10 u-m-r-10" :price="coupon.amount" fontWeight="600"></custom-price> 的优惠券
        </view>
      </view>
      <view class="act-item u-flex u-m-l-50" v-for="(gift, index) in giftDetails.gift_list" :key="index">
        <view class="">
          <u-image width="100" height="100" :src="gift.gift_img"></u-image>
        </view>
        <view class="act-name">
          价值 <!-- <text class="order-price-value u-m-l-10 u-m-r-10">{{ gift.gift_price | unitPrice }}</text> --><custom-price class="order-price-value u-m-l-10 u-m-r-10" :price="gift.gift_price" fontWeight="600"></custom-price>
          的{{ gift.gift_name }}
        </view>
      </view>
    </u-popup>
    <!-- 支付配送 -->
    <u-popup v-model="paymentShow" mode="bottom" length="80%" border-radius="20" :safe-area-inset-bottom="true"
      closeable close-icon-size="20">
      <view class="u-m-30 u-text-center" style="font-weight: 600;">
        支付配送
      </view>
      <view class="payment-view" v-if="orderTotal.original_price">
        <view class="payment-title">
          支付方式
        </view>
        <view class="payment-tag">
          <u-tag class="u-m-r-20" text="在线支付" :type="paymentType === 'ONLINE' ? 'error' : 'info'" shape="circle"
            @click="handleChoosePayment('ONLINE')" />
          <u-tag
            v-if="!isAssemble && orderTotal.total_price > 0 && !isVirtualOrder && !isSupplierOrder"
            text="货到付款" :type="paymentType === 'COD' ? 'error' : 'info'" shape="circle"
            @click="handleChoosePayment('COD')" />
        </view>
      </view>
      <view class="payment-view">
        <view class="payment-title">
          送货时间
        </view>
        <view class="payment-tag">
          <u-tag class="u-m-r-20" text="任意时间" :type="receiveTime === 'ANY_TIME' ? 'error' : 'info'" shape="circle"
            @click="handleChooseTime('ANY_TIME')" />
          <u-tag class="u-m-r-20" text="仅工作日" :type="receiveTime === 'WORKDAY' ? 'error' : 'info'" shape="circle"
            @click="handleChooseTime('WORKDAY')" />
          <u-tag text="仅休息日" :type="receiveTime === 'WEEKEND' ? 'error' : 'info'" shape="circle"
            @click="handleChooseTime('WEEKEND')" />
        </view>
      </view>
      <view class="big-btn1" @click="handleSavePayment">
        <view class="btn">
          确认
        </view>
      </view>
    </u-popup>
    <!-- 发票弹出层 -->
    <u-popup v-model="receiptShow" mode="bottom" length="80%" border-radius="20" :safe-area-inset-bottom="true"
      closeable close-icon-size="20">
      <view class="receipt-title-head">发票</view>
      <view class="receipt-view" style="padding-top: 100rpx;">
        <view class="receipt-title">
          发票类型
        </view>
        <view class="receipt-tag" v-if="receipt_type_list.length">
          <u-tag class="u-m-r-20" v-for="(receipt, index) in receipt_type_list" :key="index"
            @click="handleToggleType(receipt)" :text="receipt.receipt_type | receiptType"
            :type="receipt.checked ? 'error' : 'info'" shape="circle" />
          <view class="u-m-t-10 u-font-12" v-if="current_receipt_type === 'ELECTRO'">电子普通发票与普通纸质发票具有同等法律效力，支持报销入账</view>
          <view class="u-m-t-10 u-font-12" v-if="current_receipt_type === 'VATOSPECIAL'">我司依法开具发票，请您按照税法规定使用发票</view>
        </view>
        <view class="receipt-tag" v-else>商家未开通任何发票</view>
      </view>
      <view class="receipt-view u-p-b-30" v-if="need_receipt">
        <!-- 发票抬头 start -->
        <view class="item receipt-head">
          <view class="u-flex u-row-between u-m-b-20 u-line-1">
            <text class="receipt-title">发票抬头</text>
            <text class="u-line-1 u-m-l-80">{{receiptForm.receipt_title}}</text>
          </view>
          <view class="u-flex u-m-b-20" v-show="current_receipt_type !== 'VATOSPECIAL'" @click="handlePersonReceipt">
            <u-icon :name="receipt_title_type === 0 ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
            <text class="u-m-l-20">个人</text>
          </view>
          <view class="u-flex u-m-b-20" @click="handleChooseReceipt">
            <u-icon :name="receipt_title_type === 1 ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
            <text class="u-m-l-20 u-m-r-20">单位</text>
            <view class="u-flex-1 receipt-word"
              v-show="current_receipt_type !== 'VATOSPECIAL' && receipt_title_type === 1">
              <u-input v-model="receiptForm.receipt_title" placeholder="请填写单位名称" maxlength="60"
                @focus="show_receipts = true" @blur="handleOutReceipt"></u-input>
              <view class="receipts" v-if="receipts.length && show_receipts">
                <view class="rep-item" v-for="(rep, index) in receipts" :key="index"
                  @click.stop="handleSelectReceipt(rep)">
                  {{ rep.receipt_title }}
                </view>
              </view>
            </view>
          </view>
          <view class="u-flex u-m-b-20" v-show="current_receipt_type !== 'VATOSPECIAL' && receipt_title_type === 1">
            <text class="u-m-l-60 u-m-r-20">税号</text>
            <view class="u-flex-1 receipt-word">
              <u-input v-model="receiptForm.tax_no" autocomplete="off" placeholder="请输入纳税人识别号"></u-input>
            </view>
          </view>
        </view>
        <!-- 发票抬头 end -->
        <!-- 收票人信息 start -->
        <view class="item receiver-info" v-show="current_receipt_type === 'ELECTRO'">
          <view class="u-flex u-row-between u-m-b-20">
            <text class="receipt-title">收票人信息</text>
          </view>
          <u-cell-group>
            <u-form-item labelPosition="left" label="收票人手机" label-width="150">
              <view class="u-flex">
                <area-select ref="electroAreaSelect" :areaCode="receiptForm.mobile_area_code" />
                <u-input maxlength="11" type="tel" v-model="receiptForm.member_mobile" placeholder="请输入收票人手机"
                  clearable />
              </view>
            </u-form-item>
            <u-field v-model="receiptForm.member_email" type="email" size="mini" label="收票人邮箱" placeholder="请输入收票人邮箱" />
          </u-cell-group>
        </view>
        <!-- 收票人信息 end -->
        <!-- 收票信息 start -->
        <view class="item receiver-info" v-show="current_receipt_type === 'VATOSPECIAL'">
          <view class="u-flex u-row-between u-m-b-20">
            <text class="receipt-title">收票信息</text>
          </view>
          <u-cell-group>
            <u-field v-model="receiptForm.member_name" required size="mini" clearable label="收票人" placeholder="请输入收票人姓名" />
            <u-form-item required labelPosition="left" label="收票人手机" label-width="150">
              <view class="u-flex">
                <area-select ref="areaSelect" :areaCode="receiptForm.mobile_area_code"></area-select>
                <u-input maxlength="11" type="tel" v-model="receiptForm.member_mobile" placeholder="请输入收票人手机"
                  clearable />
              </view>
            </u-form-item>
            <addressFiled :defaultForm="receiptForm" @handlerRegionJson="handlerRegionJson" />
            <u-field v-model="receiptForm.detail_addr" required size="mini" type="text" label="详细地址" placeholder="请输入详细地址" />
          </u-cell-group>
        </view>
        <!-- 收票信息 end -->
        <!-- 发票内容 start -->
        <view class="item receipt-content">
          <view class="u-flex u-row-between u-m-t-20 u-m-b-20">
            <text class="receipt-title">发票内容</text>
            <text>{{ receiptForm.receipt_content }}</text>
          </view>
          <view class="receipt-tip-box u-m-b-20" v-if="isShowtip">
            根据国家相关规定，发票的开票内容需与购买的商品一致，暂不支持手动选择开票内容。
            <u-icon class="receipt-tip-close" name="close-circle-fill" @click="isShowtip = false" />
          </view>
          <view class="content-receipt">
            <view class="" v-for="(item, _index) in receipt_contents" :key="_index"
              v-show="item.receipt_type === current_receipt_type || !item.receipt_type"
              @click="handleChooseContent(item)">
              <view class="u-flex">
                <u-icon :name="item.code ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
                <text class="u-m-l-20">{{ item.receipt_content }}</text>
              </view>
              <view class="receipt-tip" v-show="!item.receipt_type && current_receipt_type !== 'VATOSPECIAL'">
                商品明细显示详细商品名称及价格信息
              </view>
              <view class="receipt-tip" v-show="item.receipt_type === 'ELECTRO'">
                本单可开发票内容：商品类别集合
              </view>
            </view>
          </view>
        </view>
        <!-- 发票内容 end -->
        <!-- 明细 start -->
        <view class="item detailed" v-show="current_receipt_type === 'VATOSPECIAL'">
          <view class="u-flex u-row-between u-m-t-20 u-m-b-20">
            <text class="receipt-title">明细</text>
          </view>
          <view class="">
            <view class="">
              <text>单位名称：</text>
              <text>{{ invoiceInfo.company_name }}</text>
            </view>
            <view class="">
              <text>纳税人识别号：</text>
              <text>{{ invoiceInfo.taxpayer_code }}</text>
            </view>
            <view class="">
              <text>注册地址：</text>
              <text>{{ invoiceInfo.register_address }}</text>
            </view>
            <view class="">
              <text>注册电话：</text>
              <text>{{ invoiceInfo.register_tel }}</text>
            </view>
            <view class="">
              <text>开户银行：</text>
              <text>{{ invoiceInfo.bank_name }}</text>
            </view>
            <view class="">
              <text>银行账户：</text>
              <text>{{ invoiceInfo.bank_account }}</text>
            </view>
          </view>
        </view>
        <!-- 明细 end -->
      </view>
      <view :class="need_receipt ? 'big-btn' : 'big-btn1'" @click="handleConfirmReceipt">
        <view class="btn">
          <text class="u-m-l-10">确定</text>
        </view>
      </view>
    </u-popup>
    <u-popup v-model="showAddressSelector" mode="bottom" closeable close-icon-size="20" border-radius="20">
      <region-picke @addressSelectorChanged="handleAddressSelectorChanged"
        @closeRegionpicke="showAddressSelector = false" :show="showAddressSelector"></region-picke>
    </u-popup>

    <!-- 优惠券弹出层 -->
    <u-popup v-model="couponsShow" mode="bottom" length="70%" border-radius="20" :safe-area-inset-bottom="true"
      closeable close-icon-size="20">
      <view class="u-m-30 u-text-center" style="font-weight: 600;">
        优惠券
      </view>
      <u-tabs :list="couponsTabList" :is-scroll="false" :current="current" @change="couponsTabsChange"
        active-color="#FA3534" bar-width="0"></u-tabs>
      <scroll-view scroll-y="true" v-if="current === 0">
        <view class="coupons-list u-flex u-m-20" v-for="(coupon, index) in availableCoupons" :key="index"
          @click="handleUseCoupons(coupon, index)">
          <view class="coupons-left">
            <custom-price :price="coupon.amount" :textColor="'#FFFFFF'" :size="50" class="u-line-1"></custom-price>
            <view class="u-font-22" style="display: flex;">
              满<!--{{ coupon.coupon_threshold_price | unitPrice }}--><custom-price :price="coupon.coupon_threshold_price" :size="22"></custom-price> 可用
            </view>
          </view>
          <view class="coupons-cont u-flex-1">
            <view class="coupons-title  u-m-b-10">
              {{ coupon.seller_name }}
            </view>
            <view class="coupons-time u-font-22">
              有效期截止：{{ coupon.end_time | date }}
            </view>
          </view>
          <view class="coupons-right">
            <u-icon :name="coupon.selected === 1 ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
          </view>
        </view>
        <u-empty v-if="!availableCoupons.length" text="暂无优惠券" mode="list"></u-empty>
      </scroll-view>
      <scroll-view scroll-y="true" v-if="current === 1">
        <view class="coupons-list u-flex u-m-20" v-for="(coupon, index) in noAvailableCoupons" :key="index">
          <view class="coupons-left">
            <custom-price :price="coupon.amount" :textColor="'#FFFFFF'" :size="50" class="u-line-1"></custom-price>
            <view class="u-font-22" style="display: flex;">
              满<!--{{ coupon.coupon_threshold_price | unitPrice }}--><custom-price :price="coupon.coupon_threshold_price" :size="22"></custom-price> 可用
            </view>
          </view>
          <view class="coupons-cont u-flex-1">
            <view class="coupons-title  u-m-b-10">
              {{ coupon.seller_name }}
            </view>
            <view class="coupons-time u-font-22">
              有效期截止：{{ coupon.end_time | date }}
            </view>
          </view>
        </view>
        <u-empty v-if="!noAvailableCoupons.length" text="暂无优惠券" mode="list"></u-empty>
      </scroll-view>
    </u-popup>
    <loading-view v-if="loading"></loading-view>
  </view>
</template>

<script>
  import * as API_Address from '@/api/address.js'
  import * as API_Members from '@/api/members.js'
  import * as API_Trade from '@/api/trade.js'
  import * as API_Crowdfunding from '@/api/crowdfunding'
  import {
    RegExp as RegExpUtil,
    Foundation
  } from '@/app-utils/index.js'
  import areaSelect from '@/components/areaSelect/areaSelect'
  import SellerGoodsItem from './components/SellerGoodsItem'
  import addressFiled from '@/components/addressFiled/addressFiled'
  import Cache, {
    Keys
  } from '@/utils/cache.js'

  export default {
    components: {
      areaSelect,
      SellerGoodsItem,
      addressFiled
    },
    data() {
      return {
        user: Cache.getItem(Keys.user),
        params: {}, //结算参数
        address: '', //已选地址
        // 是否是拼团
        isAssemble: false,
        inventories: '', //购物清单
        remark: '', //订单备注
        way: 'CART',
        // 订单总金额
        orderTotal: {
          discount_price: 0,
          exchange_point: 0,
          freight_price: 0,
          goods_price: 0,
          is_free_freight: 0,
          total_price: 0
        },
        giftShow: false, //赠品弹出层
        giftDetails: '', //赠品详情
        couponsShow: false, //优惠券弹出层
        couponsTabList: [
          { name: '可用优惠券' },
          { name: '不可用优惠券' }
        ],
        current: 0,
        sellerIds: '', //商品所属的商家id
        paymentShow: false, //支付配送弹出框
        paymentType: '',
        receiveTime: '',
        availableCoupons: [], //可以优惠券
        noAvailableCoupons: [], //不可以优惠券
        receiptShow: false, //发票弹出层
        need_receipt: false, //是否需要发票
        current_receipt_type: '', //当前选择的发票类型
        receipt_type_menu: [{
            show_detail: false,
            name: '增值税普通发票',
            status: 'ordin_receipt_status',
            checked: false,
            receipt_type: 'VATORDINARY'
          },
          {
            show_detail: false,
            name: '电子普通发票',
            status: 'elec_receipt_status',
            checked: false,
            receipt_type: 'ELECTRO'
          },
          {
            show_detail: false,
            name: '增值税专用发票',
            status: 'tax_receipt_status',
            checked: false,
            receipt_type: 'VATOSPECIAL'
          }
        ], //发票原始类型列表
        receipt_type_list: [], //发票类型列表
        receipt_type: '个人',
        // 发票表单
        receiptForm: {
          receipt_title: "", //发票抬头
          receipt_content: "", //发票内容
          receipt_type: "", //发票类型
          tax_no: "", //纳税人识别号
          address: '',
          member_name: '',
          member_mobile: ''
        },
        receipts: [], //发票列表
        content: '商品明细', //发票内容
        assembleOrderId: '',
        receipt_method: '订单完成后开票', // 开票方式
        last_receipt_title: '', // 上次选择的单位发票抬头
        receipt_title_type: 0, // 发票抬头类型 个人为0 单位为1
        receipt_contents: [{
          receipt_content: '商品明细',
          code: false,
          // 显示所对应的发票类型 '' 代表对应所有
          receipt_type: ''
        }, {
          receipt_content: '商品类别',
          code: false,
          // 显示所对应的发票类型 ELECTRO=>电子普通发票
          receipt_type: 'ELECTRO'
        }], // 发票内容列表 code为代号 false 未选
        invoiceInfo: '', // 增票资质详情信息
        invoiceAddressInfo: '', // 增票资质地址信息
        isShowtip: true, //是否显示提示信息 默认显示 状态为true
        show_receipts: false, //显示已有发票
        showAddressSelector: false, //是否显示地址选择器
        customStyle: {
          background: 'linear-gradient(to right, #FB6C30 0%, #F01026 100%)',
          color: '#FFFFFF',
          height: '80rpx'
        }, //自定义按钮样式
        isShowfp: true, //拼团的时候优惠劵不显示
        loading: true,
        crowdfundingShowFlag: false,
        crowdfundingId: null,
        amount: '', //优惠券优惠金额
        isVirtualOrder: false, // 是否为虚拟商品订单
        isSupplierOrder: false, // 是否为供应商品订单
        regionJSon: '',
        addressList: [],

      }
    },
    async onShow() {
      const params = await API_Trade.getCheckoutParams()
      this.params = params
      this.remark = params.remark
      this.receiveTime = params.receive_time

      if (params.address_id) {
        await API_Trade.setAddressId(params.address_id)
        this.initAddress()
      }
      if (this.orderTotal.total_price == 0) {
        this.paymentType = 'ONLINE'
        this.handleSavePayment()
      } else {
        this.paymentType = params.payment_type
      }
      this.getCarts()
    },
    onLoad(options) {
      // 是否是拼团
      this.isAssemble = options.from_nav === 'assemble'
      if (this.isAssemble) {
        this.params.payment_type = 'ONLINE'
        API_Trade.setPaymentType(this.params.payment_type)
      }
      if (options.way) {
        this.way = options.way
      }
      if (options.assembleOrderId) {
        this.assembleOrderId = options.assembleOrderId
      }
      this.crowdfundingShowFlag = !!options.crowdfundingShowFlag
      this.crowdfundingId = options.crowdfundingId
    },
    watch: {
      sellerIds: 'init',
      receiptShow(val) {
        if (!val) return
        const {
          receipt
        } = this.params
        // 如果存在发票信息
        if (receipt && receipt.receipt_title) {
          this.receiptForm = {
            ...receipt
          }
          const {
            areaCode,
            mobileValue
          } = Foundation.formatIn18Mobile(this.receiptForm.member_mobile)
          this.receiptForm.mobile_area_code = areaCode
          this.receiptForm.member_mobile = mobileValue
          const _receipt = this.receipts.find(key => key.receipt_title === this.receiptForm.receipt_title)
          if (_receipt && _receipt.receipt_id) {
            this.receiptForm.receipt_id = _receipt.receipt_id
          }
          if (receipt.receipt_type === 'VATOSPECIAL') {
            this.receiptForm.receipt_title = this.invoiceInfo.company_name || '单位'
            this.receiptForm.detail_addr = receipt.detail_addr
            this.receiptForm.member_name = receipt.member_name
            this.receiptForm.regions = [receipt.province_id, receipt.city_id, receipt.county_id, receipt.town_id]
            this.receiptForm.address = receipt.province ?
              `${receipt.province}${receipt.city}${receipt.county}${receipt.town}` : receipt.address
            this.handleToggleType(this.receipt_type_list.find(item => item.receipt_type == receipt.receipt_type))
          }
          this.receipt_contents.forEach(item => {
            if (item.receipt_content === receipt.receipt_content) {
              item.code = true
            } else {
              item.code = false
            }
          })
        } else { // 如果不存在发票信息
          this.handleToggleType(this.receipt_type_list[0])
        }
        this.receipt_title_type = this.receiptForm.receipt_title === '个人' ? 0 : 1
      },

    },
    computed: {
      hideInput() {
        const {
          giftShow,
          paymentShow,
          receiptShow,
          showAddressSelector,
          couponsShow
        } = this
        return giftShow || paymentShow || receiptShow || showAddressSelector || couponsShow
      },

    },
    filters: {
      receiptType(type) {
        switch (type) {
          case 'VATORDINARY':
            return '增值税普通发票'
          case 'ELECTRO':
            return '电子普通发票'
          case 'VATOSPECIAL':
            return '增值税专用发票'
          default:
            return '不开发票'
        }
      },
      formatReceiveType(type) {
        switch (type) {
          case 'ANY_TIME':
            return '任意时间'
          case 'WORKDAY':
            return '仅工作日'
          case 'WEEKEND':
            return '仅休息日'
        }
      }
    },
    methods: {
      handlerRegionJson(obj) {
        this.regionJSon = obj
      },
      /** 初始化地址 */
      async initAddress() {
        const params = this.params

        // 个人地址
        let addressList = []
        let defAddress = null

        await API_Address.getAddressList().then(res => {
          addressList = res
          defAddress = res.find(item => {
            return item.def_addr
          })
        })


        this.addressList = addressList
        let address = {}
        if (params.address_id) {
          let list = addressList



          address = list.find(item => {
            return item.addr_id === params.address_id
          })
          this.address = address || defAddress
        }
      },


      //选择地址
      handleCheckoutAddress() {
        const tabCurrent = this.tabCurrent
        const url = tabCurrent ? '/enterprise-module/enterprise-address/index?from=checkout' :
          '/mine-module/address?from=checkout'
        uni.navigateTo({
          url
        })
      },
      couponsTabsChange(index) {
        this.current = index
      },
      //赠品详情
      handleGift(shop) {
        this.giftShow = true
        this.giftDetails = shop
      },
      //使用优惠券
      async handleUseCoupons(coupon, index) {
        const params = {}
        params.way = this.way
        const used = coupon.selected === 1
        params.type = coupon.selected
        await API_Trade.useCoupon(coupon.member_coupon_id, params)
        if (used) {
          this.amount = ''
        } else {
          this.amount = coupon.amount
        }
        this.getCarts()
        this.couponsShow = false
      },
      //选择发票抬头
      handleReceiptTag(name) {
        this.receipt_type = name
      },
      //选择支付方式
      handleChoosePayment(name) {
        this.paymentType = name
      },
      //选择配送方式
      handleChooseTime(name) {
        this.receiveTime = name
      },
      handlePayment() {
        if (this.isVirtualOrder) return
        this.paymentShow = true
        this.paymentType = this.params.payment_type
        this.receiveTime = this.params.receive_time
      },
      //保存支付配送
      handleSavePayment() {
        Promise.all([
          API_Trade.setPaymentType(this.paymentType),
          API_Trade.setReceiveTime(this.receiveTime)
        ]).then(() => {
          this.paymentShow = false
          this.params.payment_type = this.paymentType
          this.params.receive_time = this.receiveTime
        })
      },
      //函数节流隐藏元素
      handleOutReceipt() {
        setTimeout(() => {
          this.show_receipts = false
        }, 50)
      },
      //商品金额为0元时不支持开具发票
      handleShowReceiptPopup() {
        if (!this.orderTotal.original_price || !this.orderTotal.goods_price) {
          this.$u.toast('该订单不支持开具发票')
          return
        } else {
          this.receiptShow = true
        }
      },
      //初始化发票信息
      init() {
        if (!this.sellerIds) return
        const params = {
          seller_ids: this.inventories.map(item => item.seller_id)
        }

        API_Members.queryMembersReceipt(params).then(async response => {
          this.receipt_type_list.push({
            show_detail: false,
            name: '不开发票',
            status: '',
            checked: false,
            receipt_type: ''
          })
          const _receipt_type_list = this.receipt_type_menu.filter(item => response[item.status] === 1)
          this.receipt_type_list = [...this.receipt_type_list, ..._receipt_type_list]
          // 如果商家开启专票
          if (response.tax_receipt_status === 1) {
            // 获取赠票资质基础信息
            this.GET_InvoiceInfo()
            this.GET_InvoiceAddressInfo()
          }
          // 如果没有发票信息
          if (!this.params.receipt) {
            this.receipt_type_list.forEach(key => {
              if (!key.receipt_type) key.checked = true
            })
          } else { // 如果有自带发票信息
            this.receiptForm = {
              ...this.params.receipt
            }
            const {
              areaCode,
              mobileValue
            } = Foundation.formatIn18Mobile(this.receiptForm.member_mobile)
            this.receiptForm.mobile_area_code = areaCode
            this.receiptForm.member_mobile = mobileValue
            this.current_receipt_type = this.params.receipt.receipt_type
            this.receipt_type_list.forEach(key => {
              if (key.receipt_type === this.current_receipt_type) key.checked = true
            })
            if (this.current_receipt_type === 'VATORDINARY' || this.current_receipt_type === 'VATOSPECIAL') {
              const _receipt = this.receipt_contents.find(key => key.receipt_content === this.receiptForm
                .receipt_content)
              if (_receipt && _receipt.code !== undefined && _receipt.code !== null) {
                _receipt.code = true
              }
            }
            this.need_receipt = true
            this.GET_ReceiptList()
          }
        })
      },
      //切换发票类型
      async handleToggleType(receipt) {
        if (receipt.receipt_type === 'ELECTRO') {
          this.receiptForm.member_mobile = ''
          this.receiptForm.member_email = ''
        }
        // 切换发票校验
        if (receipt.checked) return
        if (this.invoiceInfo && this.invoiceInfo.status !== 'AUDIT_PASS') {
          this.$u.toast('会员还未申请增票资质或者申请审核未通过')
          return
        }
        // 获取当前发票类型 并且选择当前发票相关信息
        this.current_receipt_type = receipt.receipt_type
        // 获取会员发票列表
        await this.GET_ReceiptList()
        if (this.current_receipt_type === 'VATORDINARY' || this.current_receipt_type === 'ELECTRO') {
          // 设置发票抬头 如果不存在发票则首先选中默认发票 否则选中 个人
          const _receipt = this.receipts.find(key => key.is_default === 1)
          if (_receipt) {
            this.receiptForm = JSON.parse(JSON.stringify(_receipt))
            this.receipt_title_type = 1
          } else {
            this.receiptForm.receipt_title = '个人'
            this.receipt_title_type = 0
          }
        }
        // 选定发票内容 如果是增值税普通发票/专用发票 内容为商品明细； 电子发票可选类别【商品明细 | 商品类别】
        if (this.current_receipt_type === 'VATORDINARY' || this.current_receipt_type === 'VATOSPECIAL') {
          // 设置发票内容
          this.receipt_contents.forEach(key => key.code = false)
          // 翻译问题导致需要兼容判断 商品明细 || 商品详情
          this.receipt_contents.find(key => key.receipt_content === '商品明细' || key.receipt_content === '商品详情').code =
            true
          this.receiptForm.receipt_content = '商品明细'
        }
        // 选定发票内容 如果选定的是电子普通发票，则判断默认选择的是那个
        if (this.current_receipt_type === 'ELECTRO') {
          const default_receipt = this.receipts.find(item => item.is_default)
          this.receipt_contents.forEach(key => key.code = false)
          if (default_receipt) {
            const current_receipt = this.receipt_contents.find(key => key.receipt_content === default_receipt
              .receipt_content)
            current_receipt.code = true
            this.receiptForm.receipt_content = default_receipt.receipt_content
          } else {
            this.receipt_contents.find(key => key.receipt_content === '商品明细' || key.receipt_content === '商品详情').code =
              true
            this.receiptForm.receipt_content = '商品明细'
          }
        }
        if (this.current_receipt_type === 'VATOSPECIAL') {
          this.receipt_title_type = 1
          this.receiptForm = { ...this.receiptForm, ...this.invoiceAddressInfo }
          this.receiptForm.receipt_title = this.invoiceInfo.company_name || '单位'
          this.receiptForm.addrs = this.MixinFormatRegions(this.invoiceAddressInfo)
          this.handleChooseReceipt()
        }
        const {
          areaCode,
          mobileValue
        } = Foundation.formatIn18Mobile(this.receiptForm.member_mobile)
        this.receiptForm.mobile_area_code = areaCode
        this.receiptForm.member_mobile = mobileValue
        this.receipt_type_list.forEach(key => key.checked = false)
        receipt.checked = true
        this.need_receipt = !!receipt.receipt_type
      },
      // 地址选择器发生改变
      handleAddressSelectorChanged(object) {
        const obj = {
          last_id: object[object.length - 1].id,
          address: object.map(key => {
            return key.local_name
          }).join(' ')
        }
        this.receiptForm.region = obj.last_id
        this.receiptForm.address = obj.address
      },
      //选择发票抬头类型
      handleSelectReceipt(receipt) {
        this.show_receipts = false
        this.receiptForm = {
          ...receipt
        }
        this.last_receipt_title = this.receiptForm.receipt_title
      },
      // 当选择个人发票类型的时候 设置发票抬头为 '个人' 发票抬头类型为0 税号为 ''
      handlePersonReceipt() {
        this.receiptForm.tax_no = ''
        this.receiptForm.receipt_title = '个人'
        this.receipt_title_type = 0
      },
      // 当选择非个人发票类型的时候 匹配默认发票
      handleChooseReceipt() {
        if (this.current_receipt_type === 'VATOSPECIAL') {
          this.receiptForm.member_mobile = this.receiptForm.member_mobile || ''
          return
        }
        this.receiptForm.receipt_title = ''
        this.receiptForm.tax_no = ''
        let _receipt
        if (this.receiptForm.receipt_id && this.last_receipt_title) {
          _receipt = this.receipts.find(key => key.receipt_title === this.last_receipt_title)
        } else {
          _receipt = this.receipts.find(key => key.is_default === 1)
        }
        if (_receipt) {
          this.receiptForm = {
            ..._receipt
          }
          if (!_receipt.receipt_content) {
            this.receipt_contents.forEach(key => key.code = false)
          }
        }
        this.last_receipt_title = this.receiptForm.receipt_title
        this.receipt_title_type = 1
      },
      // 选择发票内容
      handleChooseContent(item) {
        this.receiptForm.receipt_content = item.receipt_content
        this.receipt_contents.forEach(key => key.code = false)
        item.code = true
      },
      cancelReceipt() {
        API_Trade.cancelReceipt().then(() => {
          this.receiptShow = false
          this.$set(this.params, 'receipt', '')
        })
      },
      //确认发票
      handleConfirmReceipt() {
        if (!this.need_receipt) {
          this.cancelReceipt()
          return
        }
        const {
          receiptForm,
          invoiceInfo
        } = this
        const current_receipt_type = this.current_receipt_type
        const {
          mobile_regex,
          formatValid,
          mobileValue
        } = current_receipt_type === 'ELECTRO' ? this.$refs.electroAreaSelect : this.$refs.areaSelect
        const mobileReg = new RegExp(mobile_regex)
        const member_mobile = mobileValue(receiptForm.member_mobile)

        if (current_receipt_type !== 'VATORDINARY' && !mobileReg.test(formatValid(member_mobile))) {
          this.$u.toast(`请输入正确的手机号码`)
          return
        }
        // 增值税发票参数
        const _speparams = {
          receipt_method: this.receipt_method,
          bank_name: invoiceInfo.bank_name,
          bank_account: invoiceInfo.bank_account,
          reg_addr: invoiceInfo.register_address,
          reg_tel: invoiceInfo.register_tel,
          member_name: receiptForm.member_name,
          detail_addr: receiptForm.detail_addr,
          address: receiptForm.address,
          tax_no: invoiceInfo.taxpayer_code
        }
        // 电子发票
        const _elecparams = {
          member_mobile: member_mobile,
          member_email: receiptForm.member_email
        }

        let params = {
          // 发票类型
          receipt_type: current_receipt_type,
          // 发票抬头
          receipt_title: receiptForm.receipt_title,
          // 发票内容
          receipt_content: receiptForm.receipt_content,
          // 税号
          tax_no: receiptForm.tax_no
        }
        if (current_receipt_type === 'ELECTRO') {
          params = {
            ...params,
            ..._elecparams
          }
        }
        if (current_receipt_type === 'VATOSPECIAL') {
          params = {
            region: JSON.stringify(this.regionJSon),
            ...params,
            ..._elecparams,
            ..._speparams
          }
        }
        // 抬头
        if (!params.receipt_title) {
          this.$u.toast('请填写发票抬头')
          return false
        }
        // 税号
        if (params.receipt_title !== '个人' && params.tax_no && !RegExpUtil.TINumber.test(params.tax_no)) {
          this.$u.toast('纳税人识别号不正确')
          return false
        }
        // 验证是否相同
        API_Trade.setRecepit(params).then(() => {
          // 如果对发票列表进行操作 编辑/新增单位发票  如果操作增值税普通发票并且抬头不是个人 则调用以下API
          if (current_receipt_type !== 'VATOSPECIAL' && params.receipt_title !== '个人') {
            const isEdit = !!(receiptForm.receipt_id && this.receipts.find(key => key.receipt_title === receiptForm
              .receipt_title))
            Promise.all([
              isEdit ?
              API_Members.editReceipt(receiptForm.receipt_id, params) :
              API_Members.addReceipt(params)
            ]).then(async () => {
              this.$u.toast('成功！')
              this.receiptShow = false
              this.$set(this.params, 'receipt', params)
              await this.GET_ReceiptList()
            })
          } else {
            this.$u.toast('成功！')
            this.receiptShow = false
            this.$set(this.params, 'receipt', params)
          }
        })
      },
      //获取购物清单，和结算金额
      getCarts() {
        let fun = API_Trade.getCarts
        if (this.isAssemble) {
          fun = API_Trade.getAssembleCarts
        }
        if(this.crowdfundingShowFlag){
          fun = API_Crowdfunding.getCart
        }
        fun('checked', this.way).then(response => {
          const {
            cart_list,
            total_price,
            cart_member_coupon_list
          } = response
          if (cart_member_coupon_list && cart_member_coupon_list.available_list) {
            const amounts = cart_member_coupon_list.available_list.filter(item => item.selected === 1)[0]
            if (amounts) {
              this.amount = amounts.amount
            }
          }

          this.inventories = cart_list
          this.inventories.forEach(item => {
            if (item.cart_type == 'PINTUAN') {
              this.isShowfp = false
            }
          })
          if (total_price && Object.keys(total_price).length) {
            this.orderTotal = total_price
          }

          //0元商品只能显示在线支付
          if (this.params && this.params.payment_type === 'COD' && !this.orderTotal.original_price) {
            this.params.payment_type = 'ONLINE'
            API_Trade.setPaymentType(this.params.payment_type)
          }

          //清空优惠卷数组
          this.availableCoupons = []
          this.noAvailableCoupons = []

          //设置优惠券
          if (cart_member_coupon_list) {
            cart_member_coupon_list.available_list && cart_member_coupon_list.available_list.forEach(item => {
              this.availableCoupons.push(item)
            })
            cart_member_coupon_list.un_available_list && cart_member_coupon_list.un_available_list.forEach(item => {
              this.noAvailableCoupons.push(item)
            })
          }
          this.isVirtualOrder = cart_list.some(sku => {
            return sku.sku_list.some(goods => goods.goods_type === 'VIRTUAL') || sku.group_list.some(group =>
              group.sku_list.some(goods => goods.goods_type === 'VIRTUAL'))
          })
          this.isSupplierOrder = cart_list.some(sku => {
            return sku.sku_list.some(goods => goods.supplier_goods) || sku.group_list.some(group => group
              .sku_list.some(goods => goods.supplier_goods))
          })
          this.sellerIds = cart_list.map(item => item.seller_id).join(',')
          this.loading = false
        })
      },
      // 提交订单
      async handleCreateTrade() {
        let client = ''
        // #ifdef APP-PLUS
        client = 'APP'
        // #endif

        // #ifdef H5
        client = 'H5'
        const user_agent = navigator.userAgent
        if (user_agent) {
          // 区分微信生态
          const ua = user_agent.toLowerCase();
          const isWeChat = (() => {
            return /MicroMessenger/i.test(ua)
          })()
          if (isWeChat) {
            client = 'WECHAT_H5'
          }
        }
        // #endif

        // #ifdef MP
        client = 'MINI'
        // #endif
        let params = {
          client,
          way: this.way,

        }


        if (this.params.remark) {
          uni.showLoading({
            title: '请稍候...',
            mask: true
          })
          await API_Trade.setRemark(this.params.remark)
        }
        if (this.isAssemble) {
          params.pintuan_order_id = this.assembleOrderId
        }
        uni.showLoading({
          title: '请稍候...',
          mask: true
        })
        let fun = API_Trade.createTrade
        if (this.isAssemble) {
          fun = API_Trade.createAssembleTrade
        } else if (this.crowdfundingShowFlag) {
          fun = API_Crowdfunding.createTrade
        }
        const response = await fun(params)
        if (this.orderTotal.total_price && this.params.payment_type === 'ONLINE') {
          uni.redirectTo({
            url: `/order-module/cashier/cashier?trade_sn=${response.trade_sn}`
          })
        } else {
          uni.redirectTo({
            url: `/order-module/checkout/create-complete`
          })
        }
      },
      // 获取发票列表
      async GET_ReceiptList() {
        if (this.current_receipt_type === 'VATORDINARY' || this.current_receipt_type === 'ELECTRO') {
          this.receipts = await API_Members.getReceipts(this.current_receipt_type)
        }
      },
      // 获取增票资质详情信息
      async GET_InvoiceInfo() {
        let api = API_Members.queryInvoiceInfo

        this.invoiceInfo = await api()
      },
      // 获取增票地址信息
      async GET_InvoiceAddressInfo() {
        let api = API_Members.queryTicketAdress

        this.invoiceAddressInfo = await api()
      }
    }
  }
</script>

<style lang="scss" scoped>
  .wrap {
    padding-bottom: 150rpx;
  }

  .address-view {
    margin: 20rpx;
    margin-top: 30rpx;
    padding: 15rpx !important;
    background-color: #FFFFFF;
    border-radius: 20rpx;

    ::v-deep.custom-icon {
      font-size: 60rpx !important;
      font-weight: bold !important;
    }
  }

  .tabs-view + .address-view {
    margin: 0;
    padding: 80rpx 0 15rpx !important;
  }

  .goods-list-view {
    .shop-list {
      margin: 20rpx;
      padding: 20rpx;
      border-radius: 20rpx;
      margin-bottom: 10rpx;
      background-color: #FFFFFF;
    }

    .act-box {
      .act-item {
        position: relative;
        padding: 20rpx;
        margin: 20rpx;
        background-color: #FDF3F3;
        border-radius: 4rpx;

        .act-item-title {
          color: #333;
          font-size: 28rpx;
        }

        .act-item-cont {
          margin-left: 20rpx;
          color: #7f828b;
          font-size: 24rpx;
        }

        &::before {
          content: ' ';
          position: absolute;
          top: -10rpx;
          left: 68rpx;
          width: 20rpx;
          height: 20rpx;
          background-color: #FDF3F3;
          transform: rotate(45deg);
        }
      }
    }
  }

  .receipt-title-head {
    position: fixed;
    width: 100%;
    height: 100rpx;
    line-height: 100rpx;
    font-weight: 600;
    text-align: center;
    z-index: 2;
    background-color: #FFFFFF;
  }

  .other-view {
    margin: 20rpx;
    background-color: #FFFFFF;
    padding: 15rpx;
    border-radius: 20rpx;

    .other-info-view {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      margin: 20rpx 10rpx;
      align-items: center;

      .other-left {
        min-width: 150rpx;
        font-weight: bold;

        text {
          color: #F56C6C;
          margin-right: 8rpx;
        }
      }

      .other-middle {
        flex: 1;
        text-align: right;
        display: flex;
        justify-content: flex-end;
      }

      .other-right {
        width: 60rpx;
        text-align: right;
      }
    }
  }

  .order-price-view {
    margin: 20rpx;
    background-color: #FFFFFF;
    padding: 15rpx;
    border-radius: 20rpx;

    .order-exchange-value {
      color: #333333;
      font-weight: bold;
    }

    .exchange-tip {
      display: block;
      color: #FA3534;
      font-size: 22rpx;
    }
  }

  .order-price-value {
    color: #FA3534;
    font-weight: bold;
	display: flex;
	justify-content: flex-end;
  }

  .receipt-word {
    position: relative;

    .u-input {
      width: 100%;
      background: #f0f2f5;
      padding: 0 15rpx !important;
    }

    .receipts {
      position: absolute;
      top: 75rpx;
      width: 100%;
      background-color: #fff;
      box-shadow: 0 10rpx 32rpx 0 #ccc;
      z-index: 10;

      .rep-item {
        padding: 10rpx;
        word-break: break-word;
      }
    }
  }

  .settlement {
    position: fixed;
    z-index: 999;
    bottom: 0rpx;
    left: 0rpx;
    display: flex;
    background-color: #ffffff;
    width: 100%;
    align-items: center;
    justify-content: space-between;
    padding: 20rpx;
    padding-bottom: 40rpx;
  }

  .receipt-view,
  .payment-view {
    margin: 0 30rpx;
    position: relative;

    .receipt-title {
      font-weight: 600;
    }

    .payment-title {
      font-weight: 600;
      margin-bottom: 15rpx;
    }

    .active .u-size-default {
      background-color: #578AF2;
      color: #FFFFFF;
      border: 2rpx solid #578AF2;
    }

    .receipt-tip {
      color: #999;
      font-size: 24rpx;
      padding-left: 60rpx;
    }

    .receipt-tip-box {
      display: flex;
      color: #f85;
      padding: 15rpx 40rpx 15rpx 30rpx;
      font-size: 24rpx;
      position: relative;
      background-color: #fff7cc;

      .receipt-tip-close {
        position: absolute;
        right: 10rpx;
        top: 38rpx;
        font-size: 32rpx;
      }
    }
  }

  .coupons-list {
    .coupons-left {
      padding: 30rpx 20rpx;
      background-color: rgb(98, 154, 238);
      text-align: center;
      font-size: 28rpx;
      color: #ffffff;
      width: 252rpx;

      .u-line-1 {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }

    .coupons-cont {
      margin: 0 20rpx;
    }
  }

  ::v-deep {
    .u-shape-circle {
      min-width: 150rpx;
      text-align: center;
    }

    .u-field {
      padding: 20rpx 0 !important;
    }

    .u-field__input-wrap {
      font-weight: 400 !important;
    }

    .u-cell {
      padding: 5rpx 0 !important;

      .u-cell_title {
        color: #000000;
        font-weight: bold;
      }
    }

    .u-mode-light-info {
      border: 2rpx solid #F4F4F5 !important;
    }

    .u-empty {
      margin-top: 160rpx !important;
    }

    .custom-icon-xuanze {
      color: #FA3534;
      font-size: 40rpx !important;
    }

    .custom-icon-choose {
      font-size: 40rpx !important;
    }

    .u-tag {
      font-size: 22rpx !important;
      padding: 8rpx 20rpx !important;
      margin-bottom: 20rpx;
    }
  }

  .big-btn1 {
    position: fixed;
    text-align: center;
    bottom: 60rpx;
    width: 100%;

    .btn {
      background: linear-gradient(145deg,#ff9000,#ff5000 77%);
      color: #FFFFFF;
      padding: 20rpx;
      border-radius: 40rpx;
      margin: 0 30rpx;
    }
  }
</style>