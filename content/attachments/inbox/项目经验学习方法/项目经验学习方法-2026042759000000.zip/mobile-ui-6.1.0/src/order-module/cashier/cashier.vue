<template>
  <view class="cashier-wrap">
    <view class="order-price-view">
      <view class="u-flex-col u-col-center">
        <custom-price class="u-margin-top-30" :price="order.need_pay_price" :size="60" :fontWeight="400">
        </custom-price>
        <view>
          <text class="times-title">{{order.enterprise_id ? '采购申请审核' : '支付'}}剩余时间</text>
          <u-count-down :timestamp="cancel_left_time" :show-days="false"></u-count-down>
        </view>
      </view>
    </view>

    <view class="payment-view u-margin-top-30" v-if="!order.enterprise_id">
      <view class="u-p-25">
        <u-checkbox
          v-model="isCheckPreDeposit"
          :disabled="!(account_balance > 0)"
          active-color="#FA3534"
          shape="square"
        >
          <view class="u-m-l-10 u-font-24">
            <view style="display: flex; flex-direction: row; flex-wrap: wrap;">
              <text>使用预存款支付（预存款余额</text><!--{{ account_balance | unitPrice }}-->
              <custom-price :price="account_balance" :size="24"></custom-price>
              <text>，目前还需在线支付</text><!--{{ order.need_pay_price | unitPrice }}-->
              <custom-price :price="order.need_pay_price" :size="24"></custom-price>）
              <text>余额不足？</text>
            </view>
            <text @click="handleRecharge">马上充值</text>
          </view>
        </u-checkbox>
        <view class="" v-if="isCheckPreDeposit">
          <u-message-input
            active-color="#FA3534"
            :maxlength="6"
            :dot-fill="true"
            @finish="handlePasswordFinish"
          ></u-message-input>
          <view class="tip-box">
            <view class="u-flex">
              <u-icon size="36" name="error-circle-fill"></u-icon>
              <text class="u-font-24 u-m-l-10">支付密码与用户登录密码不同，可在用户中心进行设置</text>
            </view>
            <navigator class="tip" url="/mine-module/account-safe" v-if="!order.deposite.is_pwd">您还未设置支付密码?
            </navigator>
            <navigator class="tip" url="/mine-module/account-safe" v-else>忘记密码?</navigator>
          </view>
        </view>
      </view>
    </view>

    <view class="payment-view u-margin-top-30" v-if="!order.enterprise_id">
      <view
        v-for="(pay, index) in paymentList"
        :key="index"
        class="u-flex u-row-between u-p-25"
        :class="index > 0 ? 'cell-view' : '' "
        @click="handlePaymentType(pay.plugin_id)"
      >
        <view class="cell-icon">
          <u-image width="200" height="60" :src="pay.image"></u-image>
        </view>
        <view class="cell-title">
          {{ pay.platform_name }}
        </view>
        <view class="cell-right-icon">
          <u-icon :name="pay.selected ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
        </view>
      </view>
    </view>

    <view class="big-btn">
      <view @click="handlePayment" v-if="!isCheckPreDeposit && !order.enterprise_id">
        <view class="btn u-flex u-row-center">
          确认支付
          <custom-price :price="order.need_pay_price" :textColor="'#FFFFFF'"></custom-price>
        </view>
      </view>
      


      <!-- 平台客服icon -->
      <view class="fixed-icon" @click="handleToChat">
          <u-icon name="server-man" size="60" color="#333" />
          <text class="server-tips">联系平台</text>
      </view>
    </view>

    <!-- #ifdef H5 -->
    <div class="__pay_form__"></div>
    <!-- #endif -->
    <view v-if="debug">{{ log }}</view>
    <!-- 进入加载 -->
    <loading-view v-if="loading"></loading-view>
    <!-- #ifdef H5 -->
    <stripe-popup v-if="stripeSupported" ref="stripePopup" />
    <!-- #endif -->
    <!-- #ifdef MP-WEIXIN -->
    <u-modal
      v-model="subscribeModalShow"
      title="提示"
      content="是否开启订单相关消息提醒"
      show-cancel-button
      cancel-text="取消"
      confirm-text="订阅"
      @cancel="pushWxSubscribe(false)"
      @confirm="pushWxSubscribe(true)"
    />
    <!-- #endif -->
  </view>
</template>

<script>
import * as API_Trade from '@/api/trade'
import * as API_Common from '@/api/common'
import * as Payment from '@/common/payment'
import * as API_Deposit from '@/api/deposit'
import * as Openid from '@/api/openid'
import * as API_Order from '@/api/order'
import Cache, { Keys } from '@/utils/cache'
import { huiFuPay } from '@/config/config'
// #ifdef H5
import StripePopup from '@/components/stripe-popup/stripe-popup'
// #endif

export default {
  components: {
    // #ifdef H5
    StripePopup,
    // #endif
  },
  data() {
    return {
      debug: false, //在app里显示调试日志
      openid: '',
      code: '',
      log: 'log',
      trade_sn: '',
      order_sn: '', //订单编号
      //订单详情
      order: {
        need_pay_price: '--'
      },
      is_callback: '', //是否是支付跳转回来的，如果为yes，表示是跳转回来的
      default_plugin_id: '', //默认要选中的支付方式
      paymentList: [], //支付方式列表
      payment_plugin_id: '', //支付方式
      cancel_left_time: '', //剩余支付时间
      account_balance: 0, //预存款余额
      isCheckPreDeposit: false, //是否使用预存款支付
      loading: true,
      noClick: true, //禁止多次点击
      queryPaymentStatusUrl: '',
      openHuiFuPay: huiFuPay,
      stripeSupported: false,
      subscribeModalShow: false,
      subscribeTmplIds: null
    }
  },
  onLoad(options) {
    this.trade_sn = options.trade_sn || ''
    this.order_sn = options.order_sn || ''
    this.is_callback = options.is_callback || ''
    this.default_plugin_id = options.default_plugin_id || ''
    this.openid = Cache.getItem(Keys.wxopenid)

    if (this.is_callback === 'yes') {
      this.payCallback()
    }

    // #ifdef APP-PLUS
    this.openid = 'appopenid'
    // #endif

    // #ifdef H5
    this.code = options.code || ''
    // #endif

    this.loadPaymentList()
    this.getCancelLeftTime()
  },
  onShow() {
    if (this.openHuiFuPay && this.queryPaymentStatusUrl) {
      this.queryPaymentStatus()
    }
  },
  watch: {
    isCheckPreDeposit(val) {
      if (!val) return
      this.paymentList.forEach(item => {
        item.selected = false
      })
    }
  },
  computed: {
    isWechat() {
      let isWechat = false
      // #ifdef H5
      isWechat = navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1
      // #endif
      return isWechat
    }
  },
  methods: {
    handleToChat() {
      let url = '/chat-module/chat'
      url += '?receiver_id=0'
      url += `&receiver_name=${encodeURIComponent('平台')}`
      uni.navigateTo({ url })
    },
    // 获取订单取消剩余时间
    getCancelLeftTime() {
      const trade_type = this.trade_sn ? 'TRADE' : 'ORDER'
      const sn = this.trade_sn || this.order_sn
      API_Trade.getCancelLeftTime(trade_type, sn).then(response => {
        this.cancel_left_time = response
        this.loading = false
      })
    },
    
    //马上充值
    handleRecharge() {
      uni.navigateTo({
        url: "/mine-module/account-balance"
      })
    },
    //支付密码输入结束
    handlePasswordFinish(password) {
      const trade_type = this.trade_sn ? 'TRADE' : 'ORDER'
      const sn = this.trade_sn || this.order_sn
      const params = { sn, trade_type, password }
      API_Deposit.getBalancePay(trade_type, sn, params).then(async response => {
        uni.hideKeyboard()
        if (Number(response.need_pay) === 0) {
          // #ifdef MP-WEIXIN
          await this.getSubscribeTmpIds()
          this.subscribeModalShow = true
          // #endif
          // #ifndef MP-WEIXIN
          uni.redirectTo({ url: '/order-module/payment-complete/payment-complete' })
          // #endif
        } else {
          this.isCheckPreDeposit = false
          this.loadPaymentList()
        }
      })
    },
    loadMiniOpenId() {
      if (!this.openid) {
        Openid.fetchWeixinMiniOpenId().then(openid => {
          this.openid = openid
          this.initiatePay()
        }).catch(e => {
          return this.$u.toast(`获取openid出现意外错误`)
        })
      } else {
        this.initiatePay()
      }
    },
    loadH5OpenId(code) {
      // 非微信内部，跳过获取openid
      if (!this.isWechat) {
        this.openid = 'h5openid'
      }
      if (!this.openid) {
        if (code === '') {
          Openid.createRedirectUri().then(url => {
            location.href = url
          })
        } else {
          Openid.fetchWeiXinH5OpenId(code).then(openid => {
            this.openid = openid
            this.initiatePay()
          }).catch(e => {
            return this.$u.toast(`获取openid出现意外错误`)
          })
        }
      } else {
        this.initiatePay()
      }
    },
    loadPaymentList() {
        let isWechat = false
        // #ifdef H5
        isWechat = navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1
        // #endif
        let client_type = ''
        // #ifdef APP-PLUS
        client_type = 'APP'
        // #endif
        // #ifdef H5
        client_type = 'H5'
        //如果微信内则传递 WECHAT_H5
        if (isWechat) {
            client_type = 'WECHAT_H5'
        }
        // #endif
        // #ifdef MP
        client_type = 'MINI'
        // #endif
      Promise.all([
        this.trade_sn ?
          API_Trade.getCashierData({ trade_sn: this.trade_sn }) :
          API_Trade.getCashierData({ order_sn: this.order_sn }),
        API_Trade.getPaymentList(client_type),
        API_Deposit.getDepositBalance()
      ]).then(response => {
        this.order = response[0]
        this.account_balance = response[2]
        if (response[1] && response[1].length) {
          let paymentList = response[1]
          // 默认不选中支付方式
          paymentList.forEach(item => {
            item.selected = false
            //如果传递了default_plugin_id则选中此支付方式
            if (item.plugin_id === this.default_plugin_id) {
              item.selected = true
              this.payment_plugin_id = item.plugin_id
            }
          })
          // #ifdef H5
          if (paymentList.find(item => item.plugin_id === 'stripePlugin')) {
            this.stripeSupported = true
            this.$nextTick(() => {
              this.$refs['stripePopup'].loadStripeScriptAndKey()
            })
          }
          // #endif

          // #ifndef MP-WEIXIN
          // 如果是在微信浏览器内则隐藏支付宝支付
          if (this.isWechat) {
            paymentList = paymentList.filter(item => item.plugin_id !== 'alipayDirectPlugin')
          }
          // #endif

          // 如果是在小程序内则隐藏支付宝支付
          // #ifdef MP-WEIXIN
          paymentList = paymentList.filter(item => item.plugin_id !== 'alipayDirectPlugin')
          // #endif

          if (!this.default_plugin_id && paymentList.length === 1) {
            paymentList[0].selected = true
            this.payment_plugin_id = paymentList[0].plugin_id
          }
          this.paymentList = paymentList
        }
      })
    },
    //选择支付方式
    handlePaymentType(plugin_id) {
      this.paymentList.forEach(item => {
        item.selected = item.plugin_id === plugin_id
      })
      this.payment_plugin_id = plugin_id
    },
    // #ifdef MP-WEIXIN
    // 发起订阅授权
    async pushWxSubscribe(confirm = true) {
      if (!confirm) {
        uni.redirectTo({ url: '/order-module/payment-complete/payment-complete' })
        return
      }
      if (!this.subscribeTmplIds) return
      uni.requestSubscribeMessage({
        tmplIds: this.subscribeTmplIds,
        fail: err => {
          console.log('requestSubscribeMessage:err: ', err)
        },
        complete: () => {
          uni.redirectTo({ url: '/order-module/payment-complete/payment-complete' })
        }
      })
    },
    // 获取订阅消息模板id集合
    async getSubscribeTmpIds() {
      uni.showLoading({ title: '请稍候...', mask: true })
      const data_type = this.trade_sn ? 0 : 1
      const sn = this.trade_sn || this.order_sn
      this.subscribeTmplIds = await API_Order.getWechatListTmpId(data_type, sn)
    },
    // #endif
    async payCallback() {
      // #ifdef MP-WEIXIN
      await this.getSubscribeTmpIds()
      this.pushWxSubscribe()
      // #endif
      // #ifndef MP-WEIXIN
      uni.redirectTo({ url: '/order-module/payment-complete/payment-complete' })
      // #endif
    },
    payFail(err) {
      if (this.debug) {
        this.log = 'fail:' + JSON.stringify(err)
      }
    },
    // 确定支付
    handlePayment() {
      // #ifdef H5
      if (this.payment_plugin_id === 'wechatPayPlugin') {
        this.loadH5OpenId(this.code)
      } else {
        this.initiatePay()
      }
      // await this.$u.throttle(this.loadH5OpenId(this.code), 2000)
      // #endif

      // #ifdef MP-WEIXIN
      this.$u.throttle(this.loadMiniOpenId(), 2000)
      // #endif

      // #ifdef APP-PLUS
      this.initiatePay()
      // #endif
    },
    async initiatePay() {
      if (!this.paymentList.some(item => item.selected)) {
        this.$u.toast(`请选择支付方式`)
        return
      }
      const trade_type = this.trade_sn ? 'trade' : 'order'
      const sn = this.trade_sn || this.order_sn
      const openid = this.openid
      const goods_desc = this.order.goods_desc
      let isWechat = false
      // #ifdef H5
      isWechat = navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1
      // #endif
      let client_type = ''
      // #ifdef APP-PLUS
      client_type = 'APP'
      // #endif
      // #ifdef H5
      client_type = 'H5'
      //如果微信内则传递 WECHAT_H5
      if (isWechat) {
        client_type = 'WECHAT_H5'
      }
      // #endif
      // #ifdef MP
      client_type = 'MINI'
      // #endif
      const pay_mode = 'normal'
      const payment_plugin_id = this.payment_plugin_id

      let uni_app = ''
      // #ifdef H5
      uni_app = 'H5'
      // #endif
      // #ifndef H5
      uni_app = 'UNH5'
      // #endif

      uni.showLoading({ title: '加载中...', mask: true })
      try {
        const response = await API_Trade.initiatePay(trade_type, sn, {
          client_type,
          pay_mode,
          uni_app,
          payment_plugin_id,
          openid,
          goods_desc
        })
        if (payment_plugin_id === 'wechatPayPlugin') {
          // 微信内嵌H5，调用wechatH5Pay方法
          // #ifdef H5
          console.log(response)
          if (typeof WeixinJSBridge == 'undefined') {
            const redirect_url = encodeURIComponent(`${location.href}&is_callback=yes`)
            Payment.mobileH5Pay(response, redirect_url)
          } else {
            if (this.openHuiFuPay) {
              const payInfo = JSON.parse(response.expend.pay_info)
              Payment.wechatH5Pay(payInfo, this.payCallback, this.payFail)
            } else {
              Payment.wechatH5Pay(response, this.payCallback, this.payFail)
            }
          }
          // #endif

          // 微信小程序，调用wechatMiniPay方法
          // #ifdef MP-WEIXIN
          if (this.openHuiFuPay) {
            const payInfo = JSON.parse(response.expend.pay_info)
            Payment.wechatMiniPay(payInfo, this.payCallback, this.payFail)
          } else {
            Payment.wechatMiniPay(response, this.payCallback, this.payFail)
          }
          // #endif

          //微信App
          // #ifdef APP-PLUS
          console.log('调用微信APP支付')
          Payment.wechatAppPay(response, this.payCallback, this.payFail)
          // #endif

          return
        }
        // #ifdef H5
        if (payment_plugin_id === 'stripePlugin') {
          this.$refs['stripePopup'].show(response)
          return
        }
        if (this.openHuiFuPay) {
          if (payment_plugin_id === 'unionYunPlugin') {
            // H5银联支付
            document.write(response.expend.form_html)
          } else if (payment_plugin_id === 'alipayDirectPlugin') {
            // 调起支付宝支付
            this.queryPaymentStatusUrl = response.query_url
            window.location.href = response.expend.pay_info
          }
        } else {
          // 调起支付宝支付
          Payment.aliPayH5(response, this.payCallback, this.payFail)
        }
        // #endif

        // #ifdef APP-PLUS
        if (payment_plugin_id === 'stripePlugin') {
          const stripeKey = await API_Common.getStripeKey()
          Payment.stripePayApp(response, stripeKey, this.payCallback, this.payFail)
        } else {
          Payment.aliPayApp(response, this.payCallback, this.payFail)
        }
        // #endif
      } finally {
        uni.hideLoading()
      }
    },
    // 查询支付状态
    queryPaymentStatus() {
      uni.showLoading({ title: '请稍候', mask: true })
      uni.request({
        url: this.queryPaymentStatusUrl,
        success: (result) => {
          const { status } = result.data
          if (status === 'successed') {
            uni.showModal({
              title: '提示',
              content: '支付成功！',
              showCancel: false,
              confirmText: '查看订单列表',
              success: () => {
                uni.redirectTo({ url: '/order-module/order/order-list' })
              }
            })
          } else if (status === 'failed') {
            uni.showModal({
              title: '提示',
              content: '支付失败！',
              showCancel: false,
              confirmText: '重新支付'
            })
          } else {
            uni.showModal({
              title: '提示',
              content: '支付成功了吗？',
              cancelText: '重新支付',
              confirmText: '查看订单列表',
              success: (result) => {
                if (result.confirm) {
                  uni.redirectTo({ url: '/order-module/order/order-list' })
                }
              }
            })
          }
        },
        complete: () => {
          uni.hideLoading()
        }
      })
    }
  }
}
</script>

<style lang="scss">
.big-btn {
  position: relative;
  .fixed-icon {
    position: absolute;
    bottom: -150rpx;
    right: 30rpx;
    background: #fff;
    width: 100rpx;
    height: 100rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: .7;
    box-shadow: 0 0rpx 8rpx rgba(0,0,0,0.3);
    .server-tips {
        font-size: 24rpx;
        text-align: right;
        position: absolute;
        bottom: -65rpx;
        right: 0;
    }
  }
}
.order-price-view {
  background-color: #FFFFFF;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 50rpx;
  text-align: center;
  .order-price {
    font-size: 45rpx;
    color: #FA3534;
    font-weight: bold;
  }
  .times-title {
    margin: 0 10rpx;
  }
}
.payment-view {
  margin: 20rpx;
  border-radius: 20rpx;
  background-color: #FFFFFF;
  .cell-view {
    border-top: 2rpx solid #E5E5E5;
  }
  .cell-icon {
    padding: 10rpx 0rpx;
  }
  .cell-title {
    text-align: right;
    flex: 1;
    margin: 0 20rpx;
    font-size: 30rpx;
    font-weight: bold;
  }
}
.tip-box {
  padding-left: 20rpx;
  margin-top: 20rpx;
  color: #ffcc00;
  .tip {
    display: inline-block;
    background-color: #F59C1A;
    border-color: #F59C1A;
    color: #FFF;
    padding: 8rpx 16rpx;
    border-radius: 10rpx;
    margin: 20rpx 0 0 10rpx;
    font-size: 24rpx;
  }
}
::v-deep {
  .custom-icon-xuanze {
    color: #FA3534;
    font-size: 40rpx !important;
  }
  .custom-icon-choose {
    font-size: 40rpx !important;
  }
}
</style>
