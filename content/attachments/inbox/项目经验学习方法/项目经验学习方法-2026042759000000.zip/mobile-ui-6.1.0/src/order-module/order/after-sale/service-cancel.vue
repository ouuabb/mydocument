<template>
  <view>
    <view>
      <u-alert-tips type="warning" :title="title" :description="description"></u-alert-tips>
    </view>
    <view v-for="sku in orderDetail.order_sku_list" :key="sku.sku_id" class="goods-view">
      <view>
        <goods-info
          :goodsPrice="sku.purchase_price"
          :goodsName="sku.name"
          :goodsImg="sku.goods_image"
          :goodsSpecList="sku.spec_list"
          :goodsNum="sku.num"
          :goodsPoint="sku.point">
        </goods-info>
      </view>
    </view>
    <view class="block-view">
      <view class="u-flex u-row-between" v-if="refundShow">
        <view>退款方式</view>
        <view v-if="isRetrace">原路退回</view>
        <view v-else>账号退款</view>
      </view>
      <u-line margin="20rpx 0rpx"></u-line>
      <view class="u-flex u-row-between">
        <view>退款金额</view>
        <view>
          <u-input v-model="orderDetail.order_price" :disabled="true" input-align="right"></u-input>
        </view>
      </view>
      <template v-if="orderDetail.paid_point && orderDetail.paid_point > 0">
        <u-line margin="20rpx 0rpx"></u-line>
        <view class="u-flex u-row-between">
          <view>退还积分</view>
          <view>
            {{ orderDetail.paid_point }}
          </view>
        </view>
      </template>
      <u-line margin="20rpx 0rpx"></u-line>
      <view class="u-flex u-row-between">
        <view>取消原因</view>
        <view @click="reasonShow = true">
          <text>{{ form.refund_reason }}</text>
          <u-icon class="u-margin-left-20" name="more-dot-fill"></u-icon>
        </view>
      </view>
      <u-line margin="20rpx 0rpx"></u-line>
      <template v-if="!isRetrace && refundShow">
        <view class="u-flex u-row-between">
          <view>账号类型</view>
          <view @click="alterSaleWayShow = true">
            <text>{{ form.account_type_str }}</text>
            <u-icon class="u-margin-left-20" name="more-dot-fill"></u-icon>
          </view>
        </view>
        <u-line margin="20rpx 0rpx"
                v-if="form.account_type != 'BANKTRANSFER' && form.account_type !== 'BALANCE' && refundShow"></u-line>
        <view class="u-flex u-row-between"
              v-if="form.account_type != 'BANKTRANSFER' && form.account_type !== 'BALANCE'">
          <view>退款账号</view>
          <view>
            <u-input v-model="form.return_account" input-align="right" placeholder="请输入退款账号"></u-input>
          </view>
        </view>
        <u-line margin="20rpx 0rpx" v-if="form.account_type == 'BANKTRANSFER' && refundShow"></u-line>
        <view v-if="form.account_type == 'BANKTRANSFER'">
          <view class="u-flex u-row-between">
            <view>银行名称</view>
            <view>
              <u-input v-model="form.bank_name" input-align="right" placeholder="请输入银行名称"></u-input>
            </view>
          </view>
          <u-line margin="20rpx 0rpx"></u-line>
          <view class="u-flex u-row-between">
            <view>银行账号</view>
            <view>
              <u-input v-model="form.bank_account_number" input-align="right" placeholder="请输入银行账号"></u-input>
            </view>
          </view>
          <u-line margin="20rpx 0rpx"></u-line>
          <view class="u-flex u-row-between">
            <view>银行开户名</view>
            <view>
              <u-input v-model="form.bank_account_name" input-align="right" placeholder="请输入银行开户名"></u-input>
            </view>
          </view>
          <u-line margin="20rpx 0rpx"></u-line>
          <view class="u-flex u-row-between">
            <view>银行开户行</view>
            <view>
              <u-input v-model="form.bank_deposit_name" input-align="right" placeholder="请输入银行开户行"></u-input>
            </view>
          </view>
        </view>
        <u-line margin="20rpx 0rpx"></u-line>
      </template>
      <view class="u-flex u-row-between">
        <view>联系方式</view>
        <view class="u-flex">
          <area-select
            ref="areaSelect"
            :areaCode="form.areaCode"/>
          <u-input
            style="width: 240rpx"
            v-model="form.mobile"
            input-align="right"
            placeholder="请输入联系方式"></u-input>
        </view>
      </view>
    </view>

    <view class="btn-view">
      <u-button type="error" shape="circle" @click="onSubmit">提交</u-button>
    </view>

    <u-popup class="block-popup" v-model="reasonShow" mode="bottom" length="80%">
      <view class="header">
        取消订单
      </view>
      <view class="body">
        <view class="title">
          请选择申请原因（必选）：
        </view>
        <u-radio-group v-model="form.refund_reason">
          <view class="value">
            <view v-for="(item, index) in reasonList" :key="index" class="radio-view">
              <u-radio active-color="red" label-size="31" shape="circle" :name="item.name" @change="reasonChange">
                {{ item.name }}
              </u-radio>
            </view>
          </view>
        </u-radio-group>
      </view>
    </u-popup>
    <u-select v-model="alterSaleWayShow" :list="alterSaleWayList" @confirm="alterSaleWayChange"></u-select>
    <u-toast ref="uToast"/>
    <!-- #ifdef MP-WEIXIN -->
    <u-modal
      v-model="subscribeModalShow"
      title="提示"
      content="是否开启订单/物流相关消息提醒"
      show-cancel-button
      cancel-text="取消"
      confirm-text="订阅"
      @cancel="pushWxSubscribe(false)"
      @confirm="pushWxSubscribe(true)"
    />
    <!-- #endif -->
  </view>
</template>

<script>

import * as API_Order from '@/api/order'
import * as API_AfterSale from '@/api/after-sale'
import areaSelect from '@/components/areaSelect/areaSelect'
import { Foundation } from '@/app-utils'

export default {
  components: { areaSelect },
  data() {
    return {
      orderDetail: {},
      title: '温馨提示：',
      description: '订单取消后无法恢复',
      alterSaleWayList: [{
        value: 'ALIPAY',
        label: '支付宝'
      }, {
        value: 'WEIXINPAY',
        label: '微信'
      }, {
        value: 'BANKTRANSFER',
        label: '银行转账'
      }, {
        value: 'BALANCE',
        label: '预存款'
      }],
      alterSaleWayShow: false,
      reasonShow: false,
      isRetrace: true, //是否支持原路退款
      refundShow: true,
      reasonList: [
        { name: '商品质量有问题', disabled: false },
        { name: '收到商品与描述不符', disabled: false },
        { name: '不喜欢/不想要', disabled: false },
        { name: '发票问题', disabled: false },
        { name: '空包裹', disabled: false },
        { name: '快递无记录', disabled: false },
        { name: '快递一直没有收到', disabled: false },
        { name: '买错/不想要', disabled: false },
        { name: '未按照时间发货', disabled: false },
        { name: '其他', disabled: false }
      ],
      form: {
        order_sn: '',
        refund_reason: '请选择申请原因',  //申请售后原因
        account_type: 'ALIPAY',   //账户类型（退款方式）
        account_type_str: '支付宝',   //账户类型（退款方式）
        refuse_type: '',     //退款/退货
        refund_sn: '',        //退货单号
        return_num: 1,      //退货数量
        return_money: 0,    //申请金额
        return_account: '', //退款账号
        refund_price: 0.00, //退款金额
        customer_remark: '',//备注
        sku_id: 0,
        mobile: '',
        //账号类型为 BANKTRANSFER 必要的参数
        bank_name: '',      //银行名称
        bank_account_number: '',    //银行账号
        bank_account_name: '',      //银行开户名
        bank_deposit_name: ''      //银行开户行
      },
      subscribeModalShow: false,
      subscribeTmplIds: null
    }
  },
  onLoad(options) {
    this.form.order_sn = options.order_sn
    this.loadData()
  },
  methods: {
    alterSaleWayChange(e) {
      this.form.account_type = e[0].value
      this.form.account_type_str = e[0].label
    },
    loadData() {
      API_Order.getOrderDetail(this.form.order_sn).then(res => {
        this.orderDetail = res
        this.isRetrace = res.is_retrace
        const { mobileValue, areaCode } = Foundation.formatIn18Mobile(res.ship_mobile)
        this.form.areaCode = areaCode
        this.form.mobile = mobileValue
        this.refundShow = res.order_price > 0 ? true : false
      })
    },
    reasonChange(reason) {
      this.form.refund_reason = reason
      this.reasonShow = false
    },
    /** 校验参数 */
    handleCheckParams() {
      // 取消原因校验
      if (!this.form.refund_reason || this.form.refund_reason === '请选择申请原因') {
        this.$u.toast('请选择申请原因！')
        return
      }
      const { mobile_regex, formatValid } = this.$refs.areaSelect
      const mobileReg = new RegExp(mobile_regex)
      if (!mobileReg.test(formatValid(this.form.mobile))) {
        this.$u.toast('请输入正确格式的手机号码！')
        return
      }

      // 如果不支持原路退款
      if (!this.isRetrace && this.refundShow) {
        // 账户类型校验
        if (!this.form.account_type) {
          this.$u.toast('请选择账户类型！')
          return
        }

        // 如果账户类型不为银行卡
        if (this.form.account_type != 'BANKTRANSFER' && this.form.account_type != 'BALANCE') {
          // 退款账号校验
          if (!this.form.return_account) {
            this.$u.toast('请输入退款账号！')
            return
          }
        } else if (this.form.account_type == 'BANKTRANSFER') {
          // 银行名称校验
          if (!this.form.bank_name) {
            this.$u.toast('请输入银行名称！')
            return
          }
          // 银行开户行校验
          if (!this.form.bank_deposit_name) {
            this.$u.toast('请输入银行开户行！')
            return
          }
          // 银行开户名校验
          if (!this.form.bank_account_name) {
            this.$u.toast('请输入银行开户名！')
            return
          }
          // 银行账号校验
          if (!this.form.bank_account_number) {
            this.$u.toast('请输入银行账号！')
            return
          }
        }
      }

      return true
    },
    async onSubmit() {
      // 校验参数
      if (!this.handleCheckParams()) return
      const { mobileValue } = this.$refs.areaSelect
      const { form, orderDetail } = this
      const _params = {
        reason: form.refund_reason,
        mobile: mobileValue(form.mobile),
        account_type: form.account_type,
        return_account: form.return_account,
        refund_price: orderDetail.order_price,
        order_sn: form.order_sn
      }
      uni.showLoading({ title: '请稍候...', mask: true })
      await API_AfterSale.applyAfterSaleCancel(_params)
      this.$u.toast('提交成功')
      // #ifdef MP-WEIXIN
      await this.getSubscribeTmpIds()
      this.subscribeModalShow = true
      // #endif
      // #ifndef MP-WEIXIN
      setTimeout(() => {
        uni.navigateBack()
        uni.$emit('back')
      }, 1500)
      // #endif
    },
    // #ifdef MP-WEIXIN
    // 发起订阅授权
    async pushWxSubscribe(confirm = true) {
      if (!confirm) {
        uni.navigateTo({ url: '/order-module/order/after-sale/after-sale' })
        return
      }
      if (!this.subscribeTmplIds) return
      uni.requestSubscribeMessage({
        tmplIds: this.subscribeTmplIds,
        fail: err => {
          console.log('requestSubscribeMessage:err: ', err)
        },
        complete: () => {
          uni.navigateTo({ url: '/order-module/order/after-sale/after-sale' })
        }
      })
    },
    // 获取订阅消息模板id集合
    async getSubscribeTmpIds() {
      uni.showLoading({ title: '请稍候...', mask: true })
      const data_type = this.trade_sn ? 0 : 1
      const sn = this.trade_sn || this.order_sn
      this.subscribeTmplIds = await API_Order.getWechatListTmpId(data_type, sn)
    },
    // #endif
  }
}
</script>

<style lang="scss">
.goods-view {
  background-color: #ffffff;
  padding: 15rpx;
  border-radius: 0rpx 0rpx 10rpx 10rpx;
}
.cell-view {
  margin: 10rpx 20rpx;
  background-color: #ffffff;
  padding: 10rpx;
  border-radius: 8rpx;
}
.block-view {
  background-color: #ffffff;
  padding: 30rpx;
  border-radius: 10rpx;
  margin: 15rpx 0rpx;
}
.btn-view {
  padding: 0rpx 30rpx;
  margin-top: 60rpx;
}
.block-popup {
  .header {
    padding: 20rpx;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    font-weight: 600;
  }
  .body {
    padding: 20rpx 30rpx;
    .title {
      font-weight: 600;
    }
    .value {
      display: flex;
      flex-direction: column;
      .radio-view {
        margin: 10rpx 0rpx;
      }
    }
  }
  .footer {
    padding: 0rpx 20rpx;
  }
}
</style>
