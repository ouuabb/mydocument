<template>
  <loading-view v-if="loading"></loading-view>
  <view v-else-if="order">
    <view class="order-status-view">
      <view class="status-text-view">
        <view>
          <u-icon class="u-margin-right-10" size="36" :name="order.order_operate_allowable_vo.allow_pay
              || order.order_operate_allowable_vo.allow_ship
              || order.order_operate_allowable_vo.allow_rog ? 'clock' : 'checkmark-circle'">
          </u-icon>
        </view>
        <view>
          {{ order.order_type === 'PINTUAN' ? order.ping_tuan_status : order.order_status_text }}
        </view>
      </view>
      <view class="sub-text-view">
        <view @click="assembleDetail(order)" class="sub-text"
          v-if="order.order_status !== 'CONFIRM' && order.order_status !== 'CANCELLED' && order.order_type === 'PINTUAN'">
          查看拼团详情>>
        </view>
        <view class="sub-text" v-if="order.order_operate_allowable_vo.allow_pay">需付款{{ order.need_pay_money }}</view>
        <view class="sub-text" v-if="order.order_operate_allowable_vo.allow_ship && !isVirtualOrder">等待商家发货</view>
        <view class="sub-text" v-if="order.order_operate_allowable_vo.allow_rog">等待您确认收货</view>
      </view>
    </view>
    <view v-if="order.order_operate_allowable_vo.allow_check_express" class="block-view">
      <view v-for="(item, index) in express" :key="index" class="express-item u-flex u-row-between" @click="onExpress(item)">
        <view class="u-flex">
          <view>
            <u-image class="u-margin-left-30" width="45rpx" height="45rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/truck.png"></u-image>
          </view>
          <view class="express-text">
            <template v-if="item">
              <view class="u-line-2 text">{{ item.logistics_name }}</view>
              <view class="time">{{ item.delivery_sn }}</view>
            </template>
            <template v-else class="u-line-2 text">暂无物流信息，请您耐心等待~</template>
          </view>
        </view>
        <view>
          <u-icon color="#909399" name="arrow-right"></u-icon>
        </view>
      </view>
    </view>
    <view v-if="!isVirtualOrder" class="block-view">
      <addr
        left_icon="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/address.png"
        :name="order.ship_name"
        :mobile="order.ship_mobile"
        :addrs="MixinFormatRegions(order, 'ship_')"
        :addr="order.ship_addr"
      >
      </addr>
    </view>
    <view v-if="order" class="u-margin-bottom-20">
      <view class="order-list-view">
        <view class="order-header">
          <view class="order-sn">
            <text>商品列表</text>
          </view>
        </view>
        <view v-for="sku in order.order_sku_list" :key="sku.sku_id" class="goods-list-view" @click="onGoods(sku)">
          <goods-info :goodsType="order.order_type" :goodsName="sku.name" :goodsNum="sku.num"
            :goodsPrice="sku.original_price" :goodsImg="sku.goods_image" :goodsSpecList="sku.spec_list"
            :goodsPromotion="sku.promotion_tags" :goodsInfo="sku">
          </goods-info>
          <view class="u-flex u-row-right u-margin-bottom-10">
            <view class="u-flex">
              <template v-if="sku.write_off_btn && order.pay_status === 'PAY_YES' && order.order_status !== 'CANCELLED'">
                <u-button
                  v-if="!sku.use_redeem"
                  class="btn"
                  size="mini"
                  shape="circle"
                  @click="showQrCode(sku)"
                >查看兑换码</u-button>
                <view v-else @click.stop="">
                  <u-button disabled class="btn" size="mini" shape="circle">已核销</u-button>
                </view>
              </template>
              <view @click.stop="">
                <u-button disabled class="btn" size="mini" v-if="sku.complain_status === 'APPLYING'"
                  shape="circle">投诉申请中</u-button>
                <u-button disabled class="btn" size="mini" v-if="sku.complain_status === 'EXPIRED'"
                  shape="circle">投诉已失效</u-button>
              </view>
              <u-button class="btn"
                v-if="order.pay_status === 'PAY_YES' && sku.goods_operate_allowable_vo.allow_order_complain && sku.complain_status === 'NO_APPLY' || sku.complain_status === 'COMPLETE'"
                size="mini" shape="circle" @click="complaintApply(sku.sku_id)">交易投诉</u-button>
              <u-button class="btn"
                v-if="sku.goods_operate_allowable_vo.allow_apply_service && order.order_type !== 'VIRTUAL'" size="mini"
                shape="circle" @click="applySale(sku)">申请售后</u-button>
            </view>
          </view>
        </view>
      </view>
    </view>
    <view class="u-margin-bottom-20" v-if="giftList.length">
      <view class="order-gift-view">
        <view class="gift-header">
          <view class="gift-title">
            <text>赠品列表</text>
          </view>
        </view>
        <view class="gift-list-view" v-for="(gift, giftIndex) in giftList" :key="giftIndex" v-if="gift.meta_key === 'GIFT_POINT'">
          <view class="gift-img-view">
            <u-image border-radius="10" width="120rpx" height="120rpx"
              src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-color-point.png"></u-image>
          </view>
          <view class="gift-info-view">
            <view class="u-line-2">
              满优惠赠送<text class="gift-coupon-price">{{ gift.meta_value }}</text>积分
            </view>
          </view>
        </view>
        <view class="gift-list-view" v-else-if="gift.meta_key === 'FREE_FREIGHT'">
          <view class="gift-img-view">
            <u-image border-radius="10" width="120rpx" height="120rpx"
                     src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/baoyou.png"></u-image>
          </view>
          <view class="gift-info-view">
            <view class="u-line-2">
              免邮费
            </view>
          </view>
        </view>
        <view class="gift-list-view" v-else-if="gift.meta_key === 'COUPON'">
          <view class="gift-img-view">
            <u-image border-radius="10" width="120rpx" height="120rpx"
              src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-color-coupon.png"></u-image>
          </view>
          <view class="gift-info-view">
            <view class="u-line-2" style="display: flex; align-items: center;">
              满 <text class="gift-coupon-price">{{ giftCoupon.couponThresholdPrice }}</text> 赠送价值<text
                class="gift-coupon-price"><!--{{ giftCoupon.couponPrice | unitPrice }}--><custom-price :price="giftCoupon.couponPrice" :size="23"></custom-price></text>的优惠券
            </view>
          </view>
        </view>
        <view class="gift-list-view" v-else>
          <view class="gift-img-view">
            <u-image border-radius="10" width="120rpx" height="120rpx" :src="giftGoods.giftImg"></u-image>
          </view>
          <view class="gift-info-view">
            <view class="u-line-2">
              {{ giftGoods.giftName }}
            </view>
          </view>
          <view class="gift-price-view">
            <custom-price :price="giftGoods.giftPrice" :fontWeight="600" size="30"></custom-price>
          </view>
        </view>
      </view>

    </view>
    <view class="block-view">
      <view class="block-item-view">
        <view class="title">订单编号：</view>
        <view class="value" @click="Foundation.copyText(order.sn)">
          {{ order.sn }}
          <u-icon name="file-text" />
        </view>
      </view>
      <view class="block-item-view">
        <view class="title">下单时间：</view>
        <view class="value">{{ $u.timeFormat(order.create_time, 'yyyy-mm-dd hh:MM:ss') }}</view>
      </view>
      <u-line margin="30rpx 0rpx"></u-line>
      <view class="block-item-view">
        <view class="title">支付方式：</view>
        <view class="value">{{ order.payment_type === 'COD' ? '货到付款' : '在线支付' }}</view>
      </view>
      <view class="block-item-view" v-if="order.payment_time">
        <view class="title">支付时间：</view>
        <view class="value">{{ $u.timeFormat(order.payment_time, 'yyyy-mm-dd hh:MM:ss') }}</view>
      </view>
      <view class="block-item-view" v-else-if="!order.need_pay_money">
        <view class="title">支付时间：</view>
        <view class="value">{{ $u.timeFormat(order.create_time, 'yyyy-mm-dd hh:MM:ss') }}</view>
      </view>
      <view class="block-item-view" v-else>
        <view class="title">支付状态：</view>
        <view class="value">未支付</view>
      </view>
      <view v-if="order.order_status === 'CANCELLED' && order.cancel_reason" class="block-item-view">
        <view class="title">取消原因：</view>
        <view class="value">{{ order.cancel_reason }}</view>
      </view>
      <u-line margin="30rpx 0rpx"></u-line>
      <view v-if="!isVirtualOrder" class="block-item-view">
        <view class="title">配送方式：</view>
        <view class="value">{{ order.logi_name == null ? '暂无配送方式' : order.logi_name }}</view>
      </view>
      <view class="block-item-view" v-if="order.ship_time">
        <view class="title">发货时间：</view>
        <view class="value">{{ $u.timeFormat(order.ship_time, 'yyyy-mm-dd hh:MM:ss') }}</view>
        <!-- <view class="value">{{$u.timeFormat(order.ship_time,'yyyy-mm-dd hh:MM:ss') ==null ? '未发货': $u.timeFormat(order.ship_time,'yyyy-mm-dd hh:MM:ss') }}</view> -->
      </view>
      <u-line margin="30rpx 0rpx"></u-line>
      <view class="block-item-view">
        <view class="title">订单备注：</view>
        <view class="value">{{ $u.test.isEmpty(order.remark) ? '无备注' : order.remark }}</view>
      </view>
      <view v-if="!isVirtualOrder" class="block-item-view">
        <view class="title">发票信息：</view>
        <view class="value click-color" v-if="order.receipt_history && order.receipt_history.receipt_title"
          @click="onReceipt">查看发票</view>
        <view class="value" v-else>未开发票</view>
      </view>
    </view>
    <view class="block-view">
      <view>
        <view class="block-item-space-between-view ">
          <view class="title">商品总额：</view>
          <custom-price textColor="#333333" :price="order.goods_price" fontWeight="600" :size="32"></custom-price>
        </view>
        <view class="block-item-space-between-view " v-if="order.discount_price">
          <view class="title">优惠金额：</view>
          <custom-price textColor="#333333" :price="order.discount_price" fontWeight="600" :size="32"></custom-price>
        </view>
        <view class="block-item-space-between-view " v-if="order.cash_back">
          <view class="title">返现金额：</view>
          <custom-price textColor="#333333" :price="order.cash_back" fontWeight="600" :size="32"></custom-price>
        </view>
        <view class="block-item-space-between-view " v-if="order.paid_point">
          <view class="title">积分抵扣：</view>
          <view style="font-size:32rpx;font-weight: 600;color: rgb(51, 51, 51);">
            -{{ order.paid_point }}<text style="font-size: 30rpx;">积分</text>
          </view>
        </view>
        <view v-if="!isVirtualOrder" class="block-item-space-between-view">
          <view class="title">运费：</view>
          <custom-price textColor="#333333" :price="order.shipping_price" fontWeight="600" :size="32"></custom-price>
        </view>
        <view class="block-item-space-between-view "v-for="(discountList, index) in order_discount_list" :key="index" v-if="order_discount_list">
          <view class="title">{{ discountList.promotion_name}}优惠</view>
          <custom-price textColor="#333333" :price="discountList.discount_amount" fontWeight="600" :size="32"></custom-price>
        </view>
        <view class="block-item-space-between-view " v-if="order.modify_price && order.modify_price !== 0">
          <view class="title">商家调价：</view>
          <custom-price textColor="#333333" :price="order.modify_price" fontWeight="600" :size="32"></custom-price>
        </view>
        <view class="block-item-space-between-view " v-if="order.order_price">
          <view class="title">订单总额：</view>
          <view class="value u-flex">
            <custom-price :price="order.order_price" fontWeight="600" :size="40"></custom-price>
          </view>
        </view>
        <view class="block-item-space-between-view " v-if="order.balance !== 0">
          <view class="title">预存款支付金额：</view>
          <view class="value u-flex">
            <custom-price :price="order.balance" fontWeight="600" :size="40"></custom-price>
          </view>
        </view>
      </view>
    </view>
    <u-popup v-model="receiptShow" mode="bottom" border-radius="14" length="60%">
      <view class="receipt-header u-flex u-row-center">
        发票信息
      </view>
      <view v-if="!this.$u.test.isEmpty(order.receipt_history)">
        <view class="receipt-item u-flex u-row-between">
          <view class="title">发票类型</view>
          <view class="value">{{ order.receipt_history.receipt_type | receiptType }}</view>
        </view>
        <view class="receipt-item u-flex u-row-between">
          <view class="title">发票抬头</view>
          <view class="value u-line-1">{{ order.receipt_history.receipt_title }}</view>
        </view>
        <view class="receipt-item u-flex u-row-between">
          <view class="title">发票内容</view>
          <view class="value">{{ order.receipt_history.receipt_content }}</view>
        </view>
        <view class="receipt-item u-flex u-row-between" v-if="order.receipt_history.tax_no">
          <view class="title">发票税号</view>
          <view class="value">{{ order.receipt_history.tax_no }}</view>
        </view>
      </view>
    </u-popup>
    <u-divider>到底了哦~</u-divider>
    <!-- 进入加载 -->
    <u-popup v-model="showQrCodeModal" mode="center" border-radius="20" closeable :mask="true">
      <view class="qrcode-box">
        <view class="title">查看兑换码</view>
        <view class="canvas-box" v-if="showQrCodeModal">
          <canvas canvas-id="qrcode" style="width: 100%;" />
        </view>
        <view class="code-text">{{ redeemCodeData.redeem_code }}</view>
        <view class="number-box">
          <text>总核销数：{{ redeemCodeData.total_num }}</text>
          <text>已核销数：{{ redeemCodeData.use_num }}</text>
        </view>
        <view class="code-tips">有效期至：{{ redeemCodeData.expired_time | unixToDate }}</view>
      </view>
    </u-popup>
  </view>
</template>

<script>
import * as API_Order from '@/api/order.js'
import * as API_Trade from '@/api/trade.js'
import uQRCode from '../../app-utils/uQrcode.js'
import { Foundation } from '@/app-utils/index'
import { domain } from '@/config/config'

export default {
  data() {
    return {
      Foundation,
      orderSn: '',
      order: {
        order_operate_allowable_vo: {
          allow_pay: false,
          allow_ship: false,
          allow_rog: false,
        }
      },
      order_discount_list: [],
      express: '',
      receiptShow: false,
      giftList: [],  //满赠列表
      giftListCoupon: [],  //满优惠赠送优惠券列表
      giftListGift: [],   //满优惠赠送礼品列表
      giftCoupon: '',
      giftGoods: '',
      loading: true,
      showQrCodeModal: false,
      // 当前查看商品兑换码
      redeemCodeData: {
        redeem_code: '',
        expired_time: '',
        total_num: 0,
        use_num: 0
      }
    };
  },
  onLoad(options) {
    this.orderSn = options.orderSn;
  },
  onShow() {
    this.getDetail();
  },
  computed: {
    isVirtualOrder() {
      const { order_type, order_sku_list = [] } = this.order || {}
      if (order_type === 'VIRTUAL') return true
      return order_sku_list.some(item => item.goods_type === 'VIRTUAL')
    }
  },
  filters: {
    receiptType(type) {
      switch (type) {
        case 'VATORDINARY': return '增值税普通发票'
        case 'ELECTRO': return '电子普通发票'
        case 'VATOSPECIAL': return '增值税专用发票'
        default: return '不开发票'
      }
    }
  },
  methods: {
    showQrCode(sku) {
      this.showQrCodeModal = true
      this.redeemCodeData = {
        redeem_code: sku.redeem_code,
        expired_time: sku.expired_time,
        total_num: sku.total_num,
        use_num: sku.use_num
      }
      setTimeout(() => {
        uQRCode.make({
          canvasId: 'qrcode',
          componentInstance: this,
          text: `${domain.wap}/pages/verification/verification?seller_id=${sku.seller_id}&redeem_code=${sku.redeem_code}`,
          size: 150,
          margin: 0,
          backgroundColor: '#ffffff',
          foregroundColor: '#000000',
          fileType: 'jpg',
          errorCorrectLevel: uQRCode.errorCorrectLevel.H,
          success: function () {
          }
        })
      }, 100)

    },

    /** 获取订单详情 */
    getDetail() {
      API_Order.getOrderDetail(this.orderSn).then(res => {
        const order = res
        order.order_sku_list.forEach(sku => {
          let specValues = ""
          if (sku.spec_list !== null) {
            sku.spec_list.forEach(spec => {
              specValues += spec.spec_value + ","
            })
          }
          sku.spec_value_str = specValues.slice(0, specValues.length - 1)
        })
        this.order = order
        this.loading = false
        const virtualSku = order.order_sku_list.find(item => item.goods_type === 'VIRTUAL')
        if (virtualSku && order.order_status === 'FORMED') {
          this.getOrderVirtual(order)
        }
        this.order_discount_list = order.order_discount_list;
        this.giftList = order.gift_list;
        this.giftListCoupon = this.giftList.filter(item => item.meta_key === 'COUPON')
        this.giftListGift = this.giftList.filter(item => item.meta_key === 'GIFT')
        if (this.giftListCoupon.length) {
          this.giftCoupon = JSON.parse(this.giftListCoupon[0].meta_value)[0]
        }
        if (this.giftListGift.length) {
          this.giftGoods = JSON.parse(this.giftListGift[0].meta_value)[0]
        }
        this.getExpress()
      })
    },

    /** 获取商品核销数据 */
    getOrderVirtual() {
      API_Order.getOrderVirtual(this.orderSn).then(response => {
        this.order.order_sku_list = this.order.order_sku_list.map(sku => {
          const s = response.find(item => item.sku_id === sku.sku_id)
          if (!s) return sku
          sku.write_off_btn = true
          sku.redeem_code = s.redeem_code
          sku.use_redeem = s.use_redeem
          sku.expired_time = s.expired_time
          sku.total_num = s.total_num
          sku.use_num = s.use_num
          return sku
        })
      })
    },
    //读取物流信息
    getExpress() {
      if (!this.order.order_operate_allowable_vo.allow_check_express) {
        return;
      }
      API_Trade.getShipLog(this.orderSn).then(res => {
          this.express = res;
      })
    },
    //查看商品
    onGoods(sku) {
      uni.navigateTo({
        url: '/goods-module/goods?goods_id=' + sku.goods_id,
      })
    },
    //查看物流
    onExpress(shipLog) {
      uni.navigateTo({
        url: '/order-module/order/express?logi_id=' + shipLog.logistics_id + '&ship_no=' + shipLog.delivery_sn
      })
    },
    /** 交易投诉 */
    complaintApply(skuId) {
      uni.navigateTo({
        url: `/order-module/order/complaint-apply/complaint-apply?sn=${this.orderSn}&skuId=${skuId}`
      })
    },
    //申请售后
    applySale(sku) {
      uni.navigateTo({
        url: `/order-module/order/after-sale/after-sale-select?sn=${this.orderSn}&sku_id=${sku.sku_id}`
      })
    },
    assembleDetail(order) {
      uni.navigateTo({
        url: `/order-module/order/assemble?order_sn=${this.orderSn}&pay_status=${this.order.pay_status}`
      })
    },
    //查看发票
    onReceipt() {
      this.receiptShow = true;
    }
  }
}
</script>

<style lang="scss">
.qrcode-box {
  width: 240px;
  padding: 30px 10px;

  .canvas-box {
    width: 300rpx;
    margin: 0 auto;
  }

  .title {
    color: #333;
    font-size: 14px;
    // margin-bottom: 20px;
    position: relative;
    bottom: 20px;
  }

  .number-box {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin: 10px 0;
    font-size: 12px;
  }

  .qrcode-img {
    width: 100%;
    height: 200px;
  }

  .code-text {
    text-align: center;
    color: #333;
  }

  .code-tips {
    margin-top: 10px;
    font-size: 12px;
  }
}

.order-status-view {
  background: linear-gradient(145deg,#ff9000,#ff5000 77%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #fff;
  font-size: 35rpx;
  /* #ifdef APP-PLUS */
  padding-top: 130rpx;
  /* #endif */
  /* #ifndef APP-PLUS */
  padding-top: 80rpx;
  /* #endif */
  padding-bottom: 20rpx;
  .status-text-view {
    display: flex;
    flex-direction: row;
    font-weight: 500;
  }
  .sub-text-view {
    margin-top: 10rpx;
    .sub-text {
      font-size: 25rpx;
    }
  }
}

.order-gift-view {
  background-color: #FFFFFF;
  border-radius: 10rpx;

  .gift-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding: 30rpx 20rpx;

    .gift-title {
      font-size: 33rpx;
      font-weight: bold;
    }
  }

  .gift-list-view {
    padding: 0rpx 20rpx;
    padding-bottom: 10rpx;
    display: flex;
    flex-direction: row;
    line-height: 120rpx;

    .gift-img-view {
      position: relative;
    }
  }

  .gift-info-view {
    margin: 0rpx 20rpx;
    flex: 1;

    .gift-coupon-price {
      color: #f42424;
    }
  }

  .gift-price-view {
    text-align: right;

    .goods-price {
      font-weight: bold;
    }
  }
}

.order-list-view {
  background-color: #FFFFFF;
  border-radius: 10rpx;

  .order-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding: 30rpx 20rpx;

    .order-sn {
      font-size: 33rpx;
      font-weight: bold;
    }

    .order-status {
      color: #FA3534;
      font-weight: 500;
    }
  }

  .goods-list-view {
    padding: 0rpx 20rpx;
    padding-bottom: 10rpx;

    .btn {
      margin-left: 6px;
    }

    .status-tips {
      color: #666;
      font-size: 26rpx;
      margin: 0 10rpx;
    }
  }

  .order-price-view {
    padding-right: 20rpx;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;

    .order-total-price {
      color: #82848a;
      margin-left: 10rpx;
    }

    .order-pay-price {
      font-size: 33;
      font-weight: 600;
      margin-left: 8rpx;
    }
  }

  .order-footer {
    padding: 20rpx;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: flex-end;
  }
}

.block-view {
  background-color: #fff;
  padding: 20rpx;
  margin-bottom: 20rpx;
  border-radius: 10rpx;

  .header {
    font-weight: 600;
    margin-bottom: 20rpx;
  }

  .block-item-view {
    display: flex;
    flex-direction: row;
    margin: 13rpx 0rpx;
    font-size: 25rpx;

    .title {
      width: 200rpx;
      font-size: 31rpx;
    }

    .value {
      font-weight: 600;
      font-size: 31rpx;
      word-break: break-all;
      width: 87%;
    }

    .click-color {
      color: $u-type-error;
    }
  }

  .block-item-space-between-view {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin: 13rpx 0rpx;
    font-size: 25rpx;

    .title {
      width: 300rpx;
      font-size: 31rpx;
    }

    .value {
      font-weight: 600;
      font-size: 31rpx;
    }
  }

  .express-item {
    .express-text {
      margin-left: 40rpx;
      font-size: 25rpx;

      .time {
        color: $u-tips-color;
        margin: 8rpx 0rpx;
        font-size: 26rpx;
      }
    }
  }
}

.receipt-header {
  margin: 20rpx 0rpx;
  font-size: 33rpx;
}

.receipt-item {
  margin: 20rpx 30rpx;

  .title {
    font-size: 30rpx;
    width: 400rpx;
  }

  .value {
    font-weight: 600;
    font-size: 31rpx;
  }
}</style>
