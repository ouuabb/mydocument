<template>
  <view>
    <view class="goods-view">
      <view v-if="sku">
        <goods-info
          :goodsPrice="sku.purchase_price"
          :goodsName="sku.name"
          :goodsImg="sku.goods_image"
          :goodsSpecList="sku.spec_list"
          :goodsNum="sku.num"
          :goodsPoint="sku.point"
        />
      </view>
    </view>
    <view class="u-margin-bottom-20 u-margin-top-20" v-if="serverDetail.gift_list && serverDetail.gift_list.length">
      <view class="order-gift-view">
        <view class="gift-header">
          <view class="gift-title">
            <text>赠品列表</text>
          </view>
        </view>
        <view v-for="(gift, giftIndex) in serverDetail.gift_list" :key="giftIndex" class="gift-list-view">
          <view class="gift-img-view" v-if="gift.gift_image">
            <u-image border-radius="10" width="120rpx" height="120rpx" :src="gift.gift_image"></u-image>
          </view>
          <view class="gift-img-view" v-else-if="gift.type === 'GIFT_POINT'">
            <u-image border-radius="10" width="120rpx" height="120rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-color-point.png"/>
          </view>
          <view class="gift-img-view" v-else-if="gift.type === 'COUPON'">
            <u-image border-radius="10" width="120rpx" height="120rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-color-coupon.png"/>
          </view>
          <view class="gift-img-view" v-else-if="gift.type === 'FREE_FREIGHT'">
            <u-image border-radius="10" width="120rpx" height="120rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/baoyou.png"/>
          </view>
          <view class="gift-info-view">
            <view class="u-line-2">
              {{ gift.gift_info }}
            </view>
          </view>
        </view>
      </view>
    </view>
    <view class="type-view">
      <view v-if="allowReturnGoods" class="type-item u-flex u-row-between" @click="onType('RETURN_GOODS')">
        <view class="u-flex">
          <u-image width="38rpx" height="38rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/after-money.png"></u-image>
          <view class="title">退货</view>
        </view>
        <view class="sub-text">
          <text>退回收到的商品</text>
          <u-icon name="arrow-right" :size="27"></u-icon>
        </view>
      </view>
      <u-line></u-line>
      <view class="type-item u-flex u-row-between" @click="onType('ONLY_REFUND')">
        <view class="u-flex">
          <u-image width="38rpx" height="38rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/after-money.png"></u-image>
          <view class="title">仅退款</view>
        </view>
        <view class="sub-text">
          <text>原路退回款项</text>
          <u-icon name="arrow-right" :size="27"></u-icon>
        </view>
      </view>
      <u-line></u-line>
      <view class="type-item u-flex u-row-between" @click="onType('CHANGE_GOODS')">
        <view class="u-flex">
          <u-image width="38rpx" height="38rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/after-money.png"></u-image>
          <view class="title">换货</view>
        </view>
        <view class="sub-text">
          <text>更换收到的商品</text>
          <u-icon name="arrow-right" :size="27"></u-icon>
        </view>
      </view>
      <u-line></u-line>
      <view class="type-item u-flex u-row-between" @click="onType('SUPPLY_AGAIN_GOODS')">
        <view class="u-flex">
          <u-image width="38rpx" height="38rpx" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/after-money.png"></u-image>
          <view class="title">补发</view>
        </view>
        <view class="sub-text">
          <text>商家少发商品</text>
          <u-icon name="arrow-right" :size="27"></u-icon>
        </view>
      </view>
    </view>
  </view>
</template>

<script>
import * as API_Order from '@/api/order.js'
import * as API_AfterSale from '@/api/after-sale.js'

export default {
  data() {
    return {
      sn: '',
      sku_id: '',
      sku: '',
      allowReturnGoods: true,
      serverDetail: {}
    }
  },
  onLoad(options) {
    this.sku_id = options.sku_id
    this.sn = options.sn
    this.loadData()
  },
  methods: {
    onType(type) {
      let url = `/order-module/order/after-sale/after-sale-apply`
      url += `?sn=${this.sn}&type=${type}&sku_id=${this.sku_id}`
      uni.navigateTo({ url })
    },
    async loadData() {
      uni.showLoading({ title: '请稍后...', mask: true })
      const [order, sale] = await Promise.all([
        API_Order.getOrderDetail(this.sn),
        API_AfterSale.getAfterSaleData(this.sn, this.sku_id)
      ])
      this.sku = (order.order_sku_list || []).find(item => item.sku_id === this.sku_id)
      this.serverDetail = sale
      this.allowReturnGoods = sale.allow_return_goods
    }
  }
}
</script>

<style lang="scss">
.goods-view {
  background-color: #ffffff;
  padding: 20rpx;
  border-radius: 0rpx 0rpx 10rpx 10rpx;
}
.type-view {
  border-radius: 10rpx;
  background-color: #ffffff;
  margin: 20rpx;
  .type-item {
    height: 100rpx;
    padding: 0rpx 20rpx;
    .title {
      font-size: 30rpx;
      font-weight: 600;
      margin-left: 10rpx;
    }
    .sub-text {
      font-size: 25rpx;
      color: #909399;
    }
  }
}
.order-gift-view {
  background-color: #ffffff;
  border-radius: 10rpx;
  .gift-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    padding: 30rpx 20rpx;
    .gift-title {
      font-size: 33rpx;
      font-weight: bold;
    }
  }
  .gift-list-view {
    padding: 0rpx 20rpx;
    padding-bottom: 10rpx;
    display: flex;
    flex-direction: row;
    line-height: 120rpx;
    .gift-img-view {
      position: relative;
    }
  }
  .gift-info-view {
    margin: 0rpx 20rpx;
    flex: 1;
    .gift-coupon-price {
      color: #f42424;
    }
  }
  .gift-price-view {
    text-align: right;
    .goods-price {
      font-weight: bold;
    }
  }
}
</style>
