<template>
    <view class="apply-detail-wrap" v-if="Object.keys(complaintDetail).length">
      <view class="base-box">
        <u-steps
        class="u-p-t-20"
        :list="steps"
        mode="number"
        :current="stepsActive"
        active-color="#FA3534"></u-steps>
      </view>

      <view class="base-box">
        <view class="title">交易商品信息</view>
        <view class="goods-item">
          <image class="goods-img" :src="complaintDetail.goods_image" alt="" />
          <view>
            <view class="goods-name">{{complaintDetail.goods_name}}</view>
            <view class="goods-price">
			<!-- {{complaintDetail.goods_price | unitPrice}} -->
			<custom-price :price="complaintDetail.goods_price" textColor="#666" :size="26"></custom-price>
			</view>
          </view>
        </view>
        <view class="info-item" @click="Foundation.copyText(complaintDetail.order_sn)">
          订单编号：{{ complaintDetail.order_sn }}
          <u-icon name="file-text" />
        </view>
        <view class="info-item">
			运费：
			<!-- {{ (complaintDetail.shipping_price || 0) | unitPrice }} -->
			<custom-price :price="complaintDetail.shipping_price" textColor="#666" :size="26"></custom-price>
			</view>
        <view class="info-item">
			订单金额：
			<!-- {{ complaintDetail.order_price | unitPrice }} -->
			<custom-price :price="complaintDetail.shipping_price" textColor="#666" :size="26"></custom-price>
			</view>
        <view class="info-item">商家：{{ complaintDetail.seller_name }}</view>
      </view>

      <view class="base-box">
        <view class="title">投诉信息</view>
        <view class="info-item">投诉商品：{{ complaintDetail.goods_name }}</view>
        <view class="info-item">投诉主题：{{ complaintDetail.complain_topic }}</view>
        <view class="info-item">投诉时间：{{ complaintDetail.create_time | unixToDate }}</view>
        <view class="info-item">投诉内容：{{ complaintDetail.content }}</view>
        <view class="info-item">
          投诉凭证：
          <view class="u-flex">
            <u-image
              style="margin-right:10rpx;"
              v-for="(item, index) in images"
              :key="item"
              :src="item"
              width="120"
              height="120"
              @click="handlePreviewImage(images, index)"></u-image>
          </view>
        </view>
      </view>

      <view class="base-box" v-if="complaintDetail.appeal_content">
        <view class="title">商家申诉信息</view>
        <view class="info-item">申诉时间：{{ complaintDetail.appeal_time | unixToDate }}</view>
        <view class="info-item">投诉内容：{{ complaintDetail.appeal_content }}</view>
        <view class="info-item">
          投诉凭证：
          <view class="u-flex">
            <u-image
              style="margin-right:10rpx;"
              v-for="(item, index) in appeal_images"
              :key="item"
              :src="item"
              width="120"
              height="120"
              @click="handlePreviewImage(appeal_images, index)"></u-image>
          </view>
        </view>
      </view>

      <view class="base-box" v-if="complaintDetail.status === 'COMMUNICATION'|| complaintDetail.status === 'WAIT_ARBITRATION' || complaintDetail.status === 'COMPLETE'">
        <view class="title">对话详情</view>
        <view class="info-item">
          对话记录：
          <view class="message-box">
            <template v-if="communication_list && communication_list.length">
              <view v-for="item in communication_list" :key="item.communication_id">
                {{item.owner}}[{{item.create_time | unixToDate('yyyy-MM-dd hh:mm:ss')}}]：{{item.content}}
              </view>
            </template>
            <text v-else>暂无对话</text>
          </view>
        </view>
        <u-form-item
          v-if="complaintDetail.status === 'COMMUNICATION' || complaintDetail.status === 'WAIT_ARBITRATION'"
          required
          labelPosition="top"
          label="发送对话：">
          <u-input
            v-model="message"
            type="textarea"
            height="150"
            placeholder="请填写对话，字数限制200字内"/>
        </u-form-item>
        <view class="u-flex button-box u-row-center">
          <u-button
            class="btn"
            v-if="complaintDetail.status === 'COMMUNICATION' || complaintDetail.status === 'WAIT_ARBITRATION'"
            type="error"
            @click="submitEvent"
            size="mini">发送对话</u-button>
          <u-button
            class="btn"
            v-if="complaintDetail.status === 'COMMUNICATION'"
            type="error"
            @click="submitArbitration"
            size="mini">提交仲裁</u-button>
        </view>
      </view>
      <view class="base-box" v-if="complaintDetail.arbitration_result">
        <view class="title">平台仲裁</view>
        <view class="info-item">仲裁意见：{{ complaintDetail.arbitration_result }}</view>
      </view>

      <u-toast ref="uToast" />
    </view>
  </template>

  <script>
  import * as API_Complaint from '@/api/complaint.js'
  import { Foundation } from '@/app-utils/index.js'
  import { api } from '@/config/config'
  import Cache,{Keys} from '@/utils/cache.js'

  export default {
    data() {
      return {
        Foundation,
        id: '',
        // 投诉流程
        steps: [],
        // 流转状态
        stepsActive: '',
        // 投诉详情
        complaintDetail: {},
        // 投诉凭证
        images: [],
        // 商家申诉凭证
        appeal_images: [],
        // 对话记录
        communication_list: [],
        message: ''
      };
    },
    onLoad(options) {
      if (options.id) {
        this.id = options.id
        this.getComplaintDetail()
        this.getComplaintFlow()
      }
    },
    methods: {
      /** 提交仲裁 */
      submitArbitration() {
        API_Complaint.arbitrationProcess(this.id).then(response => {
          this.$refs.uToast.show({
            title: '提交仲裁成功！',
            type: 'success'
          })
          uni.navigateBack()
        })
      },
      /** 发送对话 */
      submitEvent() {
        const content = this.message
        if (!content) {
          this.$u.toast('请填写对话内容！')
          return
        } else if (content.trim().length > 200) {
          this.$u.toast('对话内容不得超过200字数')
          return
        }
        API_Complaint.initiationSession(this.id, { content }).then(response => {
          this.getComplaintDetail()
          this.message = ''
        })
      },
      /** 图片预览 */
      handlePreviewImage(images, index) {
        uni.previewImage({
          current: index,
          urls: images
        })
      },
      /** 获取投诉详情 */
      getComplaintDetail() {
        API_Complaint.getComplaintDetail(this.id).then(res => {
          this.complaintDetail = res
          this.images = res.images ? res.images.split(',') : []
          this.appeal_images = res.appeal_images ? res.appeal_images.split(',') : []
          this.communication_list = res.communication_list ? res.communication_list.reverse() : []
        })
      },
      /** 获取交易投诉流程 */
      getComplaintFlow() {
        API_Complaint.getComplaintFlow(this.id).then(response => {
          this.steps = response.map(item => {
            item.name = item.text
            return item
          })
          const index = response.findIndex(item => item.show_status === 0)
          this.stepsActive = index === -1 ? response.length : index - 1
        })
      }
    }
  }
  </script>

  <style lang="scss" scoped>
  .apply-detail-wrap {
    padding: 20rpx;
    .button-box {
      margin: 20rpx 0;
      .btn{
        margin: 0 14rpx;
      }
    }
    .base-box {
      font-size: 26rpx;
      color: #666;
      width: 100%;
      background: #fff;
      padding: 20rpx 20rpx;
      border-radius: 8rpx;
      margin-bottom: 20rpx;
    }
    .title {
      color: #333;
      font-weight: 500;
    }
    .info-item {
      margin: 10rpx 0;
      word-break: break-all;
      .message-box {
        border: 2rpx dashed #efefef;
        padding: 14rpx;
        margin: 10rpx;
      }
    }
    .goods-img {
      width: 120rpx;
      height: 120rpx;
      margin-right: 10rpx;
    }
    .goods-item {
      margin: 20rpx 0;
      display: flex;
      align-items: center;
      padding: 20rpx 0;
      color: #666;
    }

  }
  </style>
