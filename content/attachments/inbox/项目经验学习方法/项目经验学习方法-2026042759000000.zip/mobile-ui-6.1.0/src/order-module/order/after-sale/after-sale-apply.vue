<template>
  <view>
    <view class="goods-view">
      <view v-if="sku">
        <goods-info
          :goodsPrice="sku.purchase_price"
          :goodsName="sku.name"
          :goodsImg="sku.goods_image"
          :goodsSpecList="sku.spec_list"
          :goodsNum="sku.num"
          :goodsPoint="sku.point"
        />
        <view class="u-flex u-row-between u-padding-left-15 u-padding-right-15">
          <view>申请数量</view>
          <view>
            <u-number-box v-model="form.return_num" :min="1" :max="sku.num" @change="valChange"></u-number-box>
          </view>
        </view>
      </view>
    </view>

    <view class="block-view">
      <u-field
        v-model="form.reason"
        input-align="right"
        label="申请原因"
        placeholder="请选择申请原因"
        placeholder-style="color: #CDCDCD"
        @click="onReason"
        disabled
        required
        right-icon="arrow-right"
        maxlength="20"
      >
      </u-field>
      <view class="u-margin-top-15 u-margin-left-30 u-margin-right-20">
        <u-input
          v-model="form.problem_desc"
          :customStyle="remarkStyle"
          :type="'textarea'"
          :auto-height="true"
          placeholder="请描述申请售后服务的具体原因."
        />
      </view>
      <!-- 上传图片 -->
      <view class="u-margin-top-10 u-margin-left-20">
        <u-upload
          :action="action"
          :header="header"
          :max-count="5"
          :file-list="fileList"
          @on-uploaded="onUploaded"
        />
      </view>
    </view>

    <view class="block-view" v-if="form.service_type === 'RETURN_GOODS'">
      <u-field
        v-model="return_point"
        disabled
        input-align="right"
        label="退还积分"
        v-if="return_point > 0"
        placeholder-style="color: #CDCDCD"
        maxlength="20"
      />
      <u-field
        v-model="form.return_way_str"
        disabled
        input-align="right"
        label="退款方式"
        placeholder-style="color: #CDCDCD"
        maxlength="20"
        v-if="refundShow"
      />
      <view v-if="afterSaleData.enterprise_id">
        <u-field
          :value="enterprise_account_name"
          input-align="right"
          label="退款账户"
          disabled
        />
      </view>
      <view v-if="!afterSaleData.is_retrace && refundShow && !afterSaleData.enterprise_id">
        <u-field
          v-model="form.account_type_str"
          input-align="right"
          label="账户类型"
          placeholder="请选择账户类型"
          placeholder-style="color: #CDCDCD"
          @click="alterSaleWayShow = true"
          disabled
          right-icon="arrow-right"
          maxlength="20"
        >
        </u-field>
        <u-field
          v-model="form.return_account"
          v-if="form.account_type != 'BANKTRANSFER' && form.account_type !== 'BALANCE' && refundShow"
          input-align="right"
          label="退款账号"
          placeholder="请填写退款账号"
          placeholder-style="color: #CDCDCD"
          maxlength="20"
        />
        <view v-if="form.account_type === 'BANKTRANSFER' && refundShow">
          <u-field
            v-model="form.bank_name"
            input-align="right"
            label="银行名称"
            placeholder="请填写银行名称"
            placeholder-style="color: #CDCDCD"
            maxlength="20"
          />
          <u-field
            v-model="form.bank_account_number"
            input-align="right"
            label="银行账号"
            placeholder="请填写银行账号"
            placeholder-style="color: #CDCDCD"
            maxlength="20"
          />
          <u-field
            v-model="form.bank_account_name"
            input-align="right"
            label="银行开户名"
            placeholder="请填写银行开户名"
            placeholder-style="color: #CDCDCD"
            maxlength="20"
          />
          <u-field
            v-model="form.bank_deposit_name"
            input-align="right" label="银行开户行"
            placeholder="请填写银行开户行"
            placeholder-style="color: #CDCDCD"
            maxlength="20"
          />
        </view>
      </view>
    </view>
    <view class="block-view">
      <!-- <u-field
        input-align="right"
        disabled
        label="返回方式"
        value="快递至第三方卖家"
        placeholder-style="color: #CDCDCD"
        maxlength="20"
      /> -->
      <view v-show="!['RETURN_GOODS', 'ONLY_REFUND'].includes(form.service_type)">
        <addressFiled
          v-if="form.addrs"
          :defaultForm="form"
          @handlerRegionJson="handlerRegionJson"
        />
        <u-field
          v-model="form.ship_addr"
          label="详细地址"
          label-width="150rpx"
          placeholder="请填写详细地址"
          placeholder-style="color: #CDCDCD"
          maxlength="50"
        />
      </view>
      <u-field
        v-model="form.ship_name"
        label="联系人"
        label-width="150rpx"
        placeholder="请填写联系人"
        placeholder-style="color: #CDCDCD"
        maxlength="20"
        v-show="form.service_type !=='RETURN_GOODS'"
      />
      <u-form-item
        v-show="form.service_type !=='RETURN_GOODS'"
        style="padding: 15px;"
        label="联系方式"
        label-width="150rpx"
      >
        <view class="u-flex">
          <area-select ref="areaSelect" :areaCode="form.areaCode"></area-select>
          <u-input v-model="form.ship_mobile" placeholder="请填写联系方式" maxlength="11" clearable/>
        </view>
      </u-form-item>
    </view>
    <view class="btn-view">
      <u-button type="error" shape="circle" @click="onSubmit">提交</u-button>
    </view>

    <!-- 申请原因 -->
    <u-popup class="block-popup" v-model="reasonShow" mode="bottom" length="80%">
      <view class="header">
        申请原因
      </view>
      <view class="body">
        <view class="title">
          请选择申请原因（必选）：
        </view>
        <u-radio-group v-model="reason">
          <view class="value">
            <view v-for="(item, index) in reasonList" :key="index" class="radio-view">
              <u-radio active-color="red" label-size="31" shape="circle" :name="item.name" @change="reasonChange">
                {{ item.name }}
              </u-radio>
            </view>
          </view>
        </u-radio-group>
      </view>
    </u-popup>

    <!-- 申请凭证 -->
    <u-popup class="block-popup" v-model="applyVouchersShow" mode="bottom" length="40%">
      <view class="header">
        申请凭证
      </view>
      <view class="body">
        <u-checkbox-group @change="checkboxGroupChange" :wrap="true">
          <u-checkbox
            v-model="item.checked"
            v-for="(item, index) in vouchersList" :key="index"
            :name="item.name"
          >{{ item.name }}
          </u-checkbox>
        </u-checkbox-group>
      </view>
    </u-popup>
    <u-select v-model="alterSaleWayShow" :list="alterSaleWayList" @confirm="alterSaleWayChange"></u-select>
    <u-toast ref="uToast"/>
    <!-- #ifdef MP-WEIXIN -->
    <u-modal
      v-model="subscribeModalShow"
      title="提示"
      content="是否开启订单/物流相关消息提醒"
      show-cancel-button
      cancel-text="取消"
      confirm-text="订阅"
      @cancel="pushWxSubscribe(false)"
      @confirm="pushWxSubscribe(true)"
    />
    <!-- #endif -->
  </view>
</template>

<script>
import * as API_AfterSale from '@/api/after-sale'
import * as API_Order from '@/api/order'
import { api } from '@/config/config'
import { Foundation } from '@/app-utils'
import { i18n as openI18n } from '@/config/config'
import addressFiled from '@/components/addressFiled/addressFiled'
import areaSelect from '@/components/areaSelect/areaSelect'

export default {
  components: {
    addressFiled,
    areaSelect
  },
  data() {
    return {
      openI18n,
      action: `${api.buyer}/buyer/uploaders`,
      header: this.MixinUploadHeader(),
      value: 1,
      remarkStyle: {
        backgroundColor: '#f3f4f6',
        borderRadius: '10rpx',
        padding: '10rpx'
      },
      sku: '',
      reason: '',
      reasonShow: false,
      applyVouchersShow: false,
      reasonList: [
        { name: '商品质量有问题' },
        { name: '收到商品与描述不符' },
        { name: '不喜欢/不想要' },
        { name: '发票问题' },
        { name: '空包裹' },
        { name: '快递无记录' },
        { name: '快递一直没有收到' },
        { name: '买错/不想要' },
        { name: '未按照时间发货' },
        { name: '其他' }],
      vouchersList: [
        { name: '有发票', checked: false },
        { name: '有检测报告', checked: false }
      ],
      type: 'money',   //申请售后类型, money：申请退款
      alterSaleWayShow: false,
      alterSaleWayList: [
        { value: 'ALIPAY', label: '支付宝' },
        { value: 'WEIXINPAY', label: '微信' },
        { value: 'BANKTRANSFER', label: '银行转账' },
        { value: 'BALANCE', label: '预存款' }
      ],
      form: {
        reason: '',         //申请原因
        return_num: 1,      //退货数量
        ship_addr: '',      //详细地址
        ship_name: '',      //联系人
        ship_mobile: '',    //联系电话
        account_type: '',   //账户类型
        problem_desc: '',   //问题描述
        return_account: '', //退款账号
        order_sn: '',       //订单编号
        sku_id: 0,          //skuid
        service_type: '',   //申请类型
        apply_vouchers: '', //凭证
        region: 0,       //地区ID
        images: [],         //图片
        return_way_str: '账号退款'
      },
      fileList: [],
      afterSaleData: {},
      return_point: 0,
      regionJSon: '',
      refundShow: true,
      enterprise_account_name: '',
      enterprise_account_type: '',
      subscribeModalShow: false,
      subscribeTmplIds: null
    }
  },
  onLoad(options) {
    const { sku_id, sn, type } = options || {}
    this.form.sku_id = sku_id
    this.form.order_sn = sn
    this.form.service_type = type
    let navTitle = ''
    if (type === 'RETURN_GOODS') {
      navTitle = '申请退货'
    } else if (type === 'ONLY_REFUND') {
      navTitle = '仅退款'
    } else if (type === 'CHANGE_GOODS') {
      navTitle = '申请换货'
    } else if (type === 'SUPPLY_AGAIN_GOODS') {
      navTitle = '申请补发'
    }
    uni.setNavigationBarTitle({ title: navTitle })
    this.loadData()
  },
  methods: {
    handlerRegionJson(obj) {
      this.regionJSon = obj
    },
    valChange(e) {
      console.log('当前值为: ' + e.value)
      this.return_point = this.afterSaleData.paid_point * e.value
    },
    onUploaded(list) {
      this.form.images = []
      list.forEach(res => {
        this.form.images.push(res.response.url)
      })
    },
    onReason() {
      this.reasonShow = true
    },
    //申请原因
    reasonChange(reason) {
      this.form.reason = reason
      this.reasonShow = false
    },
    //账户类型
    alterSaleWayChange(e) {
      this.form.account_type = e[0].value
      this.form.account_type_str = e[0].label
    },
    // 申请凭证选择
    checkboxGroupChange(e) {
      this.form.apply_vouchers = e.toString()
    },

    async loadData() {
      uni.showLoading({ title: '请稍后...', mask: true })
      const { order_sn, sku_id } = this.form
      console.log('order_sn: ', order_sn)
      const [order, sale] = await Promise.all([
        API_Order.getOrderDetail(order_sn),
        API_AfterSale.getAfterSaleData(order_sn, sku_id)
      ])
      this.sku = (order.order_sku_list || []).find(item => item.sku_id === sku_id)
      this.form = Object.assign(this.form, sale)
      const { mobileValue, areaCode } = Foundation.formatIn18Mobile(sale.ship_mobile)
      this.form.ship_mobile = mobileValue
      this.form.areaCode = areaCode
      this.form.return_num = sale.buy_num
      this.afterSaleData = sale
      this.return_point = sale.paid_point * sale.apply_num
      this.form.country_name = sale.ship_country_name
      this.form.enterprise_id = sale.enterprise_id
      if (sale.credit_account_pay_money && sale.credit_account_pay_money !== 0) {
        this.enterprise_account_type = 'CREDIT_ACCOUNT'
        this.enterprise_account_name = '授信账户'
      } else {
        this.enterprise_account_type = 'ENTERPRISE_ACCOUNT'
        this.enterprise_account_name = '企业预存账户'
      }
      this.form.addrs = this.MixinFormatRegions(sale)
      this.form.region = this.MixinGetRegionDefaultData(sale)
      if (sale.is_retrace || sale.enterprise_id) {
        this.form.return_way_str = '原路退回'
      }
      this.refundShow = sale.order_price > 0
    },
    async onSubmit() {
      if (!this.handleCheckParams()) return
      const { account_type_str, ...data } = this.form
      if (data.enterprise_id) {
        data.account_type = this.enterprise_account_type
      }
      data.ship_mobile = this.$refs.areaSelect.mobileValue(data.ship_mobile)
      const params = { region: JSON.stringify(this.regionJSon) }
      uni.showLoading({ title: '请稍候...', mask: true })
      if (this.form.service_type === 'RETURN_GOODS') {
        await API_AfterSale.applyAfterSaleGoods(data, params)
      }
      if (this.form.service_type === 'ONLY_REFUND') {
        await API_AfterSale.applyAfterSaleOnlyMoney(data, params)
      }
      if (this.form.service_type === 'CHANGE_GOODS') {
        await API_AfterSale.applyAfterSaleChange(data, params)
      }
      if (this.form.service_type === 'SUPPLY_AGAIN_GOODS') {
        await API_AfterSale.applyAfterSaleReplace(data, params)
      }
      this.afterCallback()
    },
    handleCheckParams() {
      if (!this.form.reason || this.form.reason === '请选择申请原因') {
        this.$u.toast('请选择申请原因！')
        return
      }
      if (!this.form.problem_desc) {
        this.$u.toast('请输入问题描述！')
        return
      }
      if (!this.afterSaleData.is_retrace && this.refundShow && !this.afterSaleData.enterprise_id) {
        if (this.form.service_type === 'RETURN_GOODS') {
          if (!this.form.account_type) {
            this.$u.toast('请选择账户类型！')
            return
          }
          // 如果账户类型不为银行卡
          if (this.form.account_type === 'BANKTRANSFER') {
            // 银行名称校验
            if (!this.form.bank_name) {
              this.$u.toast('请输入银行名称！')
              return
            }
            // 银行账号校验
            if (!this.form.bank_account_number) {
              this.$u.toast('请输入银行账号！')
              return
            }
            // 银行开户名校验
            if (!this.form.bank_account_name) {
              this.$u.toast('请输入银行开户名！')
              return
            }
            // 银行开户行校验
            if (!this.form.bank_deposit_name) {
              this.$u.toast('请输入银行开户行！')
              return
            }
          } else if (this.form.account_type === 'ALIPAY' || this.form.account_type === 'WEIXINPAY') {
            // 退款账号校验
            if (!this.form.return_account) {
              this.$u.toast('请输入退款账号！')
              return
            }
          }
        }
      }
      if (!this.form.addrs) {
        this.$u.toast('请选择收货地址！')
        return
      }
      if (!this.form.ship_addr) {
        this.$u.toast('请输入详细地址！')
        return
      }
      if (!this.form.ship_name) {
        this.$u.toast('请输入联系人！')
        return
      }
      const { mobile_regex, formatValid } = this.$refs.areaSelect
      const mobileReg = new RegExp(mobile_regex)

      if (!mobileReg.test(formatValid(this.form.ship_mobile))) {
        this.$u.toast('手机号码格式有误')
        return
      }
      return true
    },
    async afterCallback() {
      uni.showToast({ title: '成功' })
      // #ifdef MP-WEIXIN
      await this.getSubscribeTmpIds()
      this.subscribeModalShow = true
      // #endif
      // #ifndef MP-WEIXIN
      setTimeout(() => {
        uni.navigateTo({ url: '/order-module/order/after-sale/after-sale' })
      }, 1500)
      // #endif
    },
    // #ifdef MP-WEIXIN
    // 发起订阅授权
    async pushWxSubscribe(confirm = true) {
      if (!confirm) {
        uni.navigateTo({ url: '/order-module/order/after-sale/after-sale' })
        return
      }
      if (!this.subscribeTmplIds) return
      uni.requestSubscribeMessage({
        tmplIds: this.subscribeTmplIds,
        fail: err => {
          console.log('requestSubscribeMessage:err: ', err)
        },
        complete: () => {
          uni.navigateTo({ url: '/order-module/order/after-sale/after-sale' })
        }
      })
    },
    // 获取订阅消息模板id集合
    async getSubscribeTmpIds() {
      uni.showLoading({ title: '请稍候...', mask: true })
      const data_type = this.trade_sn ? 0 : 1
      const sn = this.trade_sn || this.order_sn
      this.subscribeTmplIds = await API_Order.getWechatListTmpId(data_type, sn)
    }
    // #endif
  }
}
</script>

<style lang="scss">
.goods-view {
  background-color: #ffffff;
  padding: 15rpx;
  border-radius: 0rpx 0rpx 10rpx 10rpx;
}
::v-deep .block-view > .uni-input-input {
  text-align: right;
}

.block-view {
  background-color: #ffffff;
  border-radius: 10rpx;
  margin: 10rpx 0;
  ::v-deep .u-label {
    flex: none;
  }
}
.btn-view {
  padding: 0rpx 30rpx;
  margin-top: 60rpx;
  margin-bottom: 40rpx;
}
.block-popup {
  .header {
    padding: 20rpx;
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    font-weight: 600;
  }
  .body {
    padding: 20rpx 30rpx;
    .title {
      font-weight: 600;
    }
    .value {
      display: flex;
      flex-direction: column;
      .radio-view {
        margin: 10rpx 0rpx;
      }
    }
  }
  .footer {
    padding: 0rpx 20rpx;
  }
}
</style>
