<template>
  <view>
    <view class="wrap">
      <view class="tabs-view">
        <u-tabs
          :list="tabsList"
          active-color="#FA3534"
          :is-scroll="false"
          :current="current"
          @change="change"></u-tabs>
      </view>
      <view class="swiper-box">
        <mescroll-body ref="mescrollRef" top="80" auto="false" :down="down" @init="mescrollInit" @down="downCallback"
          @up="upCallback">
          <view class="list-item" v-for="(item, index) in applyList" :key="index">
            <view class="title" @click="Foundation.copyText(item.complain_id)">
              投诉编号：{{item.complain_id}}
              <u-icon name="file-text" />
            </view>
            <view class="">投诉主题：{{item.complain_topic}}</view>
            <view class="goods-info u-flex">
              <image class="goods-img" :src="item.goods_image" alt=""/>
              <view>
                <view class="goods-name">{{item.goods_name}}</view>
                <view class="goods-name" >
                  订单编号：{{item.order_sn}}
                  <u-icon @click="Foundation.copyText(item.order_sn)" name="file-text" />
                </view>
              </view>
            </view>
            <view class="status-content u-flex u-row-between">
              <view>
                状态：<text class="status">{{item.status |statusFilter }}</text>
              </view>
              <view class="u-flex">
                <u-button style="margin-right:10rpx;" size="mini" @click="checkDetail(item.complain_id)">查看详情</u-button>
                <u-button size="mini" v-if="item.status === 'NEW'" @click="cancelComplaint(item.complain_id)">撤销投诉</u-button>
              </view>
            </view>
          </view>

        </mescroll-body>
      </view>
    </view>
    <u-toast ref="uToast" />
    <loading-view v-if="loading"></loading-view>
  </view>
</template>

<script>
import * as API_Complaint from '@/api/complaint.js'
// 引入mescroll-mixins.js
import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
import { Foundation } from '@/app-utils/index.js'

export default {
  mixins: [MescrollMixin], // 使用mixin
  data() {
    return {
      Foundation,
      tabsList: [
        { name: '全部投诉', tag: '' },
        { name: '进行中', tag: 'COMPLAINING' },
        { name: '已完成', tag: 'COMPLETE' },
        { name: '已撤销', tag: 'CANCELED' }
      ],
      current: 0,
      applyList: [],
      params: {
        tag: '',
        page_no: 1,
        page_size: 10,
      },
      //底部加载数据时的状态
      loadStatus: 'loading',
      //是否允许加载数据（true：允许）。如果没有更多的数据了，就不再调用API了。
      isLoad: true,
      down: {
        auto: false
      },
      loading: true
    };
  },
  filters: {
    statusFilter(val) {
      switch (val) {
        case 'NEW':
          return '新投诉'
        case 'CANCEL':
          return '已撤销'
        case 'WAIT_APPEAL':
          return '待申诉'
        case 'COMMUNICATION':
          return '对话中'
        case 'WAIT_ARBITRATION':
          return '等待仲裁'
        case 'COMPLETE':
          return '已完成'
      }
    }
  },
  onLoad() {
  },
  methods: {
    /** tab切换，初始化数据 */
    change(index) {
      this.loadStatus = 'loading'
      this.isLoad = true
      this.applyList = [];
      this.current = index;
      this.params = {
        tag: this.tabsList[index].tag,
        page_no: 1,
        page_size: 10
      }
      this.mescroll.resetUpScroll(true)
    },
    /** 撤销投诉 */
    cancelComplaint(id) {
      API_Complaint.cancelComplaint(id).then(response => {
        this.$refs.uToast.show({
          title: '撤销投诉成功！',
          type: 'success'
        })
        this.applyList = [];
        this.params.page_no = 1
        this.getApplyListList()
      })
    },
    /** 获取投诉列表 */
    getApplyListList() {
      API_Complaint.getComplaintList(this.params).then(res => {
        let applyList = res.data;
        this.loading = false;
        this.applyList = this.applyList.concat(applyList);
        this.mescroll.endBySize(res.data.length, res.data_total);
      })
    },
    //上拉加载数据
    upCallback(page) {
      this.params.page_no = page.num;
      this.getApplyListList();
    },
    //下拉刷新
    downCallback() {
      this.change(this.current);
    },
    checkDetail(id) {
      uni.navigateTo({
        url: `/order-module/order/complaint-apply/apply-detail?id=${id}`,
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.wrap {
  display: flex;
  flex-direction: column;
  height: calc(100vh - var(--window-top));
  width: 100%;
}

.swiper-box {
  flex: 1;
  height: 90%;
  padding: 20rpx;
  .list-item {
    background: #fff;
    margin-bottom: 10rpx;
    padding: 20rpx;
    border-radius: 8rpx;
    font-size: 26rpx;
    color: #333;
    .title {
      border-bottom: 2rpx solid #efefef;
      padding-bottom: 10rpx;
      margin-bottom: 20rpx;
    }
    .goods-info {
      padding: 20rpx 0;
      border-bottom: 2rpx solid #efefef;
      .goods-img {
        width: 100rpx;
        height: 100rpx;
        margin-right: 20rpx;
      }
      .goods-name {
        color: #666;
        margin-bottom: 10rpx;
      }
    }
    .status-content {
      padding: 16rpx 0;
      width: 100%;
      .u-btn{
        margin: 0;
      }
      .status {
        color: #FA3534;
      }
    }
  }
}
</style>
