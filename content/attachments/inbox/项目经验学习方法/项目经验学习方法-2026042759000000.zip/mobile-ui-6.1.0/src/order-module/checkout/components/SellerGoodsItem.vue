<template>
  <view class="seller-view">
    <view class="seller-name u-flex">
      <u-icon name="shop" custom-prefix="custom-icon" size="35"></u-icon>
      <view class="u-margin-left-10">{{ shop.seller_name }}</view>
    </view>
    <view style="color: red; margin-bottom: 25rpx;">{{ shop.promotion_notice }}</view>
    <view class="sku-list" v-for="(group, index) in shop.group_list" :key="index">
      <view class="u-flex u-col-center u-row-between promotion-tag-box ">
        <view class="u-flex u-col-center">
          <view
            class="u-m-r-20 promotion-group-tag">{{ group.promotion_type_name }}
          </view>
          <text class="tips-text">{{ promotionTips(group) }}</text>
        </view>
        <u-icon
          v-if="group.promotion_type_name === '满赠'"
          name="more-dot-fill"
          @click="handleShowGiftList(group)"></u-icon>
      </view>
      <view class="sku-list" v-for="(sku, skuIndex) in group.sku_list" :key="skuIndex">
        <goods-info
          :goodsName="sku.name"
          :goodsImg="sku.goods_image"
          :goodsPromotion="sku.promotion_tags"
          :goodsPoint="sku.point"
          :goodsSpecList="sku.spec_list"
          :goodsPrice="sku.original_price"
          :goodsNum="sku.num">
        </goods-info>
      </view>
    </view>
    <view v-for="sku in shop.sku_list" :key="sku.sku_id" class="sku-list">
      <goods-info
        :goodsType="sku.goods_type"
        :goodsName="sku.name"
        :goodsImg="sku.goods_image"
        :goodsPromotion="sku.promotion_tags"
        :goodsSpecList="sku.spec_list"
        :goodsPoint="sku.point"
        :goodsPrice="sku.original_price"
        :goodsNum="sku.num">
      </goods-info>
    </view>
    <view v-if="shop.coupon_list">
      <view class="other-info-view" @click="couponsShow = true"
            v-if="shop.coupon_list.available_list && shop.coupon_list.available_list.length">
        <view class="other-left">店铺优惠券</view>
        <view class="other-middle" v-if="amount">
          <!-- {{ `-${MixinUnitOfCurrency}${amount}` }} -->
			<custom-price :price="amount" isNeg :size="24"></custom-price>
        </view>
        <view class="other-middle" v-else>
          {{ (shop.coupon_list.available_list.length + '个可用') }}
        </view>
        <view class="other-right">
          <u-icon name="more-dot-fill"></u-icon>
        </view>
      </view>
    </view>
    <!-- 优惠券弹出层 -->
    <u-popup v-if="shop.coupon_list" v-model="couponsShow" mode="bottom" length="70%" border-radius="20"
             :safe-area-inset-bottom="true" closeable close-icon-size="20">
      <view class="u-m-30 u-text-center" style="font-weight: 600;">
        优惠券
      </view>
      <scroll-view scroll-y="true">
        <view class="coupons-list u-flex u-m-20" v-for="(coupon, index) in shop.coupon_list.available_list" :key="index"
              @click="handleUseCoupons(coupon)">
          <view class="coupons-left">
            <custom-price :price="coupon.amount" :textColor="'#ffffff'" :size="50" class="u-line-1"></custom-price>
            <view class="u-font-22">
              满{{ coupon.coupon_threshold_price }} 可用
            </view>
          </view>
          <view class="coupons-cont u-flex-1">
            <view class="coupons-title  u-m-b-10">
              {{ coupon.seller_name }}
            </view>
            <view class="coupons-time u-font-22">
              有效期截止：{{ coupon.end_time | date }}
            </view>
          </view>
          <view class="coupons-right">
            <u-icon :name="coupon.selected === 1 ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
          </view>
        </view>
      </scroll-view>
    </u-popup>

    <u-popup
      v-model="showGiftList"
      mode="bottom"
      length="auto"
      border-radius="20"
      :safe-area-inset-bottom="true"
      closeable
      close-icon-size="20">
      <view style="padding: 60rpx 0;">
        <view class="u-m-30 u-text-center" style="font-weight: 600;">
          赠品信息
        </view>
        <view class="give-item" v-if="groupGift.free_freight">
          <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/baoyou.png" alt=""/>
          <text>免邮费</text>
        </view>
        <view v-for="(item, index) of groupGift.gift_list" :key="index">
          <view class="give-item" v-if="item.type === 'point'">
            <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/jifen.png" alt=""/>
            <text>送{{ item.value }}积分</text>
          </view>
          <view class="give-item" v-if="item.type === 'coupon'">
            <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/youhuiquan.png" alt=""/>
            赠送一张满 <text class="gift-coupon-price">{{ item.value.threshold }}</text> 减<text
            class="gift-coupon-price"><!--{{ giftCoupon.couponPrice | unitPrice }}--><custom-price :price="item.value.amount" :size="24"></custom-price></text>的优惠券          </view>
          <view class="give-item" v-if="item.type === 'gift'">
            <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/zengping.png" alt=""/>
            <text>送{{ item.value.gift_name }}一份</text>
          </view>
        </view>
      </view>
    </u-popup>

  </view>
</template>

<script>
import * as API_Trade from '@/api/trade.js'
import { i18n as openI18n } from '@/config/config'

/**
 * 店铺+商品 Cell组件
 *
 * ===== 使用场景 ======
 * 购物车页，确认订单页，我的订单页。
 *
 * ===== 参数 =====
 * shop        店铺信息
 */
export default {
  props: {
    shop: {
      type: Object,
      default() {
        return []
      }
    },
    way: {
      type: String
    }
  },
  data() {
    return {
      openI18n,
      couponsShow: false,
      amount: '',  // 店铺优惠金额
      // 赠品弹窗显隐
      showGiftList: false,
      // 赠品数据
      groupGift: {}
    }
  },
  computed: {
    promotionTips() {
      return (group) => {
        const promotion = group.promotion_tips
        let tips = ''
        const unit = promotion.discount_type === 2 ? '件' : ''
        if (group.promotion_type_name === '满减') {
          // current_threshold_value：当前已满足档位 current_discount_amount：当前已减金额
          if (promotion.current_threshold_value && promotion.current_discount_amount) {
            tips += `已购满${promotion.current_threshold_value}${unit}`
            if (promotion.current_type === 1) {
              // 满额减
              tips += `，已减${promotion.current_discount_amount}`
            } else {
              // 满折
              tips += `，享${promotion.current_discount_amount}折优惠`
            }
          }
        } else if (group.promotion_type_name === '满赠') {
          if (promotion.current_threshold_value) {
            tips = `已满${promotion.current_threshold_value}${unit}享受满赠优惠`
          }
        }
        return tips
      }
    }
  },
  created() {
    // 刷新页面优惠券是否使用
    if (this.shop.coupon_list) {
      const amounts = this.shop.coupon_list.available_list.filter(item => item.selected === 1)[0]
      if (amounts) {
        this.amount = amounts.amount
      }
    }
  },
  methods: {
    handleShowGiftList(group) {
      this.groupGift = group
      this.showGiftList = true
    },
    //使用优惠券
    async handleUseCoupons(coupon, index) {
      const params = {}
      params.way = this.way
      const used = coupon.selected === 1
      params.type = coupon.selected
      await API_Trade.useCoupon(coupon.member_coupon_id, params)
      if (used) {
        this.amount = ''
      } else {
        this.amount = coupon.amount
      }
      this.$emit('couponChange')
      this.couponsShow = false
    }
  }
}
</script>

<style lang="scss" scoped>
.give-item {
  padding: 0 20rpx;
  display: flex;
  align-items: center;
  font-size: 24rpx;
  margin: 14rpx 0;
  .give-icon {
    width: 50rpx;
    height: 50rpx;
    margin-right: 20rpx;
  }
}
.seller-view {
  .sku-list {
    .promotion-tag-box {
      margin-bottom: 20rpx;
      .promotion-group-tag {
        font-size: 22rpx;
        padding: 4rpx 20rpx;
        color: #fff;
        background: #f42424;
        border-radius: 8rpx;
      }
      .tips-text {
        font-size: 22rpx;
      }
    }
  }
  .seller-name {
    margin-bottom: 20rpx;
    font-size: 30rpx;
    font-weight: 600;
  }
  .other-info-view {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin: 20rpx 10rpx;
    align-items: center;
    .other-left {
      width: 200rpx;
      font-weight: bold;
    }
    .other-middle {
      flex: 1;
      text-align: right;
      display: flex;
      justify-content: flex-end;
    }
    .other-right {
      width: 60rpx;
      text-align: right;
    }
  }
  .coupons-list {
    .coupons-left {
      padding: 30rpx 20rpx;
      background-color: rgb(98, 154, 238);
      text-align: center;
      font-size: 28rpx;
      color: #ffffff;
      width: 252rpx;
      .u-line-1 {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .coupons-cont {
      margin: 0 20rpx;
    }
  }
}
</style>
