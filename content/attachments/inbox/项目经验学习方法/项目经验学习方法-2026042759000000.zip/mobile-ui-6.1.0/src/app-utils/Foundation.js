import h5Copy from '@/common/junyi-h5-copy.js'

/**
 * 一些常用的基础方法
 * unixToDate    将unix时间戳转换为指定格式
 * dateToUnix    将时间转unix时间戳
 * deepClone     对一个对象进行深拷贝
 * formatPrice   货币格式化
 * secrecyMobile 手机号隐私保护
 * randomString  随机生成指定长度的字符串
 */
import { i18n as openI18n } from '../config/config'
import { parseText, parseTemplate } from './helpers'

/**
 * 将unix时间戳转换为指定格式
 * @param unix   时间戳【秒】
 * @param format 转换格式
 * @returns {*|string}
 */
export function unixToDate(unix, format) {
  if (!unix) return unix
  let _format = format || 'yyyy-MM-dd hh:mm:ss'
  const d = new Date(unix * 1000)
  const o = {
    'M+': d.getMonth() + 1,
    'd+': d.getDate(),
    'h+': d.getHours(),
    'm+': d.getMinutes(),
    's+': d.getSeconds(),
    'q+': Math.floor((d.getMonth() + 3) / 3),
    S: d.getMilliseconds()
  }
  if (/(y+)/.test(_format)) _format = _format.replace(RegExp.$1, (d.getFullYear() + '').substr(4 - RegExp.$1.length))
  for (const k in o) if (new RegExp('(' + k + ')').test(_format)) _format = _format.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
  return _format
}

// 获取当前系统时间
export function getNowFormatDate() {
  var date = new Date()
  var seperator1 = '-'
  var seperator2 = ':'
  var month = date.getMonth() + 1
  var strDate = date.getDate()
  if (month >= 1 && month <= 9) {
    month = '0' + month
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = '0' + strDate
  }
  var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
    + ' ' + date.getHours() + seperator2 + date.getMinutes()
    + seperator2 + date.getSeconds()
  return currentdate
}

/**
 * 将时间转unix时间戳
 * @param date
 * @returns {number} 【秒】
 */
export function dateToUnix(date) {
  let newStr = date.replace(/:/g, '-')
  newStr = newStr.replace(/ /g, '-')
  const arr = newStr.split('-')
  const datum = new Date(Date.UTC(
    arr[0],
    arr[1] - 1,
    arr[2],
    arr[3] - 8 || -8,
    arr[4] || 0,
    arr[5] || 0
  ))
  return parseInt(datum.getTime() / 1000)
}

/**
 * 货币格式化
 * @param price
 * @returns {string}
 */
export function formatPrice(price) {
  if (typeof price !== 'number') return price
  return String(Number(price).toFixed(2))
  // return String(Number(price).toFixed(2)).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

/**
 * 手机号隐私保护
 * 隐藏中间四位数字
 * @param mobile
 * @returns {*}
 */
export function secrecyMobile(mobile) {
  mobile = String(mobile)
  if (mobile.indexOf(',') !== -1) {
    const areaValue_n = mobile.split(',')[0]
    const newMobile = mobile.split(',')[1]
    if (areaValue_n && openI18n) {
      return '+' + areaValue_n + newMobile.replace(/(\d{3})(\d{4})(\d{4})/, '$1****$3')
    }
    return newMobile
  } else if (!/\d{11}/.test(mobile)) {
    return mobile
  }
  return mobile.replace(/(\d{3})(\d{4})(\d{4})/, '$1****$3')
}

/**
 * 随机生成指定长度的字符串
 * @param length
 * @returns {string}
 */
export function randomString(length = 32) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  const maxPos = chars.length
  let _string = ''
  for (let i = 0; i < length; i++) {
    _string += chars.charAt(Math.floor(Math.random() * maxPos))
  }
  return _string
}

/**
 * 计算传秒数的倒计时【天、时、分、秒】
 * @param seconds
 * @returns {{day : *, hours : *, minutes : *, seconds : *}}
 */
export function countTimeDown(seconds) {
  const leftTime = (time) => {
    if (time < 10) time = '0' + time
    return time + ''
  }
  return {
    day: leftTime(parseInt(seconds / 60 / 60 / 24, 10)),
    hours: leftTime(parseInt(seconds / 60 / 60 % 24, 10)),
    minutes: leftTime(parseInt(seconds / 60 % 60, 10)),
    seconds: leftTime(parseInt(seconds % 60, 10))
  }
}

/**
 * 计算当前时间到第二天0点的倒计时[秒]
 * @returns {number}
 */
export function theNextDayTime() {
  const nowDate = new Date()
  const time = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate() + 1, 0, 0, 0).getTime() - nowDate.getTime()
  return parseInt(time / 1000)
}


/**
 * emoji表情字符处理
 * 用于把用utf16编码的字符转换成实体字符，以供后台存储
 * @param  {string} str 将要转换的字符串，其中含有utf16字符将被自动检出
 * @return {string}     转换后的字符串，utf16字符将被转换成&#xxxx;形式的实体字符
 */
export function utf16toEntities(str) {
  var patt = /[\ud800-\udbff][\udc00-\udfff]/g // 检测utf16字符正则
  str = str.replace(patt, function(char) {
    var H, L, code
    if (char.length === 2) {
      H = char.charCodeAt(0) // 取出高位
      L = char.charCodeAt(1) // 取出低位
      code = (H - 0xD800) * 0x400 + 0x10000 + L - 0xDC00 // 转换算法
      return '&#' + code + ';'
    } else {
      return char
    }
  })
  return str
}

function formateDate(time) {
  let year = time.getFullYear()
  let month = time.getMonth() + 1
  let day = time.getDate()

  if (month < 10) {
    month = '0' + month
  }

  if (day < 10) {
    day = '0' + day
  }

  return year + '.' + month + '.' + day + ''

}

/**
 *
 * @param dateNow :Date类
 * @param intervalDays ：间隔天数
 * @param bolPastTime  ：Boolean,判断在参数date之前，还是之后，
 */
export function getDateRange(dateNow, intervalDays, bolPastTime = true) {
  let oneDayTime = 24 * 60 * 60 * 1000
  let data = {}
  let lastDay

  if (bolPastTime == true) {
    lastDay = new Date(dateNow.getTime() - intervalDays * oneDayTime)
    data.startDate = formateDate(lastDay)
    data.endDate = formateDate(dateNow)
    data.startTime = parseInt(lastDay.getTime() / 1000)
    data.endTime = parseInt(dateNow.getTime() / 1000)
  } else {
    lastDay = new Date(dateNow.getTime() + intervalDays * oneDayTime)
    data.startDate = formateDate(dateNow)
    data.endDate = formateDate(lastDay)
    data.startTime = parseInt(dateNow.getTime() / 1000)
    data.endTime = parseInt(lastDay.getTime() / 1000)
  }
  return data
}


/**
 * 解析url参数
 * @param {*} url
 * @returns
 */
export function queryURLparamsReg(url) {
  let obj = {}
  let reg = /([^?=&]+)=([^?=&]+)/g
  url.replace(reg, (...arg) => {
    obj[arg[1]] = arg[2]
  })
  return obj
}

/**
 * 处理手机号区号显示  86,13269111627 --> +8613269111627
 * @param val
 */
export function formatMobile(val) {
  if (!val) return val
  if (val.indexOf(',') !== -1) {
    const areaValue_n = val.split(',')[0]
    const mobile = val.split(',')[1]
    if (areaValue_n && openI18n) {
      return '+' + areaValue_n + mobile
    }
    return mobile
  } else {
      return val
  }
}

/**
 * 国际化手机号 区号与手机号拆分
 * @param {*} value
 * @returns
 */
export function formatIn18Mobile(value) {
  if (value && value.indexOf(',') !== -1) {
    const mobile = value.split(',')
    return {
      areaCode: mobile[0],
      mobileValue: mobile[1]
    }
  } else {
    return {
      areaCode: '',
      mobileValue: value
    }
  }
}

/**
 * I18n文本模板格式化
 * @param data
 * @param key
 * @param i18n
 */
export function i18nTemplateFormatter(data, key, i18n) {
  const result = i18n.t(key)
  if (!result || result === key) return result
  let parseRes = parseTemplate(result, data)
  parseRes = parseText(parseRes)
  parseRes = parseRes.tokens.map(item => {
    if (typeof item === 'object' && item['@binding']) {
      let d = data
      let keys = item['@binding'].split('.')
      while (keys.length !== 0) {
        const key = keys.splice(0, 1)
        if (key[0]) d = d[key[0].trim()]
      }
      return d
    }
    return item
  }).join('')
  return parseRes
}

/**
 * 文本复制
 * @param {*} text
 */
export function copyText(text) {
  if (!text) {
    uni.showToast({
      title: '无数据',
      icon: 'none'
  })
    return
  }
    //#ifdef H5
    const result = h5Copy(text)
    if (result) {
        uni.showToast({
            title: '复制成功',
            icon: 'none'
        })
    } else {
        uni.showToast({
            title: '暂不支持复制',
            icon: 'none'
        })
    }
    // #endif
    // #ifndef H5
    uni.setClipboardData({
        data: text,
        success: () => {
            uni.showToast({
                title: '复制成功',
                icon: 'none'
            })
        }
    })
    // #endif
}