/**
 * 支付相关方法
 */

/**
 * 微信小程序支付
 * @param {function} paymentParams 支付参数
 * @param {function} paySuccess 支付成功回调
 * @param {function} payFail 支付失败回调
 */
export function wechatMiniPay(paymentParams, paySuccess, payFail) {
  uni.requestPayment({
    provider: 'wxpay',
    timeStamp: paymentParams.timeStamp,
    nonceStr: paymentParams.nonceStr,
    package: paymentParams.package,
    signType: paymentParams.signType,
    paySign: paymentParams.paySign,
    success(res) {
      console.log('success:' + JSON.stringify(res))
      paySuccess(res)
    },
    fail: function (err) {
      payFail(err)
      console.log('fail:' + JSON.stringify(err))
    }
  })
}


/**
 * 微信App支付
 * @param {function} paymentParams 支付参数
 * @param {function} paySuccess 支付成功回调
 * @param {function} payFail 支付失败回调
 */
export function wechatAppPay(orderInfo, paySuccess, payFail) {
  console.log('weixin app call1')
  uni.requestPayment({
    provider: 'wxpay',
    orderInfo: orderInfo,
    success(res) {
      console.log('success:' + JSON.stringify(res))
      paySuccess(res)
    },
    fail: function (err) {
      payFail(err)
      console.log('fail', err)
    }
  })
}


/**
 * 手机浏览器h5支付
 * @param {Object} paymentParams
 * @param {Object} paySuccess
 * @param {Object} payFail
 */
export function mobileH5Pay(response, redirect_url = '') {
  location.href = `${response.gateway_url}&redirect_url=${redirect_url}`
}

/**
 * 微信内嵌h5支付
 * @param {Object} paymentParams
 * @param {Object} paySuccess
 * @param {Object} payFail
 */
export function wechatH5Pay(paymentParams, paySuccess, payFail) {

  WeixinJSBridge.invoke(
    'getBrandWCPayRequest', {
      'appId': paymentParams.appId,     //公众号名称，由商户传入
      'timeStamp': paymentParams.timeStamp,        //时间戳，自1970年以来的秒数
      'nonceStr': paymentParams.nonceStr, //随机串
      'package': paymentParams.package,
      'signType': paymentParams.signType,        //微信签名方式
      'paySign': paymentParams.paySign //微信签名
    },
    function (res) {
      paySuccess(res)
      if (res.err_msg == 'get_brand_wcpay_request:ok') {

      }
    })
}

/**
 * 支付宝H5支付
 * 在
 * @param {Object} response
 * @param {Object} paySuccess
 * @param {Object} payFail
 */
export function aliPayH5(response, paySuccess, payFail) {
  window.location.href = response.gateway_url
}

export function aliPayApp(response, paySuccess, payFail) {
  uni.requestPayment({
    provider: 'alipay',
    orderInfo: response.gateway_url, //支付宝订单数据
    success: function (res) {
      console.log('success:' + JSON.stringify(res))
      paySuccess(res)
    },
    fail: function (err) {
      payFail(err)
      console.log('fail:' + JSON.stringify(err))
    }
  })
}

export function stripePayApp(payInfo, stripeKey, paySuccess, payFail) {
  uni.getProvider({
    service: 'payment',
    success: (res) => {
      if (!res.provider.includes('stripe')) {
        payFail('未找到Stripe服务！')
        return
      }
      const orderInfo = {
        merchantName: payInfo.merchantName,
        paymentIntent: payInfo.clientSecret,
        publishKey: stripeKey
      }
      uni.requestPayment({
        provider: 'stripe',
        orderInfo: orderInfo,
        success: (res) => {
          paySuccess(res)
        },
        fail: (err) => {
          payFail(err)
        }
      })
    }
  })
}
