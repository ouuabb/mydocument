import { Foundation } from '../app-utils'
import i18n from '../lang'
import Cache, { Keys } from '@/utils/cache'
import Config from '@/config/config'

export default {
  computed: {
    MixinUnitOfCurrency() {
      return Config.i18n ? (this.$store.state.baseCurrency.symbol || '$') : '￥'
    }
  },
  methods: {
    /**
     * 国际化模板
     * @param data
     * @param key
     * @returns {*|string}
     * @constructor
     */
    MixinI18nTemplate(data, key) {
      return Foundation.i18nTemplateFormatter(data, key, i18n)
    },
    /**
     * 上传文件请求头
     * @returns {{Authorization: *, tenantId: string}}
     * @constructor
     */
    MixinUploadHeader() {
      return {
        Authorization: Cache.getItem(Keys.accessToken),
        
      }
    },
    // 国际化下的价格，基准货币*选中货币汇率
    MixinI18nPrice(price) {
      if (!Config.i18n) return ''
      const { symbol, rate = 1 } = this.$store.state.currentCurrency || {}
      const unit = symbol || '$'
      return unit + Foundation.formatPrice(price / rate)
    },
    /**
     * 地区选择器默认数据
     * @param data
     * @param prefix
     * @returns {(*|number)[]|{country_code: *, city_name: *, country_name: *, region_id: *, region_name: *, city_id: *}}
     * @constructor
     */
    MixinGetRegionDefaultData(data, prefix = '') {
      const country_code = data[`${prefix}country_code`]
      if (!country_code || country_code === 'CN') {
        return [
          data[`${prefix}province_id`],
          data[`${prefix}city_id`] || -1,
          data[`${prefix}county_id`] || -1,
          data[`${prefix}town_id`] || -1
        ]
      }
      return {
        country_code: data[`${prefix}country_code`],
        country_name: data[`${prefix}country_name`],
        region_id: data[`${prefix}province_id`],
        region_name: data[`${prefix}province`],
        city_id: data[`${prefix}city_id`],
        city_name: data[`${prefix}city`]
      }
    },
    /**
     * 格式化地址
     * @param data
     * @param prefix
     * @param separator
     * @returns {string}
     * @constructor
     */
    MixinFormatRegions(data, prefix = '', separator = '') {
      const country_code = data[`${prefix}country_code`]
      let address = []
      if (!country_code || country_code === 'CN') {
        if (data[`${prefix}province`]) address.push(data[`${prefix}province`])
        if (data[`${prefix}city`]) address.push(data[`${prefix}city`])
        if (data[`${prefix}county`]) address.push(data[`${prefix}county`])
        if (data[`${prefix}town`]) address.push(data[`${prefix}town`])
      } else {
        address.push(data[`${prefix}country_name`])
        address.push(data[`${prefix}province`])
        address.push(data[`${prefix}city`])
      }
      if (separator === false) return address
      return address.join(separator)
    },
    /**
     * 获取最后一级地区id
     * @param region
     * @param prefix
     * @constructor
     */
    MixinLastRegionId(region, prefix = '') {
      const names = {
        province: `${prefix}province_id`,
        city: `${prefix}city_id`,
        county: `${prefix}county_id`,
        town: `${prefix}town_id`
      }
      for (const key of ['town', 'county', 'city', 'province']) {
        const value = region[names[key]];
        if (value !== undefined && value !== null && value !== 0 && value !== '0') {
          return value;
        }
      }
      return undefined;
    }
  }
}