import jwt_decode from './jwt-decode'

//缓存的Key
export const Keys = {
  uid: 'uid',
  uuid: 'uuid',
  wxopenid: 'wxopenid',
  user: 'user',
  wxauth: 'wxauth',
  loginResult: 'loginResult',
  accessToken: 'accessToken',
  searchHistory: 'searchHistory',
  refreshToken: 'refreshToken',
  site: 'site',
  h5LoginLastPage: 'h5LoginLastPage',
  oldUuid: 'oldUuid',
  su: 'su', // 当前携带进入的分销关系
  lang: 'mobileLanguage',
  locales: 'locales',
  languages: 'languages',
  newlyRegisteredUser: 'newlyRegisteredUser', // 是否为新注册用户
  clientType: 'clientType',
  currencies: 'currencies',
  baseCurrency: 'baseCurrency',
  currentCurrency: 'currentCurrency'
}


//App缓存数据
class Cache {
  setItem(key, value) {
    try {
      uni.setStorageSync(`m_${key}`, value)
    } catch (e) {
      console.log(e)
    }
  }

  getItem(key) {
    const value = uni.getStorageSync(`m_${key}`)
    if (value && key === Keys.refreshToken) {
      if ((Date.now() / 1000) >= jwt_decode(value).exp) {
        return null
      }
    }
    return value
  }

  removeItem(key) {
    return uni.removeStorageSync(`m_${key}`)
  }

  /**
   * 登录后的会员信息
   * @return {如果返回null，则需要重新登录}
   */
  user() {
    const user = this.getItem(Keys.user)
    if (user === '' || user === null) {
      return null
    }
    return user
  }
}


export default new Cache()
