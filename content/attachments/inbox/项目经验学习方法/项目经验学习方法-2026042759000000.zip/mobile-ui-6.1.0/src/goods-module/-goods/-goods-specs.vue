<template>
	<view class="specs">
    <view class="specs-view" @click="specsShow = true">
      <view>
        <text class="bold-text">已选</text>
      </view>
      <view class="content-view u-margin-left-20">
        <text v-if="!selectedSku">未选规格</text>
        <text v-else>{{ selectedSpecVals.length ? selectedSpecVals.join('-') : '默认规格' }} × {{buyNum}}</text>
      </view>
      <view>
        <u-icon class="collection-icon u-margin-right-10" name="more-dot-fill" size="36"></u-icon>
      </view>
    </view>
    <view v-if="noSkuForSelectSpecs" class="no-sku-error">当前所选规格没有对应商品</view>
    <!-- 商品规格弹出层 -->
    <u-popup v-model="specsShow" mode="bottom" length="70%" closeable close-icon-size="20" border-radius="20" class="goods-popup-header">
      <view class="specs-headr u-p-20">
        <u-image width="200rpx" height="200rpx" :src="selectedSpecImg || selectedSku.thumbnail || goods.thumbnail" style="flex-shrink: 0"></u-image>
        <view class="price-header">
          <view class="price-text p" v-if="promotionsPrice">
            <custom-price :price="promotionsPrice" :size="45" fontWeight="bold" />
            <text v-if="needPoint" class="point-text">+{{ needPoint }}积分</text>
          </view>
          <view class="price-text a" v-else-if="assemble.id">
			      <custom-price :price="assemble.sales_price" :size="45" fontWeight="bold"/>
          </view>

          <view class="price-text" v-else>
            <text v-if="selectedSku.price"><custom-price :price="selectedSku.price" :size="45" fontWeight="bold"></custom-price></text>
            <text v-if="goods.point_disable === 1" class="exchange-point"> {{selectedSku.price ? '+' : ''}}{{ selectedSku.exchange_point }}积分</text>
          </view>
          <view class="u-m-t-20">
            <text class="specs-name">已选</text>
            <text class="specs-value">{{selectedSku ? selectedSpecVals.join('-') : '未选规格'}} × {{buyNum}}</text>
          </view>
        </view>
      </view>

      <scroll-view scroll-y="true" class="specs-body" >
        <view class="specs-list u-p-20" v-for="(spec, specIndex) in specList" :key="specIndex">
          <view>
            <text class="bold-text">{{spec.spec_group_name}}</text>
          </view>
          <view class="u-p-t-30">
            <u-button
              v-for="(spec_val, index) in spec.value_list"
              :key="index"
              size="mini"
              class="u-m-r-30"
              shape="circle"
              :plain="true"
              hover-class="none"
              :type="spec_val.selected ? 'error' : 'default'"
              @click="handleClickSpec(spec, specIndex, spec_val)"
              throttle-time="10"
              :custom-style="specStyle"
            >
              {{spec_val.spec_value}}
            </u-button>
          </view>
        </view>
        <view class="u-padding-20 u-flex u-row-between">
          <text class="bold-text">数量</text>
          <u-number-box v-model="buyNum" :min="1" :max="selectedSku.enable_quantity" @change="handleBuyNumChange"/>
        </view>
      </scroll-view>
      <view class="specs-footer">
        <view v-if="noSkuForSelectSpecs" class="no-sku-error">当前所选规格没有对应商品</view>
        <view class="btn-view u-flex">
          <view v-if="selectedSku.enable_quantity === 0" class="inventory btn u-line-1 u-flex-1">暂无库存</view>
          <template v-else>
            <view v-if="!crowdfundingShowFlag" :class="{disabled: buyNowBtnDisabled}" class="cart btn u-line-1 u-text-center u-flex-1" @click="handleAddCart">加入购物车</view>
            <view v-if="!crowdfundingShowFlag" :class="{disabled: buyNowBtnDisabled}" class="buy btn u-line-1 u-text-center u-flex-1" @click="handleBuyNow">立即购买</view>
            <view v-if="crowdfundingShowFlag" class="crowdfunding-buy btn u-line-1 u-text-center u-flex-1" @click="$emit('buy-now')">立即支持</view>
          </template>
        </view>
      </view>
    </u-popup>
	</view>
</template>

<script>
import * as API_Goods from '@/api/goods.js'
import { Foundation } from '@/app-utils/index.js'

export default {
  data() {
    return {
      specsShow: false,
      // 购买数量
      buyNum: 1,
      // skuMap
      skuMap: new Map(),
      // 规格列表
      specList: [],
      // 被选中规格
      selectedSpec: [],
      selectedSpecVals: [],
      // sku的规格值组合列表
      skuSpecValIds: [],
      // 规格组合列表
      skusCombination: [],
      // 被选中sku
      selectedSku: '',
      // 被选中的规格图片【如果有】
      selectedSpecImg: '',
      // 没有选中sku，初始化为false
      unselectedSku: false,
      // 商品原价
      promotionsPrice: 0,
      needPoint: 0,
      specStyle: {
        padding: '20rpx 40rpx',
        fontWeight: 600,
      },
      // 当前选择的规格没有对应的sku
      noSkuForSelectSpecs: false
    }
  },
  props: {
    goods: {
      type: Object,
      default() {
        return {}
      }
    },
    promotions: {
      type: Array,
      default() {
        return []
      }
    },
    sku_id: {
      type: String,
      default: ''
    },
    show: {
      type: Boolean,
      default: false
    },
    assemble: {
      type: Object,
      default: {}
    },
    activity_id: {
      type: String,
      default: ''
    },
    // 是否显示众筹
    crowdfundingShowFlag: {
      type: Boolean,
      default: false
    },
    // 众筹是否已结束
    crowdfundingEndFlag: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    buyNowBtnDisabled() {
      return this.noSkuForSelectSpecs
    },
    addCartBtnDisabled() {
      return this.noSkuForSelectSpecs
    },

  },
  watch: {
    show(newVal) {
      this.specsShow = newVal
    },
    specsShow(newVal) {
      this.$emit('close', newVal)
    },
    selectedSku(newVal) {
      this.$emit('sku-changed', newVal)
    },
    buyNum(newVal) {
      this.$emit('num-changed', newVal)
    },
    promotions(newVal) {
      const _promotions = newVal.filter(key => key.sku_id === (this.selectedSku.sku_id || this.sku_id))
      const _prom = _promotions.filter(key => key.promotion_type === 'SECKILL' || key.promotion_type === 'GROUPBUY' || key.promotion_type === 'EXCHANGE')

      // 如果是限时抢购或者团购促销活动不显示原价格
      if (_prom && _prom[0]) {
        if (_prom[0].promotion_type === 'SECKILL') {
          this.promotionsPrice = _prom[0].price
        } else if (_prom[0].promotion_type === 'GROUPBUY') {
          this.promotionsPrice = _prom[0].groupbuy_goods_vo.price
        } else if (_prom[0].promotion_type === 'EXCHANGE') {
          this.promotionsPrice = _prom[0].exchange.exchange_money
          this.needPoint = _prom[0].exchange.exchange_point
        } else {
          this.promotionsPrice = false
        }
      }
    }
  },
  mounted() {
    API_Goods.getGoodsSkus(this.goods.goods_id).then(res => {
      let skus = res
      if(this.crowdfundingShowFlag){
        skus = skus.filter(sku => sku.sku_id === this.sku_id)
      }
      const specList = []
      skus.sort((a, b) => a.sku_sort - b.sku_sort).forEach((sku, skuIndex) => {
        const { spec_list } = sku
        const spec_value_sns = []
        let _combination = []

        if (!Array.isArray(spec_list) || !spec_list.length) {
          this.skuMap.set('no_spec', sku)
          return
        }
        spec_list.forEach(spec => {
          const sp = specList.find(item => item.spec_group_sn === spec.spec_group_sn)
          const _spec = {
            spec_group_sn: spec.spec_group_sn,
            spec_group_name: spec.spec_group_name
          }
          const _value = {
            spec_value: spec.spec_value_name,
            spec_value_sn: spec.spec_value_sn
          }
          if (spec.spec_value_image) {
            _value.spec_value_image = spec.spec_value_image
          }
          _combination.push(_value)
          spec_value_sns.push(spec.spec_value_sn)
          if (!sp) {
            specList.push({ ..._spec, value_list: [_value] })
            return
          }
          const sv = sp.value_list.find(item => item.spec_value_sn === spec.spec_value_sn)
          if (!sv) {
            sp.value_list.push(_value)
          }
        })
        this.skuSpecValIds.push(spec_list.map(item => item.spec_value_sn).join(','))
        this.skusCombination.push(_combination)
        this.skuMap.set(spec_value_sns.join('-'), sku)
      })
      this.specList = specList
      // 如果有sku信息，初始化已选规格
      if (this.sku_id) {
        this.initSpec()
      } else if (this.specList) {
        // 默认选中第一个sku
        const _selectedSpecVals = []
        this.specList.forEach((spec, specIndex) => {
          if (!Array.isArray(spec.value_list)) return
          spec.value_list.forEach((val, specValIndex) => {
            if (specValIndex !== 0) return
            val.selected = true
            this.selectedSpec[specIndex] = val.spec_value_sn
            _selectedSpecVals.push(val.spec_value)
          })
        })
        this.$set(this, 'selectedSpecVals', _selectedSpecVals)
        this.handleSelectedSku(true)
      }
      // 如果没有规格，把商品第一个可选sku给已选择sku
      if (!specList.length) {
        this.selectedSku = this.skuMap.get('no_spec')
      }
      this.computedHasSkuForSelectedSpecs()
    })
  },
  methods: {
    //初始化规格
    initSpec() {
      let selectedSpecs = ''
      if (this.sku_id) {
        this.skuMap.forEach((value, key) => {
          if (value.sku_id === this.sku_id) {
            selectedSpecs = key.split('-')
          }
        })
      }
      const _selectedSpecVals = []
      this.specList.forEach((spec, specIndex) => {
        if (!Array.isArray(spec.value_list)) return
        spec.value_list.forEach((val, specValIndex) => {
          if (selectedSpecs) {
            const spec_value_sn = val.spec_value_sn
            if (selectedSpecs.indexOf(String(spec_value_sn)) !== -1) {
              val.selected = true
              this.selectedSpec[specIndex] = val.spec_value_sn
              _selectedSpecVals.push(val.spec_value)
            }
          } else if (specValIndex === 0) {
            val.selected = true
            this.selectedSpec[specIndex] = val.spec_value_sn
            _selectedSpecVals.push(val.spec_value)
          }
        })
      })
      this.$set(this, 'selectedSpecVals', _selectedSpecVals)
      this.handleSelectedSku()
    },
    // 选择规格
    handleClickSpec(spec, specIndex, spec_val) {
      if (spec_val.spec_value_image) {
        this.selectedSpecImg = spec_val.spec_value_image
      }
      if (spec_val.selected) return
      spec.value_list.map(item => {
        item.selected = item.spec_value_sn === spec_val.spec_value_sn
        return item
      })
      this.$set(this.specList, specIndex, spec)
      this.selectedSpec[specIndex] = spec_val.spec_value_sn
      this.selectedSpecVals[specIndex] = spec_val.spec_value
      const noSku = this.computedHasSkuForSelectedSpecs()
      if (!noSku) {
        this.handleSelectedSku(true)
      }
    },
    // 根据已选规格选出对应的sku
    handleSelectedSku(flag) {
      let sku
      if (this.selectedSpec.length) {
        const spec_vals = []
        this.selectedSpec.forEach(item => spec_vals.push(item))
        sku = this.skuMap.get(spec_vals.join('-'))
      } else {
        sku = this.skuMap.get('no_spec')
      }
      if (!sku) return
      this.selectedSku = sku
      this.unselectedSku = false
      this.goodsInfo = { ...this.goodsInfo, ...sku }
      this.buyNum = sku.enable_quantity === 0 ? 0 : 1
      if (sku.sku_image) {
        this.selectedSpecImg = sku.sku_image
      }
      if (!flag) return
      if (!this.promotions || !this.promotions.length) return
      const _promotions = this.promotions.filter(key => key.sku_id === (this.selectedSku.sku_id || this.sku_id))
      if (!_promotions.length) return
      let _prom = _promotions.filter(key => key.promotion_type === 'GROUPBUY' || key.promotion_type === 'SECKILL')
      if (_prom && _prom[0] && _prom[0].promotion_type === 'GROUPBUY') {
        this.promotionsPrice = _prom[0].groupbuy_goods_vo.price
      } else if (_prom && _prom[0] && _prom[0].promotion_type === 'SECKILL') {
        this.promotionsPrice = _prom[0].seckill_goods_vo.seckill_price
      } else {
        this.promotionsPrice = false
      }
    },
    //购买数量
    handleBuyNumChange(e) {
      this.buyNum = e.value
    },
    computedHasSkuForSelectedSpecs() {
      const ids = this.selectedSpec.join(',')
      const noSku = !this.skuSpecValIds.includes(ids)
      if (!this.skuSpecValIds.length) return false
      this.noSkuForSelectSpecs = noSku
      this.$emit('no-sku', noSku)
      return noSku
    },
    async handleBuyNow() {
      if (this.noSkuForSelectSpecs) return

      this.$emit('buy-now')
    },

    handleAddCart() {
      if (this.noSkuForSelectSpecs) return

      this.$emit('add-cart')
    }
  }
}
</script>

<style lang="scss" scoped>
.specs {
  border-radius: 15rpx;
  margin-top: 23rpx;
  background-color: #FFFFFF;
  .buy-max {
    line-height: 80rpx;
    text-align: center;
  }
  .spec-text {
    font-size: 24rpx;
    color: #999;
  }
  .spec-text-price {
    color: #ff0000;
  }
  .specs-view {
    padding: 30rpx;
    display: flex;
    align-items: center;
    padding-bottom: 20rpx;
    .left-view {
      margin-right: 20rpx;
    }
    .bold-text {
      font-weight: bold;
    }
    .content-view {
      flex: 1;
    }
  }
  //规格选择器弹出框
  .goods-popup-header {
    z-index: 888 !important;
    .specs-headr {
      display: flex;
      flex-direction: row;
      background-color: #FFFFFF;
      min-height: 240rpx;
      width: 100%;
      .price-header {
        width: calc(100% - 114rpx);
        margin-left: 30rpx;
        margin-top: 12rpx;
        .price-text {
          font-size: 45rpx;
          font-weight: bold;
          color: #FF0000;
          margin-top: 20rpx;
        }
        .point-text {
          display: flex;
          font-size: 28rpx;
          color: #FF0000;
        }
        .specs-name {
          color: #909399;
          margin-right: 10rpx;
        }
        .specs-price {
          color: #FF0000;
          font-weight: 500;
          font-size: 26rpx;
        }
        .specs-value {
          font-weight: 400;
        }
      }
    }
    .specs-body {
      // height: calc(100vh - 750rpx);
      height: 570rpx;
      // #ifdef MP
      height: 500rpx;
      // #endif
      overflow-x: hidden;
    }
    .specs-footer {
      width: 100%;
      position: fixed;
      left: 0;
      bottom: 0;
      z-index: 999;
      color: #FFFFFF;
      font-size: 28rpx;
      .btn-view {
        padding: 0 20rpx;
        padding-top: 10rpx;
        border-top: 2rpx solid #f3f4f6;
        padding-bottom: 24rpx;
        /* #ifndef H5 */
        padding-bottom: constant(safe-area-inset-bottom);
        padding-bottom: env(safe-area-inset-bottom);
        /* #endif */
      }
      .btn {
        line-height: 80rpx;
        padding: 0 30rpx;
        text-align: center;
        &.disabled {
          background: #d3d2d2;
        }
      }
      .inventory {
        filter: opacity(0.7);
        border-radius: 40rpx;
        background: linear-gradient(to right, #FFCA1E 0%, #EF0D25 100%);
      }
      .cart {
        border-top-left-radius: 40rpx;
        border-bottom-left-radius: 40rpx;
        background: linear-gradient(to right, #FFCA1E 0%, #FF8B18 100%);
      }
      .buy {
        border-top-right-radius: 40rpx;
        border-bottom-right-radius: 40rpx;
        background: linear-gradient(to right, #FD5632 0%, #EF0D25 100%);
      }
      .crowdfunding-buy {
        border-radius: 40rpx;
        background: linear-gradient(to right, #FD5632 0%, #EF0D25 100%);
      }
    }
  }
}
.no-sku-error {
  color: red;
  padding: 0 30rpx;
  padding-bottom: 12rpx;
}

</style>
