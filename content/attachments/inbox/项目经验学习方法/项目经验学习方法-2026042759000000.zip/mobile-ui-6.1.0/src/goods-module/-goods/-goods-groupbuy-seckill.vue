<template>
    <view class="" v-if="promotion && showPromotion">
        <!--团购活动-->
        <goods-prom-bar
          v-if="showGroupbuy"
          title="团购活动"
          type="groupbuy"
          :price="promotion.groupbuy_goods_vo.price"
          :oldprice="promotion.groupbuy_goods_vo.original_price"
          :endtime="promotion.end_time - parseInt(new Date() / 1000)"
          @count-end="handleCountEnd"
        />
        <!--限时抢购-->
        <goods-prom-bar
          v-if="showSeckill"
          title="限时抢购"
          type="seckill"
          :collected="collected"
          :price="promotion.price"
          :oldprice="promotion.origin_price"
          :endtime="promotion.distance_end_time"
          @count-end="handleCountEnd"
          @handleShare="handleShare"
          @handleCollect="handleCollect"
        />
    </view>
</template>

<script>
    /**
     * 商品详情页团购、限时抢购组件
     *
     * ===== 使用场景 ======
     * 商品详情页。
     *
     * ===== 参数 =====
     * promotions      促销活动
     */
    import GoodsPromBar from './-goods-prom-bar.vue'
	export default {
        data() {
            return {
                showPromotion: true,
                showGroupbuy:false,
                showSeckill:false
            }
        },
        props: {
            collected: {
                type: Boolean,
                default: ''
            },
            promotions: {
                type: Array,
                default() {
                    return []
                }
            },
            selectedSku: {
                type: Object,
                default() {
                    return {}
                }
            },
        },
        components: {
            GoodsPromBar
        },
        computed: {
            promotion() {
                const { promotions, selectedSku } = this
                if (!promotions || !promotions.length) return false
                // 先试试看有没有团购活动
                let prom = promotions.filter(item => item.groupbuy_goods_vo)
                // 如果有团购活动，活动类型标记为groupbuy
                if (prom && prom[0]) {
                    const _promot = prom.filter(key => key.sku_id === selectedSku.sku_id)
                    this.showGroupbuy = true
                    if (!_promot || !_promot[0]) return false
                    return _promot[0]

                } else {
                  // 否则再试试有没有限时抢购活动
                    prom = promotions.filter(item => item.promotion_type === 'SECKILL')
                    if (prom) {
                        const _promot = prom.filter(key => key.sku_id === selectedSku.sku_id)
                        this.showSeckill = true

                        if (!_promot || !_promot[0]) return false
                        return _promot[0]
                    }
                }
                // 如果都没有，返回false
                if (!prom || !prom[0]) return false
                return prom[0]
            }
        },
		methods: {
            /** 分享 */
            handleShare() {
                this.$emit('handleShare')
            },
            //收藏
            handleCollect() {
                this.$emit('handleCollect')
            },
            handleCountEnd() {
                this.showPromotion = false
                this.$u.toast('活动已结束，商品已恢复原价。')
                setTimeout(()=>{
                    this.$emit('count-ends')
                },200)
            }
        }
	}
</script>

<style lang="scss" scoped>

</style>
