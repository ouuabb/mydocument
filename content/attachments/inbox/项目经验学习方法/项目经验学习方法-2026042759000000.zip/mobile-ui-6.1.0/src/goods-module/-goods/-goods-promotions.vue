<template>
	<view v-if="showPromotions">
        <view class="promotion-view" @click="showPopup = true">
            <view>
                <text class="bold-text">促销</text>
            </view>
            <view class="content-view u-flex-wrap u-margin-left-20 u-margin-right-20 u-line-2">
                <view class="promotion-info-view u-line-2" v-for="(prom, index) in promotions" :key="index">
                    <view class="u-m-t-10 u-m-r-10" v-if="prom.promotion_type && ((prom.promotion_type === 'PINTUAN' && is_assemble) || prom.promotion_type !== 'PINTUAN')">
                        <u-tag :text="prom.promotion_tag" type="error" mode="plain" />
                    </view>
                </view>
            </view>
            <view>
                <u-icon class="collection-icon u-margin-right-10" name="more-dot-fill" size="36"></u-icon>
            </view>
        </view>
        <!-- 促销弹出层 -->
        <u-popup v-model="showPopup" mode="bottom" length="auto" border-radius="20" :safe-area-inset-bottom="true" closeable close-icon-size="20">
            <view class="u-m-30 u-text-center pop-title">
                促销
            </view>
            <view class="promotion-list-view u-line-1">
              <view v-for="(prom, index) in promotions" :key="index">
                <view
                  :class="['promotion-info-view', 'u-line-1', {'item-border': index + 1 !== promotions.length}]"
                  v-if="prom.promotion_type && ((prom.promotion_type === 'PINTUAN' && is_assemble) || prom.promotion_type !== 'PINTUAN')">
                      <view class="u-m-b-20 promotion-tag-item" >
                          <u-tag
                              :text="prom.promotion_tag"
                              type="error"
                              mode="plain"
                              class="promotion-tag" />
                          <text v-if="prom.promotion_type === 'HALF_PRICE'" class="tag-text">购买双数商品即可享受第二件半价优惠，优惠可叠加，多买多减！</text>
                          <text v-if="prom.promotion_type === 'MINUS'"  class="tag-text">购买1件直接立减{{prom.single_reduction_value}},优惠可叠加，多买多减！</text>
                          <text class="tag-text" v-if="prom.promotion_type === 'FULL_GIVE' || prom.promotion_type === 'FULL_MINUS'"> 优惠详情如下：</text>
                          <view class="tag-text" v-if="prom.promotion_type === 'SECKILL'">
                              <text>距离活动结束：</text>
                              <text v-if="seckillTimer.day > 0" class="day">{{seckillTimer.day}}天</text>
                              <text class='time'>{{seckillTimer.hours}}：{{seckillTimer.minutes}}：{{seckillTimer.seconds}}</text>
                          </view>
                          <view class="tag-text" v-if="is_assemble && prom.promotion_type === 'PINTUAN'">
                              <text>距离活动结束：</text>
                              <text v-if="pintuanTimer.day > 0" class="day">{{pintuanTimer.day}}天</text>
                              <text class='time'>{{pintuanTimer.hours}}：{{pintuanTimer.minutes}}：{{pintuanTimer.seconds}}</text>
                          </view>
                      </view>
                      <view class="tag-text" v-if="is_assemble && prom.promotion_type === 'PINTUAN'" @click="toPintuanList">活动时间有限，请尽快购买！点击查看更多活动商品>></view>
                      <!-- 秒杀消息活动 -->
                      <navigator
                          url="/promotion-module/seckill/seckill"
                          hover-class="none"
                          class="tag-text"
                          v-if="prom.promotion_type === 'SECKILL'">
                          活动时间有限，请尽快购买！点击查看更多活动商品>>
                      </navigator>
                      <!-- 满赠详细描述 -->
                      <template v-if="prom.promotion_type === 'FULL_GIVE'">
                          <view
                              class="give-box"
                              v-for="(child, index) in prom.full_give_info.step_list"
                              :key="index">
                              <view class="title-box">
                                  <text class="line"></text>
                                  <text class="item-title">购满{{child.threshold}}{{prom.full_give_info.discount_type === 2 ? '件' : ''}}可享</text>
                                  <text class="line"></text>
                              </view>
                              <view class="give-item" v-if="child.is_free_ship === 1">
                                  <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/baoyou.png" alt=""/>
                                  <text>免邮费</text>
                              </view>
                              <view class="give-item" v-if="child.is_send_point === 1">
                                  <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/jifen.png" alt=""/>
                                  <text>送{{child.point_value}}积分</text>
                              </view>
                              <view class="give-item" v-if="child.is_send_bonus === 1">
                                  <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/youhuiquan.png" alt=""/>
                                  <text>赠送一张满{{child.coupon.coupon_threshold_price}}减{{child.coupon.coupon_price}}优惠券</text>
                              </view>
                              <view class="give-item" v-if="child.is_send_gift === 1">
                                  <image class="give-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/zengping.png" alt=""/>
                                  <text>送价值{{child.gift.gift_price}}的{{child.gift.gift_name}}一份</text>
                              </view>
                          </view>
                      </template>
                      <!-- 满减详细描述 -->
                      <template v-if="prom.promotion_type === 'FULL_MINUS'" >
                          <view sf-text-rule="full_minus_tips"
                              style="margin-bottom: 10rpx;"
                              v-for="(child, index) in prom.full_minus_info.step_list"
                              :key="index">
                              {{`购满${child.threshold}${prom.full_minus_info.discount_type === 1 ? '' : '件'}${child.type === 1 ? '立减' : '享'}${child.discount}${child.type === 1 ? '' : '折优惠'};`}}
                          </view>
                      </template>
                </view>
              </view>
            </view>
        </u-popup>
	</view>
</template>

<script>
    /**
     * 商品详情页促销组件
     *
     * ===== 使用场景 ======
     * 商品详情页。
     *
     * ===== 参数 =====
     * promotions  促销活动
     */
    import { Foundation } from '@/app-utils/index.js'

    export default {
        data() {
            return {
                showPopup: false,
                seckillTimer: {
                    timer:null,
                    day:0,
                    hours:'00',
                    minutes:'00',
                    seconds:'00'
                },
                pintuanTimer: {
                    timer:null,
                    day:0,
                    hours:'00',
                    minutes:'00',
                    seconds:'00'
                }
            }
        },
        props: {
            promotions: {
                type: Array,
                default() {
                    return []
                }
            },
            assemble: {
                type:Object,
                default: {}
            },
            is_assemble: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            showPromotions() {
                const promotions = this.promotions
                return promotions.length && (promotions.length > 1 || ((promotions[0].promotion_type === 'PINTUAN' && this.is_assemble) || promotions[0].promotion_type !== 'PINTUAN'))
            }
        },
        watch: {
            promotions: {
                handler(val) {
                    if (val && val.length) {
                        val.forEach(item => {
                            if (item.promotion_type === 'SECKILL') {
                                this.contDown(item.distance_end_time, 'seckillTimer')
                            }
                        })
                    }
                },
                immediate: true
            },
            assemble: {
                handler(val) {
                    if (val.time_left) {
                        this.contDown(val.time_left, 'pintuanTimer')
                    }
                }
            }
        },
        destroyed() {
            clearInterval(this.timer)
        },
        methods: {
            toPintuanList() {
                uni.navigateTo({
                    url: '/promotion-module/assemble/assemble'
                })
            },
            /** 秒杀倒计时 */
            contDown(end_ime, timerType) {
                this[timerType].timer = setInterval(() => {
                    if (end_ime <= 0) {
                        clearInterval(this[timerType].timer)
                    } else {
                        const time = Foundation.countTimeDown(end_ime)
                        this[timerType].day = parseInt(time.day)
                        this[timerType].hours = time.hours
                        this[timerType].minutes = time.minutes
                        this[timerType].seconds = time.seconds
                        end_ime--
                    }
                }, 1000)
            }
        },
	}
</script>

<style lang="scss" scoped>
    .pop-title {
        font-weight: 600;
    }
    .promotion-list-view {
        padding: 20rpx;

        .promotion-info-view {
            padding-bottom: 20rpx;
            margin-bottom: 40rpx;
            .give-box {
                .give-item {
                    padding: 0 20rpx;
                    display: flex;
                    align-items: center;
                    font-size: 24rpx;
                    margin: 14rpx 0;
                    .give-icon {
                        width: 50rpx;
                        height: 50rpx;
                        margin-right: 20rpx;
                    }
                }

                .title-box {
                    text-align: center;
                    margin: 20rpx 0;
                    .line {
                        display: inline-block;
                        min-width: 260rpx;
                        border-top: 1rpx solid #efefef;
                    }
                    .item-title {
                        font-size: 24rpx;
                        color: #333;
                        text-align: center;
                        margin: 0 20rpx;
                        vertical-align: middle;
                    }
                }

            }
        }
        .item-border {
            border-bottom: 1rpx solid #999;
        }


    }
    .tag-text {
        white-space: break-spaces;
        font-size: 24rpx;
    }
    .promotion-tag-item {
        display: flex;
        align-items: center;
        .promotion-tag {
            margin-right: 20rpx;
        }

        .u-tag {
            margin-right: 20rpx;
            padding: 8rpx !important;
            font-size: 20rpx;
        }
    }
    .promotion-view {
        padding: 30rpx;
        display: flex;
        align-items: center;
        padding-bottom: 20rpx;
        background-color: #FFFFFF;
        .prom-content {
            display: flex;
        }
        .left-view {
            margin-right: 20rpx;
        }
        .bold-text {
            font-weight: bold;
        }
        .content-view {
            display: flex;
            flex: 1;
        }
    }
</style>
