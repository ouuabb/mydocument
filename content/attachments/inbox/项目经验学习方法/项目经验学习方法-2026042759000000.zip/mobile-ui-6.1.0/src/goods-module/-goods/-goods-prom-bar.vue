<template>
	<view class="prom-bar-container">
        <view class="prom-bar-content">
            <view class="msg">
              <view class="text" v-if="type !== 'crowdfunding'">
                <text class="old-price">{{ oldprice | unitPrice('￥') }}</text>
              </view>
              <view class="text">
                <text class="icon" :class="[type]">{{ title }}</text>
              </view>
            </view>
            <view class="prom-bar-box">
                <view class="u-flex">
                    <custom-price :price="price" :size="50" textColor="#FFFFFF"></custom-price>
                    <view class="text">
                      <custom-price class="old-price" :price="oldprice" textColor="#fff" line-through/>
                    </view>
                </view>
                <view class='count-down'>
                    <view v-if="endFlag" class='count-down-text-end'>活动已结束</view>
                    <view v-else class='count-down-text'>距离结束还剩</view>
                    <view v-if="!endFlag" class='count-down-times'>
                        <text v-if="day > 0" class="day">{{day}}天</text>
                        <text class='time'>{{hours}}</text>:
                        <text class='time'>{{minutes}}</text>:
                        <text class='time'>{{seconds}}</text>
                    </view>
                </view>
            </view>

        </view>
        <view class="u-flex share-box">
            <view class="u-text-center u-m-r-30" @click="handleShare">
                <u-icon class="icon" name="fenxiang1" custom-prefix="custom-icon" size="40"></u-icon>
                <view class="u-font-10">
                    <text class="collection-text">分享</text>
                </view>
            </view>
            <view class="u-text-center" @click="handleCollect">
                <u-icon :class="[{'collection-icon-selected': collected}, 'icon']" :name="collected ? 'heart-fill' : 'heart'" size="40"></u-icon>
                <view class="u-font-10">
                    <text class="collection-text"> {{ collected ? '已收藏' : '收藏'}}</text>
                </view>
            </view>
        </view>
	</view>
</template>

<script>
    /**
     * 商品详情页团购、限时抢购组件
     *
     * ===== 使用场景 ======
     * 商品详情页。
     *
     * ===== 参数 =====
     * type      活动类型
     * title     活动标题
     * price     价格
     * oldprice  原价
     * endtime   结束时间
     */
    import { Foundation } from '@/app-utils/index.js'

	export default {
		data() {
			return {
                timer:null,
                day:0,
                hours:'00',
                minutes:'00',
                seconds:'00'
			};
		},
        props: {
            collected: {
                type: Boolean,
                default: ''
            },
            type: {
                type: String,
                default: ''
            },
            title: {
                type: String,
                default: ''
            },
            price: {
                type: Number,
                default: 0,
            },
            oldprice: {
                type: Number,
                default: 0,
            },
            endtime: {
                type: [Number,String],
                default: 0,
            }
        },
        mounted() {
            this.contDown(this.endtime)
        },
        methods: {
            /** 分享 */
            handleShare() {
                this.$emit('handleShare')
            },
            //收藏
            handleCollect() {
                this.$emit('handleCollect')
            },
            contDown(times) {
                let end_ime = times
                this.timer = setInterval(() => {
                  if (end_ime <= 0) {
                    clearInterval(this.timer)
                    this.$emit('count-end')
                  } else {
                    const time = Foundation.countTimeDown(end_ime)
                    this.day = parseInt(time.day)
                    this.hours = time.hours
                    this.minutes = time.minutes
                    this.seconds = time.seconds
                    end_ime--
                  }
                }, 1000)
            }
        },
        destroyed() {
            clearInterval(this.timer)
        }
	}
</script>

<style lang="scss" scoped>
    .prom-bar-container {
        display: flex;
        align-items: center;
        z-index: 10;
        color: #fff;
        display: flex;
        align-items: center;
        .prom-bar-content {
            min-width: 76%;
            height: 100%;
            background-size: 259px,100%;
            background: url(https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/background-promotion-bar.png) no-repeat,-webkit-linear-gradient(top,#fc5997,#ef4747);
            .prom-bar-box {
                display: flex;
                align-items: center;
                justify-content: space-between;
                line-height: 40rpx;
                width: 100%;
                .old-price {
                    margin-left: 20rpx;
                }
            }
        }
        .share-box {
            width: 24%;
            display: flex;
            align-items: center;
            justify-content: center;
            .icon {
                color: #333;
            }
            .collection-icon-selected {
                color: #FF0000;
            }
            .collection-text {
                color: #333;
            }
        }
        .prom-price {
          margin: 0 10px;
          font-size: 14px;
          font-weight: 700;
          em {
            font-size: 24px;
          }
        }
        .msg {
          font-size: 12px;
            margin: 10rpx 0 0 10rpx;

          .icon {
            position: relative;
            display: inline-block;
            margin: -2px 3px 0 0;
            padding: 0 3px 0 18px;
            height: 15px;
            vertical-align: middle;
            line-height: 15px;
            font-size: 10px;
            &.seckill::before {
              background: #fff url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYBAMAAAASWSDLAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAwUExURUdwTNgqL+M4O+Q5O/8AAOQ5POM4O+Q4POQ5POQ4O+M4O+Q5OeQ5O+M5POQ4POQ5PF/0sUwAAAAPdFJOUwAGVuAC+ZDVrGlwKL3xQxKSapEAAACzSURBVBjTY2BgYOD9////BQYoQOEwMPwHYgFkjg2EJ9T8v0KRIf8giM1kD9TzWcHtB5DNkv99teCu+m8uOUAO29cpQNIzPgGkSj8OrPHpJyDBaD+BgecAAwPnZ6BpTN8dGPg/ALXWKzAwcPxiAHMY1jcwMDD/hnL2GzAwsH6EcuQDgK5E5oCUgUxjASkDGQAGIANARoMA2GiQpSAAthTFOagOhXkBohXqOaihQs2hFoogBgDIkUU0B3LhTAAAAABJRU5ErkJggg==) no-repeat 50%;
              background-size: 12px
            }
            &.groupbuy::before {
              background: #fff url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACP0lEQVQ4T32TwWvUQBSHfy/JDEULolIt3U1Q0SZV9OBBW1EPCgVBb0pVUMSDip70JAiC+heIJ8ViRbyJgmyxVKngtoLgoQqSXbdSTbJ21YtiizaT5ElWt7bbbec0MO/7ZubNbwiLjGLWuJxodIlAsmEZ8xtaiHdNcQOgbmIccoLwbX2dm8FK0kW5oaAKEx1o+hV2rv2GSgq7WblZj8OofQJuTeaaYmqewLXELWLapydh14YygipsyiMEvs4Ej4Bp21O7CYjnCBiggiVupjCrcFdHBR9rOxVMkWfwtQ4/GnQt8VpnvtDuRy9mBFXYFH0g6kYYds2G/55A9AGYBCUDBK1XKrVt3QQ+VQX/YRwWidq0PsBYfcPGVmOVkvIeCFs08EXbU3f/iaeoYMqrTLwfjCIIPx1PnSaAF3vedK3QBhuGGCXXEhWEqtOpwC+a8iGDvzu+OrGYZLwFrb+bZB6E+2njRijBHTtQtxkwiqbMMfjLQpJSK1oiIV8SOOf46jyVLLkxAg9TnJxyyvGDd4DULfGEGUG9xM9ixZQmR8D83PHV2fQq1RyU2sTW2MAQODnu+PHj8TVomk5EPzO+Or46ml7nw3IsU80iD2C4Bs8I0sn7rNieaBhEwj1OEA1UJbF4ykDQzOrcpCaeEWPU8dXJ2Q2ek8SiZexkUH9N8rkNS37oYogIDoCc7alj9c2dF+VCxtgDnR5p4IM0Gb2KlopBIvJtL+whIKl/3oafqZgx9rJOV8DYAUKv7akzafYbZeMPqbAF8MaxdIEAAAAASUVORK5CYII=) no-repeat 50%;
              background-size: 12px
            }
            &.crowdfunding::before {
              background: #fff url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACP0lEQVQ4T32TwWvUQBSHfy/JDEULolIt3U1Q0SZV9OBBW1EPCgVBb0pVUMSDip70JAiC+heIJ8ViRbyJgmyxVKngtoLgoQqSXbdSTbJ21YtiizaT5ElWt7bbbec0MO/7ZubNbwiLjGLWuJxodIlAsmEZ8xtaiHdNcQOgbmIccoLwbX2dm8FK0kW5oaAKEx1o+hV2rv2GSgq7WblZj8OofQJuTeaaYmqewLXELWLapydh14YygipsyiMEvs4Ej4Bp21O7CYjnCBiggiVupjCrcFdHBR9rOxVMkWfwtQ4/GnQt8VpnvtDuRy9mBFXYFH0g6kYYds2G/55A9AGYBCUDBK1XKrVt3QQ+VQX/YRwWidq0PsBYfcPGVmOVkvIeCFs08EXbU3f/iaeoYMqrTLwfjCIIPx1PnSaAF3vedK3QBhuGGCXXEhWEqtOpwC+a8iGDvzu+OrGYZLwFrb+bZB6E+2njRijBHTtQtxkwiqbMMfjLQpJSK1oiIV8SOOf46jyVLLkxAg9TnJxyyvGDd4DULfGEGUG9xM9ixZQmR8D83PHV2fQq1RyU2sTW2MAQODnu+PHj8TVomk5EPzO+Or46ml7nw3IsU80iD2C4Bs8I0sn7rNieaBhEwj1OEA1UJbF4ykDQzOrcpCaeEWPU8dXJ2Q2ek8SiZexkUH9N8rkNS37oYogIDoCc7alj9c2dF+VCxtgDnR5p4IM0Gb2KlopBIvJtL+whIKl/3oafqZgx9rJOV8DYAUKv7akzafYbZeMPqbAF8MaxdIEAAAAASUVORK5CYII=) no-repeat 50%;
              background-size: 12px
            }
            &::before {
              content: "";
              position: absolute;
              left: 0;
              top: 0;
              width: 15px;
              height: 15px;
              border-top-left-radius: 1px;
              border-bottom-left-radius: 1px;
            }
            &::after {
              content: "";
              display: block;
              border: 1px solid #fff;
              position: absolute;
              top: 0;
              left: 0;
              pointer-events: none;
              bottom: 0;
              right: 0;
              border-radius: 2px;
            }
          }
        }
        .count-down {
          min-width: 116px;
          margin-bottom: 10rpx;
          text-align: center;
          .count-down-text {
            margin-bottom: 2px;
            font-size: 10px;
            color: #fff;
          }
          .count-down-times {
            font-size: 14px;
            color: #FA3534;
          }
          .time {
            display: inline-block;
            margin: 0 1px;
            width: 23px;
            height: 21px;
            font-weight: 700;
            color: #fff;
            background-color: #333;
          }
          .day {
            font-size: 12px;
          }
        }
      }
</style>
