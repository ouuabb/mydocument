<template>
  <view class="goods-crowdfunding">
    <goods-prom-bar
      title="众筹活动"
      type="crowdfunding"
      :price="crowdfundingDetail.curr_price"
      :oldprice="crowdfundingDetail.goods_sku.price"
      :endtime="crowdfundingDetail.end_time - parseInt(new Date() / 1000)"
      @count-end="handleCountEnd"
    />
    <view class="crowdfunding-info">
      <view class="crowdfunding-top">
        <view class="info-item">
          已筹<span class="num">{{ crowdfundingDetail.already_price }}</span>元,
          已筹商品数量<span class="num">{{ crowdfundingDetail.already_goods_count }}</span>
        </view>
      </view>
      <view class="u-flex">
        <view class="u-flex-11">
          <progress class="crowdfunding-progress" activeColor="rgb(249, 93, 53)"
                    :percent="crowdfundingDetail.price_percent" stroke-width="3"/>
        </view>
        <view class="u-flex-1 progress-text">
          {{ formatProgressText(crowdfundingDetail.price_percent_int) }}
        </view>
      </view>
      <view class="crowdfunding-bottom">
        <view class="info-item">
          <span class="num">{{ crowdfundingDetail.already_people_count }}</span>人支持
        </view>
      </view>
    </view>

  </view>
</template>

<script>
import GoodsPromBar from './-goods-prom-bar.vue'

export default {
  data() {
    return {}
  },
  props: {
    crowdfundingDetail: {
      type: Object,
      default() {
        return {}
      }
    },
    crowdfundingEndFlag: {
      type: Boolean,
      default() {
        return false
      }
    }
  },
  components: {
    GoodsPromBar
  },
  methods: {
    handleCountEnd() {
      this.$emit('count-ends')
    },
    formatProgressText(percent) {
      if (percent > 999) {
        percent = 999
      }
      return percent + '%'
    }
  }
}
</script>

<style lang="scss" scoped>
.goods-crowdfunding ::v-deep .uni-progress-bar {
  .uni-progress-inner-bar {
    background: linear-gradient(to right, rgb(255, 153, 22), rgb(247, 76, 63))
  }
}
.crowdfunding-info {
  padding: 20rpx 25rpx;
  background-color: white;
  margin-bottom: 20rpx;

  .num {
    display: inline;
    font-size: 40rpx;
    color: #ff5000;
  }

  .crowdfunding-progress {
    width: 100wh;
  }

  .progress-text{
    margin-left: 15rpx;
    margin-bottom: 2rpx;
    color: rgb(249, 93, 53);
    font-weight: 700;
    font-size: 30rpx;
  }

  .crowdfunding-top {
    font-size: 26rpx;
    margin-bottom: -10rpx;
  }

  .crowdfunding-bottom {
    margin-top: -15rpx;
    font-size: 26rpx;
  }
}
</style>
