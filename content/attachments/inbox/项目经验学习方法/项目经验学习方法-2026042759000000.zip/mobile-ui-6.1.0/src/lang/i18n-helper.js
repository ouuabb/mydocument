import { i18n as openI18n } from '../config/config'

export function setTabBarTitle(i18n) {
  const locale = i18n.locale
  const messages = i18n.messages[locale] || {}
  const tabBarLocales = messages.tabBar
  // 如果没有tabBar翻译，就直接显示tabBar
  if (!tabBarLocales) {
    // #ifdef MP
    uni.showTabBar({})
    // #endif
    return
  }

  Object.keys(tabBarLocales).forEach(key => {
    uni.setTabBarItem({
      index: Number(key),
      text: tabBarLocales[key]
    })
  })

  // #ifdef MP
  uni.showTabBar({})
  // #endif
}

export const setPageTitleMixin = {
  onLoad() {
    if (!openI18n) return
    let pagePath
    // #ifdef MP
    if (this.mpType === 'page') {
      pagePath = this['__route__']
    }
    // #endif
    // #ifdef H5
    pagePath = this['route']
    // #endif
    // #ifdef APP-PLUS
    pagePath = this['$scope']['route']
    // #endif
    const messages = this.$i18n.messages[this.$i18n.locale]
    const title = messages.pages[pagePath]
    if (title) {
      uni.setNavigationBarTitle({title})
    }
  }
}
