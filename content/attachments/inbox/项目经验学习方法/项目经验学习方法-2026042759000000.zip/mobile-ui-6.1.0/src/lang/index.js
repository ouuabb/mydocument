import Vue from 'vue'
import VueI18n from './vue-i18n'
import { i18n as openI18n } from '../config/config'
import enUS from './en-US'
import zhCN from './zh-CN'
import * as API_Common from '../api/common'
import * as API_Currencies from '../api/currencies'
import Cache, { Keys } from '../utils/cache'
import { setTabBarTitle } from './i18n-helper'
import store from '@/store'

Vue.use(VueI18n)

let locale = Cache.getItem(Keys.lang)

if (!locale) {
  let sysInfo = uni.getSystemInfoSync()
  locale = sysInfo.language.replace('_', '-')
  Cache.setItem(Keys.lang, locale)
}

const i18n = new VueI18n({
  locale: locale || 'zh-CN',
  fallbackLocale: 'zh-CN',
  messages: {
    'zh-CN': zhCN,
    'en-US': enUS
  }
})

/**
 * 获取多语言支持列表以及语言包
 * @returns {Promise<void>}
 */
export async function loadLangAsync(loadCodes = true, lang) {
  if (!openI18n) return Promise.resolve()
  // #ifdef MP
  uni.hideTabBar()
  // #endif
  lang = lang || i18n.locale
  if (loadCodes) {
    let locales = Cache.getItem(Keys.locales)
    try {
      if (!locales || locales.length === 0) {
        locales = await API_Common.getLangCodes()
      } else {
        // 稍后更新数据
        API_Common.getLangCodes().then(res => {
          Cache.setItem(Keys.locales, res)
        })
      }
      if (!Array.isArray(locales) || !locales.length) return Promise.resolve()
      Cache.setItem(Keys.locales, locales)
      // 如果没找到当前语言，设置第一个语言为默认语言
      if (!locales.find(item => item.code === i18n.locale)) {
        i18n.locale = locales[0].code
        lang = locales[0].code
      }
    } catch (e) {
      //
    }
  }
  try {
    // 使用缓存，加快APP启动
    const ls = Cache.getItem(Keys.languages) || {}
    if (!ls[lang]) {
      // 没有语言，等待加载
      const res = await API_Common.getLang(lang)
      ls[lang] = formatSpecialChar(res)
    } else if (loadCodes) {
      // 放在稍后，更新数据,异步处理
      API_Common.getLang(lang).then(res => {
        ls[lang] = formatSpecialChar(res)
        i18n.mergeLocaleMessage(lang, ls[lang])
        Cache.setItem(Keys.languages, ls)
      })
    }
    i18n.mergeLocaleMessage(lang, ls[lang])
    Cache.setItem(Keys.languages, ls)
    Cache.setItem(Keys.lang, lang)
    i18n.locale = lang
  } finally {
    setTabBarTitle(i18n)
  }
}

/**
 * 获取货币相关数据
 * @returns {Promise<void>}
 */
export async function loadCurrencyData() {
  const values = await Promise.all([
    API_Currencies.getCurrencies(),
    API_Currencies.getDefaultCurrency()
  ])
  Cache.setItem(Keys.currencies, values[0])
  store.dispatch('setBaseCurrency', values[1])
  if (!store.state.currentCurrency) {
    store.dispatch('setCurrentCurrency', values[1])
  }
}

// 处理特殊字符
function formatSpecialChar(obj) {
  const charsMap = {
    '&gt;': '>'
  }
  Object.keys(obj).forEach(ok => {
    if (typeof obj[ok] === 'object') {
      obj[ok] = formatSpecialChar(obj[ok])
    } else if (typeof obj[ok] === 'string') {
      Object.keys(charsMap).forEach(ck => {
        obj[ok] = obj[ok].replace(new RegExp(ck, 'g'), charsMap[ck])
      })
    }
  })
  return obj
}

export default i18n
