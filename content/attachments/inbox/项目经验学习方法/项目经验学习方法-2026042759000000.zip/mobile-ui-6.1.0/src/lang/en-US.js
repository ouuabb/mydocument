export default {
  pages: {},
  mescroll: {
    'empty': 'empty...',
    'loading': 'loading...',
    'pull_down_to_refresh': 'Pull down to refresh',
    'give_up_to_refresh': 'Give up to refresh'
  }
}
