export default {
  pages: {},
  mescroll: {
    'empty': '暂无数据...',
    'loading': '加载中...',
    'pull_down_to_refresh': '下拉刷新',
    'give_up_to_refresh': '释放刷新'
  }
}
