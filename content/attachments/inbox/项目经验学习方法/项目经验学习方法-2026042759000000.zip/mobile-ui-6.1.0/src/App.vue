<script>
import Vue from 'vue'
import Cache, { Keys } from '@/utils/cache.js'
import * as API_Common from '@/api/common.js'
import { loadCurrencyData } from '@/lang'
import { i18n as openI18n } from './config/config'

export default {
  // 此处globalData为了演示其作用，不是uView框架的一部分
  globalData: {
    username: '白居易'
  },
  async onLaunch() {
    this.getSiteData()
    if(openI18n){
      loadCurrencyData()
    }
    // #ifdef APP-PLUS
    //app启动时打开启动广告页
    // var w = plus.webview.open(
    // 	'hybrid/html/advertise/advertise.html',
    // 	'本地地址',
    // 	{ top: 0, bottom: 0, zindex: 999 },
    // 	'fade-in',
    // 	500
    // );
    // //设置定时器，4s后关闭启动广告页
    // setTimeout(function() {
    // 	plus.webview.close(w);
    // }, 5000);
    // #endif

    // 如果是H5 通过复制直接打开需要登录的页面
    // #ifdef H5
    const pathname = window.location.pathname
    //如果是以下目录，需要验证是否已经登录
    if (pathname.indexOf('/mine-module') == 0 || pathname.indexOf('/pages/order') == 0) {
      const cacheUser = Cache.getItem(Keys.user)
      //如果没有登录则跳转到登录页面
      if (!cacheUser) {
        uni.redirectTo({
          url: 'pages/auth/login?back_url=' + pathname
        })
      }
    }
    // #endif

    //初始化唯一uuid
    const uuid = Cache.getItem(Keys.uuid)
    if (!uuid) {
      const strUUID = this.$u.guid(20)
      console.log('全局UUID = ' + strUUID)
      Cache.setItem(Keys.uuid, strUUID)
    }
    //获取手机状态栏、导航栏高度 statusBar:状态栏高度 customBar:状态栏高度 + 导航栏高度
    uni.getSystemInfo({
      success(res) {
        Vue.prototype.statusBar = res.statusBarHeight
        // #ifdef MP
        let custom = wx.getMenuButtonBoundingClientRect()
        Vue.prototype.customBar = custom.bottom + custom.top - res.statusBarHeight
        // #endif
      }
    })
  },
  methods: {
    // 站点信息
    getSiteData() {
      API_Common.getSiteData().then(site => {
        Cache.setItem(Keys.site, site)
      })
    },
  }
}
</script>

<style lang="scss">
@import "uview-ui/index.scss";
@import "static/common/css/demo.scss";
@import "static/common/css/floor-mobile.scss";
@import "static/common/css/iconfont.css";
/*每个页面公共css */
[type="search"]::-webkit-search-decoration,
[type="search"]::-webkit-search-cancel-button,
[type="search"]::-webkit-search-results-button,
[type="search"]::-webkit-search-results-decoration {
  display: none !important;
}
page{
    background-color: #f3f4f6;
    height: 100%;
}

// 为你推荐组件样式
.demo-warter {
    border-radius: 8px;
    margin: 5px;
    background-color: #ffffff;
    padding: 8px;
    position: relative;
}

.demo-image {
    width: 100%;
    border-radius: 4px;
}

.demo-title {
    font-size: 30rpx;
    margin-top: 5px;
    color: $u-main-color;
}

::v-deep {
    .u-field {
        padding: 30rpx !important;
        .fild-body {
            margin-top: 6rpx;
        }
    }
    .u-cell {
        align-items: center;
    }
    .u-label {
        // flex: 0 0 160rpx !important;
    }
    .u-field__input-wrap, .u-textarea-class {
        font-weight: 600;
    }
}
/** 按钮 */
.big-btn {
    margin: 80rpx 0 40rpx 0;
    text-align: center;
    .btn {
        background-image: linear-gradient(90deg, #FA3534, #FF722E);
        color: #FFFFFF;
        padding: 20rpx;
        border-radius: 40rpx;
        margin: 0 30rpx;
    }
}
.after-sale-container, .account-security, .change-mobile-container, .invoice-address-container, .change-password-container, .account-binding-contaner, .address-container, .my-performance, .withdrawals-history-container, .instructions-use, .login-container, .register-container, .reset-container, .seckill-container, .points-mall-container {
    background-color: #FFFFFF;
}

.tabs-view{
    z-index: 9900;
    position: fixed;
    top: --window-top;
    left: 0;
    background: white;
    width: 100%;
}

// 自营标识
.self {
    border-radius: 8rpx;
    color: #FFFFFF;
    font-size: 20rpx;
    min-width: 70rpx;
    text-align: center;
    padding: 4rpx 8rpx;
    background: linear-gradient(to right, #FD5632 0%, #EF0D25 100%);
}

// 设置IOS页面标题长按不可复制
::v-deep .uni-page-head__title{
    -webkit-touch-callout:none;  /*系统默认菜单被禁用*/
    -webkit-user-select:none; /*webkit浏览器*/
    -khtml-user-select:none; /*早期浏览器*/
    -moz-user-select:none;/*火狐*/
    -ms-user-select:none; /*IE10*/
    user-select:none;
}
</style>
