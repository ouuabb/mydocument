<template>
    <view class="container">
        <u-steps
            class="u-p-t-20"
            :list="numList"
            mode="number"
            :current="1"
            active-color="#FA3534"></u-steps>
        <view class="item-container">
            <view class="title">基本信息</view>
            <view class="content">
                <u-form
                    :modelValue="basicInfoForm"
                    ref="basicInfoForm"
                    label-width="200" >
                    <u-form-item label="公司名称：" name="company_name" required>
                        <u-input v-model="basicInfoForm.company_name" placeholder="请输入公司名称" :maxlength="200" clearable>
                        </u-input>
                    </u-form-item>
                    <u-form-item label="公司地址：" name="company_address" required>
                        <u-input v-model="basicInfoForm.company_address" placeholder="请输入公司地址" :maxlength="200"
                            clearable></u-input>
                    </u-form-item>
                    <u-form-item label="公司电话：" name="company_phone" required>
                        <u-input v-model="basicInfoForm.company_phone" placeholder="请输入公司电话" :maxlength="30" clearable>
                        </u-input>
                    </u-form-item>
                    <u-form-item label="公司邮箱：" name="company_email" required>
                        <u-input v-model="basicInfoForm.company_email" placeholder="请输入公司邮箱" clearable></u-input>
                    </u-form-item>
                    <u-form-item label="员工总数(人)：" name="employee_num" required>
                        <u-input v-model="basicInfoForm.employee_num" placeholder="请输入员工总数" clearable></u-input>
                    </u-form-item>
                    <u-form-item label="注册资金(万)：" name="reg_money" required>
                        <u-input v-model="basicInfoForm.reg_money" placeholder="请输入注册资金" clearable></u-input>
                    </u-form-item>
                    <u-form-item label="联系人姓名：" name="link_name" required>
                        <u-input v-model="basicInfoForm.link_name" placeholder="请输入联系人姓名" :maxlength="20" clearable>
                        </u-input>
                    </u-form-item>
                    <u-form-item label="联系人电话：" name="link_phone" required>
                        <area-select
                            ref="areaSelect"
                            :areaCode="basicInfoForm.areaCode" />
                        <u-input v-model="basicInfoForm.link_phone" placeholder="请输入联系人电话" :maxlength="30" clearable>
                        </u-input>
                    </u-form-item>
                </u-form>
            </view>
        </view>
        <view class="next-btns u-text-center u-p-b-20">
            <u-button class="u-m-r-40" size="mini" @click="handleBackStep">上一步</u-button>
            <u-button size="mini" @click="handleNextStep">下一步</u-button>
        </view>
    </view>
</template>

<script>
    import * as API_Shop from '@/api/shop'
    import {
        Foundation,
        RegExp as UtilRegExp
    } from '@/app-utils'
	import areaSelect from '@/components/areaSelect/areaSelect'

    export default {
        components: {
			areaSelect
		},
        data() {
            const req_rule = (message, trigger) => ({
                required: true,
                message,
                trigger: [trigger || 'blur']
            });
            const len_rule = (min, max) => ({
                min,
                max,
                message: `'长度在 ${min} 到 ${max} 个字符`
            });
            return {
                numList: [{
                    name: '入驻协议'
                }, {
                    name: '基本信息'
                }, {
                    name: '认证信息'
                }, {
                    name: '资质信息'
                }, {
                    name: '店铺信息'
                }],
                basicInfoForm: {
                    company_name: '',
                    company_address: '',
                    company_phone: '',
                    company_email: '',
                    employee_num: '',
                    reg_money: '',
                    link_name: '',
                    link_phone: ''
                }
            };
        },
        onLoad() {
            API_Shop.getApplyShopInfo().then(response => {
                Object.keys(this.basicInfoForm).forEach(key => {
                    if (key === 'link_phone') {
                        const { areaCode, mobileValue } = Foundation.formatIn18Mobile(response[key])
                        this.basicInfoForm.link_phone = mobileValue
                        if (areaCode) {
                            this.basicInfoForm.areaCode = areaCode
                        }
                    } else {
                        this.basicInfoForm[key] = response[key]
                    }
                })
            })
        },
        methods: {
            // 上一步
            handleBackStep() {
                uni.navigateBack()
            },
            // 下一步
            handleNextStep() {
                const params = JSON.parse(JSON.stringify(this.basicInfoForm))
                if (Object.keys(params).some(v => !params[v])) {
                    this.$u.toast('表单项未填写完整，请检查！')
                    return
                }
                if (!params.company_phone) {
                   // || !UtilRegExp.integer.test(params.company_phone)
                    this.$u.toast('请输入正确的电话号码')
                    return
                }
                if (!UtilRegExp.email.test(params.company_email)) {
                    this.$u.toast('请输入正确的公司邮箱')
                    return
                }
                if (!UtilRegExp.email.test(params.company_email)) {
                    this.$u.toast('请输入正确的公司邮箱')
                    return
                }
                if (!UtilRegExp.integer.test(params.employee_num)) {
                    this.$u.toast('员工人数应为正整数，且不为零')
                    return
                }
                if (!UtilRegExp.integer.test(params.reg_money)) {
                    this.$u.toast('注册资金应为正整数，且不为零')
                    return
                }
                const { mobile_regex, formatValid, mobileValue } = this.$refs.areaSelect
                const mobileReg = new RegExp(mobile_regex)
                if (!mobileReg.test(formatValid(params.link_phone))) {
                    this.$u.toast('联系人电话格式不正确')
                    return
                }
                params.link_phone = mobileValue(params.link_phone)

                API_Shop.applyShopStep(1, params).then(response => {
                    this.$u.route('/pages/shop/apply/auth-info')
                })
            }
        }
    }
</script>

<style lang="scss">
    .container {
        min-height: 100%;
        background-color: #FFFFFF;
        ::v-deep .u-steps__item__text--row {
            word-wrap: break-word;
            width: 70px;
            height: 60px;
        }

        .item-container {
            border-top: 1px dashed #E1E1E1;
            margin: 20rpx 0;

            .title {
                margin: 20rpx 0;
                font-size: 40rpx;
                font-weight: 600;
                text-align: center;
            }

            .content {
                padding: 0 30rpx;
            }

            .licence-range {
                margin-left: 260rpx;
            }
        }
    }
</style>
