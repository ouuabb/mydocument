<template>
  <view>
    <u-popup width="80%" v-model="showCouponPop" mode="center" border-radius="20" @close="handleClose">
      <view class="popup-wrap">
        <view class="bg-one"></view>
        <view scroll-y class="bg-two">
          <u-icon @click="handleClose" name="close-circle" class="close-icon" />
          <view class="title">—— 新人好礼 ——</view>
          <scroll-view scroll-y class="coupon-box">
            <view class="coupon-item" v-for="(item, index) of couponList" :key="item.coupon_id">
              <view class="left">
                <!-- <text class="unit">{{ MixinUnitOfCurrency }}</text> -->
                <!-- {{ item.coupon_price }} -->
				<custom-price :price="item.coupon_price" :size="40" fontWeight="600" textColor="#fff"></custom-price>
              </view>
              <view class="right"> {{ item.title }}</view>
            </view>
          </scroll-view>
        </view>
        <view class="bg-three">
          <image class="bg-icon" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/coupon-bg.png" alt="" />
          <view class="btn-box">
            <view>注册即可领取优惠券</view>
            <view class="btn" @click="toRegister">立即注册</view>
          </view>
        </view>
      </view>
    </u-popup>
    <movable-area v-if="showFixedPop" class="movable-box"
      :style="{ top: barHeight + 'px', height: 'calc(100vh - ' + calcHeight + 'px)' }" ref="movableBox">
      <movable-view class="movable-view" direction="all" out-of-bounds="false" :x="1000" :y="1000">
        <view v-if="openI18n" class="fixed-red-box" @click="handleShowPop"></view>
        <view v-else class="fixed-box" @click="handleShowPop">
          <text class="text">新人红包</text>
          <text class="text">点击查看</text>
        </view>
      </movable-view>
    </movable-area>
  </view>
</template>

<script>

import * as API_Promotions from '@/api/promotions.js'
import { i18n as openI18n } from '@/config/config'

export default {
  name: 'NewComerCoupon',
  options: {
    styleIsolation: 'shared', // 解除样式隔离
  },
  data() {
    return {
      openI18n,
      // #ifdef MP
      barHeight: this.customBar + 60, //状态栏+导航栏高度
      calcHeight: this.customBar + 60,
      // #endif
      // #ifdef APP-PLUS || H5
      barHeight: 100, //状态栏高度
      calcHeight: 200,
      // #endif
      // 优惠券弹窗显隐
      showCouponPop: false,
      // 右下角浮窗显隐
      showFixedPop: false,
      couponList: [],
      onTouch: false
    }
  },
  created() {
    this.getNewcomerCoupon()
  },
  methods: {
    /** 获取新人优惠券 */
    getNewcomerCoupon() {
      API_Promotions.getNewcomerCoupon().then(res => {
        if (res.newcomer_is_open) {
          this.couponList = res.newcomer_coupon_list
          this.showCouponPop = true
        }
      })
    },
    /** 关闭弹窗 */
    handleClose() {
      this.showFixedPop = true
      this.showCouponPop = false
    },
    /** 显示红包弹窗 */
    handleShowPop() {
      this.showCouponPop = true
      this.showFixedPop = false
    },
    /** 去注册 */
    toRegister() {
      uni.navigateTo({
        url: `/pages/auth/register?back_url=${encodeURIComponent('/pages/tabs/home/home')}`
      })
    }
  }
}
</script>

<style lang="scss" scoped>
::v-deep {
  .u-mode-center-box {
    background-color: rgba(0, 0, 0, 0) !important;
    height: 60% !important;
    display: flex;
    align-items: center;
  }
}

.movable-box {
  pointer-events: none;
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  width: 100%;
}

.movable-view {
  pointer-events: auto;
  z-index: 999;
  width: 130rpx;
  height: 130rpx;
}

.fixed-red-box {
  width: 130rpx;
  height: 130rpx;
  background-image: url('https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/hongbao3.png');
  background-size: 100% 100%;
}

.fixed-box {
  width: 130rpx;
  height: 130rpx;
  background-image: url('https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/hongbao2.png');
  background-size: 100% 100%;
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding-bottom: 10rpx;
  font-size: 20rpx;
  color: #fff;
}

.popup-wrap {
  width: 100%;
  height: 98%;
  position: relative;

  .bg-one {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    width: 100%;
    height: 50%;
    border-radius: 15rpx;
    background: #f90007;
  }

  .bg-two {
    height: 90%;
    position: absolute;
    bottom: 80rpx;
    width: calc(100% - 40rpx);
    left: 20rpx;
    right: 20rpx;
    border-radius: 15rpx;
    background: #fdf7d2;
    padding: 30rpx 30rpx;
    box-sizing: border-box;

    .close-icon {
      font-size: 44rpx;
      color: #ff5000;
      position: absolute;
      right: 20rpx;
      top: 20rpx;
    }

    .title {
      color: #ff5000;
      font-size: 40rpx;
      font-weight: 500;
      text-align: center;
      margin-bottom: 30rpx;
    }

    .coupon-box {
      height: calc(100% - 220rpx);
    }

    .coupon-item {
      background: #fff;
      border-radius: 10rpx;
      text-align: center;
      color: #ff5000;
      width: 100%;
      height: 150rpx;
      line-height: 80rpx;
      margin: 20rpx 0;
      font-size: 30rpx;
      display: flex;

      .left {
        border-radius: 6rpx 0 0 6rpx;
        width: 30%;
        background: #f23b24;
        color: #fff;
        font-weight: 600;
        font-size: 50rpx;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        background: radial-gradient(circle at right top, transparent 10rpx, #f23b24 0) right top / 100% 50% no-repeat,
          radial-gradient(circle at right bottom, transparent 10rpx, #f23b24 0) right bottom / 100% 50% no-repeat;

        &::after {
          content: ' ';
          height: 100%;
          position: absolute;
          border-left: 6px dotted white;
          top: 0;
          right: -3px;
        }

        .unit {
          font-size: 26rpx;
          font-weight: 400;
          margin-top: 20rpx;
        }
      }

      .right {
        width: 70%;
        padding-left: 20rpx;
        display: flex;
        align-items: center;
        justify-content: center;
      }

    }
  }

  .bg-three {
    position: absolute;
    bottom: 0rpx;
    left: 0rpx;
    right: 0rpx;
    width: 100%;
    height: 280rpx;

    .bg-icon {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      width: 100%;
      height: 100%;
      transform: scale(1.2);
    }

    .btn-box {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;

      .btn {
        width: 50%;
        height: 70rpx;
        line-height: 70rpx;
        background: #fff;
        border-radius: 30rpx;
        font-size: 30rpx;
        color: #ff5000;
        text-align: center;
        z-index: 3;
        margin: 20rpx 0 30rpx;
      }
    }

  }

}
</style>
