<template>
  <view class="shopping-cart-wrap">
    <u-navbar
      title="购物车"
      title-color="#333333"
      :is-fixed="true"
      :is-back="false"
      :background="{background: '#fff'}"
      :border-bottom="false"
      :title-bold="true"
    >
    </u-navbar>

    <view class="cart-content">
      <mescroll-body
        ref="mescrollRef"
        @init="mescrollInit"
        @down="downCallback"
        @up="upCallback"
        :down="down"
        :up="upOptions">
      <!-- <u-empty
        v-if="!cartList.length"
        text="购物车是空的,赶快去购买吧"
        mode="data"></u-empty> -->
        <emptyView v-if="!cartList.length" imageName="not-goods-car.png" tipsText="购物车是空的,赶快去购买吧" />

      <view class="go-login-btn" v-if="!user">
        <u-button style="background-color: #ff5000; margin-top: 80%;" type="error" size="medium" @click="handleLogin">登录/注册</u-button>
      </view>

      <view
        class="seller-view"
        v-for="(cart, index) in cartList"
        :key="index">
        <u-sticky zIndex="3">
          <view class="seller-item u-flex u-col-center">
            <view class="seller-name-box">
              <view class="seller-checkbox-view" @click="handleCheckSeller(cart)" >
                <u-icon
                  v-if="!cart.invalid"
                  :color="cart.checked === 1 ? '#FA3534' : ''"
                  size="38"
                  :name="cart.checked === 1? 'xuanze' : 'choose'"
                  custom-prefix="custom-icon">
                </u-icon>
                <u-icon
                  v-else
                  size="38"
                  color="#FA3534"
                  name="xuanze"
                  custom-prefix="custom-icon"></u-icon>
              </view>
              <view class="seller-name-view u-flex">
                <u-icon name="shop" custom-prefix="custom-icon" size="35"></u-icon>
                <view class="u-margin-left-10">{{cart.seller_name}}</view>
              </view>
            </view>

            <view class="coupon-tag" v-if="cart.couponList && cart.couponList.length">
              <image class="tag-bg" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/coupon-tag.png"/>
              <div class="content" @click="viewShopCoupon(cart)">
                优惠券
                <u-icon
                  name="arrow-down"
                  color="#fff"
                  style="margin-left: 10px;"  />
              </div>
            </view>
          </view>
        </u-sticky>

        <!-- 促销活动商品 -->
        <view class="seller-view group-view"
          v-for="(group, sellerIndex) in cart.group_list"
          :key="sellerIndex">
          <view class="promotion-view" v-if="group.promotion_type_name">
            <u-tag
              class="u-m-r-20 group-tag"
              :text="group.promotion_type_name"
              size="small"
              type="error"
              mode="plain"/>
            <text>{{ promotionTips(group) }}</text>
          </view>
          <sku-item
            :skuList="group.sku_list"
            @refreshList="getCartList" />

          <view
            class="gift-box">
            <text v-if="group.free_freight" class="gift-item">【赠】免运费</text>
            <view
              v-for="(giftItem) in group.gift_list"
              :key="giftItem.type">
              <text v-if="giftItem.type === 'gift'" class="gift-item">【赠】{{giftItem.value.gift_name}}  x 1</text>
              <text v-if="giftItem.type === 'coupon'" class="u-flex gift-item" style="display: flex; align-items: center; white-space: nowrap;">
                【赠】满{{giftItem.value.threshold}}减
                <custom-price :price="giftItem.value.amount" textColor="#333" :size="26" style="display: inline-block;"></custom-price>
                优惠券
              </text>
              <text v-if="giftItem.type === 'point'" class="gift-item">【赠】{{giftItem.value}}积分</text>
            </view>
          </view>
        </view>
        <!-- 无促销商品 -->
        <sku-item
          :skuList="cart.sku_list"
          @refreshList="getCartList" />
      </view>
      </mescroll-body>
    </view>

    <SettlementBar
      v-if="cartList.length"
      :cartList="cartList"
      :totalPrice="totalPrice"
      :checkedCount="checkedCount"
      :allCount="allCount"
      @refreshList="getCartList" />

    <u-popup
      v-model="couponsShow"
      mode="bottom"
       length="auto"
       border-radius="20"
       :safe-area-inset-bottom="true"
       closeable
       close-icon-size="20"
       @close="closePopup">
      <view style="padding: 70rpx 0;">
        <coupon-item
          v-for="(coupon, couponIndex) in couponsList"
          :key="couponIndex"
          :coupon="coupon"
          @handleReceiveCoupon="handleReceiveCoupon" />
      </view>
    </u-popup>
  </view>
</template>

<script>
  import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js"
  import Cache from '@/utils/cache.js'
  import * as API_Trade from '@/api/trade.js'
  import * as API_Promotions from '@/api/promotions.js'
  import * as API_Members from '@/api/members.js'
  import SkuItem from './components/SkuItem'
  import SettlementBar from './components/SettlementBar'
  import CouponItem from '@/components/couponItem/couponItem'
  import emptyView from '@/components/empty-view/empty-view'

  export default {
    mixins: [MescrollMixin],
    components: {
      SkuItem,
      SettlementBar,
      CouponItem,
      emptyView
    },
    data() {
      return {
        // #ifdef MP
        background: {
            background: '#FA3534'
        },
        // #endif
        // #ifndef MP
        background: {
            background: 'url(https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/bg/bg2.png) no-repeat',
            backgroundSize: 'cover'
        },
        // #endif

        // MeScroll config
        down: {
            auto: false
        },
        upOptions: {
            auto: false
        },
        // 网络状态
        networkType: '',
        // 用户数据
        user: Cache.getItem('user'),
        // 购物车数据
        cartList: [],
        // 购物车金额数据
        totalPrice: {},
        // 选中的商品数量
        checkedCount: 0,
        // 所有商品数量
        allCount: 0,
        // 优惠券领取popup
        couponsShow: false,
        // 优惠券列表
        couponsList: []
      }
    },
    computed: {
      promotionTips() {
        return (group) => {
          const promotion = group.promotion_tips
          let tips = ''
          const unit = promotion.discount_type === 2 ? '件' : ''
          if (group.promotion_type_name === '满减') {
            // current_threshold_value：当前已满足档位 current_discount_amount：当前已减金额
            if (promotion.current_threshold_value && promotion.current_discount_amount) {
              tips += `已购满${promotion.current_threshold_value}${unit}`
              if (promotion.current_type === 1) {
                // 满额减
                tips += `，已减${promotion.current_discount_amount}`
              } else {
                // 满折
                tips += `，享${promotion.current_discount_amount}折优惠`
              }
            }
            if (promotion.next_threshold_value && promotion.next_discount_amount) {
              // next_threshold_value: 距离下一档位金额 next_discount_amount： 下一档位减金额
              tips += `${tips ? '，' : ''}在凑${promotion.next_threshold_value}${unit}`
              if (promotion.next_type === 1) {
                // 满额减
                tips += `可减${promotion.next_discount_amount}`
              } else {
                // 满折
                tips += `可享${promotion.next_discount_amount}折优惠`
              }
            }
          } else if (group.promotion_type_name === '满赠') {
            if (promotion.current_threshold_value) {
              tips = `已满${promotion.current_threshold_value}${unit}享受满赠优惠`
            }
            if (promotion.next_threshold_value) {
              tips += `在凑${promotion.next_threshold_value}${unit}${tips ? '可享受更大优惠' : '可享受满赠优惠'}`
            }
          }
          return tips
        }
      }
    },
    onLoad() {
      //获取网络类型
      uni.getNetworkType({
        success: (res) => {
          this.networkType = res.networkType
          if (res.networkType !== 'none') {
            this.user = Cache.getItem('user')
            if (!this.user) {
                this.cartList = []
            }
          }
        }
      })
      //监听退出登录消息
      uni.$on('logout', (data) => {
        this.user = null;
        this.cartList = []
      })
    },
    onShow() {
      this.user = Cache.getItem('user')
      //监听网络状态变化
      uni.onNetworkStatusChange(res => {
        //监听到有网络并且第一次没有加载数据的情况下初始化数据
        if (res.isConnected && this.networkType === 'none') {
          if (!this.user) {
              this.cartList = []
          }
        }
      })
      this.downCallback()
    },
    methods: {
      /** 关闭优惠券弹窗 */
      closePopup() {
        this.couponsShow = false
        this.couponsList = []
      },
      /** 查看优惠券数据 */
      viewShopCoupon(cart) {
        this.couponsShow = true
        this.couponsList = cart.couponList
      },
      /** 获取店铺优惠券 */
      handleShopCoupon(seller_id) {
        return new Promise((resolve, reject) => {
          API_Promotions.getShopAllCoupons({ seller_id }).then(res => {
              resolve(res)
            }).catch(() => {
              reject()
            })
        })

      },
      /** 领取优惠券 */
      handleReceiveCoupon(coupon) {
        API_Members.receiveCoupons(coupon.coupon_id).then(response => {
          uni.showToast({
            title: '领取成功'
          })
        })
      },
      /** 下拉刷新 */
      downCallback() {
        console.log("下拉刷新")
        if (this.user) {
            this.getCartList()
        } else {
            this.mescroll.endErr()
        }
      },

      /** 上拉加载 */
      upCallback(page) {
        this.mescroll.endErr()
      },

      /** 登录判断 */
      handleLogin() {
        console.log("=====handleLogin=====")
        this.judgeLogin(() => {},'force')
      },

      /** 店铺商品选中切换 */
      handleCheckSeller(cart){
        console.log("=====handleCheckSeller=====")
        uni.showLoading({title: '加载中',mask:true});
        const checked = cart.checked ? 0 : 1
        API_Trade.updateSellerChecked(cart.seller_id, checked).then(res => {
            setTimeout(function () {uni.hideLoading();}, 200)
            this.getCartList()
        })
      },

      /** 获取购物车数据 */
      getCartList() {
        console.log("=====获取购物车数据=====")
        if (!this.user) {
          return;
        }
        API_Trade.getCarts('all').then(async res => {
          const { cart_list, total_price } = res
          let _allCount = 0
          let _checkedCount = 0
          let _skuList = []
          // 商品sku扁平化集合
          for (let cart of cart_list) {
            _skuList.push(...cart.sku_list)
            await this.handleShopCoupon(cart.seller_id).then(coupons => {
              cart.couponList = coupons
            })
            cart.group_list.forEach(group => {
              _skuList.push(...group.sku_list)
            })
          }
          _skuList.forEach(sku => {
            sku.show = false
            if (sku.invalid !== 1) _allCount += sku.num
            if (sku.checked && sku.invalid !== 1) _checkedCount += sku.num
          })
          this.cartList = cart_list
          this.skuList = _skuList
          this.totalPrice = total_price
          this.allCount = _allCount
          this.checkedCount = _checkedCount
          setTimeout(() => {
            this.mescroll.endSuccess(cart_list.length)
          },300)
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .cart-content {
    padding-bottom: 120rpx;
    ::v-deep {
    .u-btn--error {
      background-color: #ff5000 !important;
    }
    .u-empty {
      padding-top: 200rpx !important;
    }
    .u-tag {
      font-size: 22rpx !important;
      padding: 8rpx 20rpx !important;
      font-size: 12rpx;
      color: #fff;
      background: #f42424;
      border: none;
    }
    .u-icon-minus,.u-icon-plus {
      background-color: #fff !important;
    }
    }
    .go-login-btn {
      display: flex;
      justify-content: center;
      margin-top: 30rpx;
    }
    .group-view {
      border-bottom: 2rpx dashed #e9e9e9;
      padding-bottom: 20rpx;
    }
    .seller-view {
      background-color: #FFFFFF;
      border-radius: 20rpx 20rpx 0 0;
      overflow: hidden;
      margin-top: 20rpx;
    .gift-box {
      margin-left: 80rpx;
      font-size: #333;
      font-size: 26rpx;
    }
    .promotion-view {
      margin-left: 80rpx;
      font-size: 22rpx;
    }
      .seller-item {
        width: 100%;
        padding: 20rpx;
        background: #fff;
        display: flex;
        justify-content: space-between;
        .seller-name-box {
          display: flex;
        }
        .coupon-tag {
          position: relative;
          .tag-bg {
            width: 140rpx;
            height: 50rpx;
          }
          .content {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            color: #fff;
            font-size: 20rpx;
            line-height: 50rpx;
            text-align: center;
          }
        }
        .seller-checkbox-view {
          // width: 120rpx;
          display: flex;
          justify-content: center;
        }
        .seller-name-view {
          padding-left: 25rpx;
          font-size: 30rpx;
          font-weight: 600;
        }
      }
    }
  }
</style>