<template>
  <view class="container">
    <u-steps class="u-p-t-20" :list="numList" mode="number" :current="3" active-color="#FA3534"></u-steps>
    <view class="item-container">
      <view class="title">开户行银行许可证</view>
      <view class="content">
        <u-form :model="finlQuafForm" ref="finlQuafForm" label-width="320" :error-type="errorType">
          <u-form-item label="银行开户名：" prop="bank_account_name" required>
            <u-input
              v-model="finlQuafForm.bank_account_name"
              placeholder="请输入银行开户名"
              :maxlength="200"
              clearable
            />
          </u-form-item>
          <u-form-item label="公司银行账号：" prop="bank_number" required>
            <u-input v-model="finlQuafForm.bank_number" placeholder="请输入公司银行账号" :maxlength="50" clearable>
            </u-input>
          </u-form-item>
          <u-form-item label="开户银行支行名称：" prop="bank_name" required>
            <u-input v-model="finlQuafForm.bank_name" placeholder="请输入开户银行之行名称" :maxlength="100" clearable>
            </u-input>
          </u-form-item>
          <addressFiled
            :defaultForm="finlQuafForm"
            label="开户银行所在地"
            prefix="bank_"
            @handlerRegionJson="handlerRegionJson"
          />
          <u-form-item label="开户银行许可证电子版：" prop="bank_img" required>
            <u-upload
              :action="action"
              :header="header"
              :max-count="1"
              :file-list="bankImgFile"
              @on-remove="bankImgRemove"
              @on-success="bankImgSuccess"
            />
          </u-form-item>
        </u-form>
      </view>
    </view>
    <view class="next-btns u-text-center u-p-b-20">
      <u-button class="u-m-r-40" size="mini" @click="handleBackStep">上一步</u-button>
      <u-button size="mini" @click="handleNextStep">下一步</u-button>
    </view>
  </view>
</template>

<script>
import * as API_Shop from '@/api/shop'
import addressFiled from '@/components/addressFiled/addressFiled'
import { api, i18n as openI18n } from '@/config/config'
import Cache, { Keys } from '@/utils/cache'

export default {
  components: {
    addressFiled
  },
  data() {
    const req_rule = (message, trigger) => ({
      required: true,
      message,
      trigger: [trigger || 'blur']
    })
    const len_rule = (min, max) => ({
      min,
      max,
      message: `'长度在 ${min} 到 ${max} 个字符`
    })
    return {
      openI18n,
      numList: [
        { name: '入驻协议' },
        { name: '基本信息' },
        { name: '认证信息' },
        { name: '资质信息' },
        { name: '店铺信息' }
      ],
      finlQuafForm: {
        bank_account_name: '',
        bank_number: '',
        bank_name: '',
        bank_region: '',
        bank_address: '',
        bank_img: '',
        city: '',
        country_code: '',
        country_name: '',
        province: ''
      },
      rules: {
        bank_account_name: [req_rule('请输入银行开户名！')],
        bank_number: [req_rule('请输入公司银行账号！')],
        bank_name: [req_rule('请输入开户银行之行名称！')],
        bank_region: [{
          validator: (rule, value, callback) => {
            if (!value) {
              callback(new Error('请选择开户银行所在地！'))
            } else {
              callback()
            }
          },
          trigger: 'blur'
        }],
        bank_img: [req_rule('请上传开户银行许可证电子版！', 'change')]
      },
      errorType: ['toast'],
      action: `${api.buyer}/buyer/uploaders`,
      header: this.MixinUploadHeader(),
      bankImgFile: [],
      regionJSon: ''
    }
  },
  onLoad() {
    API_Shop.getApplyShopInfo().then(response => {
      this.bankImgFile = response.bank_img ? [{ url: response.bank_img }] : []
      this.finlQuafForm = response
    })
  },
  onReady() {
    this.$refs.finlQuafForm.setRules(this.rules)
  },
  methods: {
    // 开户银行许可证电子版
    bankImgSuccess(res) {
      this.finlQuafForm.bank_img = res.url
    },
    bankImgRemove() {
      this.finlQuafForm.bank_img = ''
    },
    // 上一步
    handleBackStep() {
      uni.navigateBack()
    },
    // 下一步
    handleNextStep() {
      const params = JSON.parse(JSON.stringify(this.finlQuafForm))
      this.$refs.finlQuafForm.validate(valid => {
        if (valid) {
          const { internal_region_id } = this.regionJSon || {}
          if (!internal_region_id || Number(internal_region_id) === 0) {
            return this.$u.toast('请选择开户银行所在地！')
          }
          params.bank_region = this.regionJSon
          API_Shop.applyShopStep(3, params).then(response => {
            this.$u.route('/pages/shop/apply/shop-info')
          })
        }
      })
    },
    handlerRegionJson(obj) {
      this.regionJSon = obj
    }
  }
}
</script>

<style lang="scss">
::v-deep {
  .u-field {
    padding: 20rpx 0 !important;
  }
}
.container {
  min-height: 100%;
  background-color: #FFFFFF;
  .item-container {
    border-top: 1px dashed #E1E1E1;
    margin: 20rpx 0;
    .title {
      margin: 20rpx 0;
      font-size: 40rpx;
      font-weight: 600;
      text-align: center;
    }
    .content {
      padding: 0 30rpx;
    }
    .licence-range {
      margin-left: 260rpx;
    }
  }
}
</style>
