<template>
  <view class="u-wrap">
    <u-navbar
      title-color="#303133"
      :is-fixed="true"
      :is-back="false"
      :background="background"
      :back-text-style="{color: '#303133'}"
      :border-bottom="false"
    >
      <view class="slot-wrap">
        <view class="search-wrap" @click="onSearch">
		      <u-icon class="u-search-icon" name="search" size="26" color="#666"></u-icon>
          请输入关键字
        </view>
      </view>
      <!-- 国际化语言切换 -->
      <view v-if="openI18n" class="navbar-right" slot="right" @click="handleShowLangCurrencyPick">
        <view class="right-item">
          <image src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-language-white.png" class="icon-lang"/>
        </view>
      </view>
      <!-- #ifndef MP -->
      <view v-else class="navbar-right" slot="right" @click="onMine">
        <view class="right-item">
          <u-icon name="dibutubiao_wode" custom-prefix="custom-icon"></u-icon>
        </view>
      </view>
      <!-- #endif -->
    </u-navbar>
    <view class="top-warp">
      <u-tabs :list="categories" :name="'cat_name'" :current="tabIndex" :bg-color="background.background" active-color="#FFFFFF" inactive-color="#FFFFFF" @change="tabChangeHome"></u-tabs>
    </view>
    <view v-if="!tabIndex" class="floor-view">
      <view class="background-view"></view>
      <decor-modules v-if="floorData" :page-data="floorData" class="decor-view"/>
    </view>
    <mescroll-item ref="mescrollItem" v-for="(tab, i) in categories" :key="i" :i="i" :index="tabIndex" :tabs="categories" :statusBarHeight="statusBarHeight"></mescroll-item>
    <u-no-network></u-no-network>

    <!-- 新用户优惠券注册提示 -->
    <new-comer-coupon v-if="!user" />
    <!-- 新用户优惠券领取提示 -->
    <coupon-receive v-else-if="showReceivePopup" />
    <!-- 多语言切换 -->
    <u-select
      v-model="showLangSelect"
      :list="locales"
      label-name="lang"
      value-name="code"
      :mask-close-able="false"
      safe-area-inset-bottom
      @cancel="handleCancelLangPick"
      @confirm="handleLangPick"
    />
    <!-- 多货币切换 -->
    <u-select
      v-model="showCurrencySelect"
      :list="currencies"
      label-name="label"
      value-name="id"
      :default-selector="defaultCurrencyIndex"
      :mask-close-able="false"
      safe-area-inset-bottom
      @cancel="handleCancelCurrencyPick"
      @confirm="handleCurrencyPick"
    />
  </view>
</template>

<script>
import * as API_Goods from '@/api/goods'
import * as API_Common from '@/api/common'
import * as API_Pages from '@/api/pages'
import Cache, { Keys } from '@/utils/cache'
import { i18n as openI18n } from '@/config/config'
import i18n, { loadLangAsync } from '@/lang'
import MescrollItem from './mescroll-item.vue'
import MescrollMoreMixin from '@/components/mescroll-uni/mixins/mescroll-more'
import DecorModules from '@/components/decor-modules/decor-modules'
import NewComerCoupon from './components/NewComerCoupon'
import CouponReceive from './components/CouponReceive'

export default {
  components: {
    MescrollItem,
    DecorModules,
    NewComerCoupon,
    CouponReceive
  },
  mixins: [MescrollMoreMixin],
  data() {
    return {
      keyword: '',
      //如果是小程序则隐藏
      // #ifdef MP
      background: {
        background: '#ff5000'
      },
      // #endif
      //如果是不是小程序则展示
      // #ifndef MP
      background: {
        // background: 'url(https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/bg/bg2.png) no-repeat',
        background: '#ff5000',
        backgroundSize: 'cover'
      },
      // #endif
      tabIndex: 0,
      categoryList: [],//分类数据
      floorData: '', //楼层数据
      networkType: '',//网络状态
      statusBarHeight: 0,
      openI18n,
      user: Cache.getItem(Keys.user),
      showReceivePopup: false, // 优惠券领取弹窗显隐
      locales: [],
      showLangSelect: false,
      currencies: [],
      showCurrencySelect: false,
      defaultCurrencyIndex: undefined
    }
  },
  async onLoad(params) {
    let $this = this
    //获取网络类型
    uni.getNetworkType({
      success(res) {
        $this.networkType = res.networkType
        if (res.networkType !== 'none') {
          $this.init()
        }
      }
    })
  },
  mounted() {
    const that = this
    uni.getSystemInfo({
      success(res) {
        const query = uni.createSelectorQuery().in(that)
        query.select('.top-warp').boundingClientRect(data => {
          //状态栏高度+tab距离顶部的高度+tab的高度
          that.statusBarHeight = res.statusBarHeight + data.top + data.height
        }).exec()
      }
    })
  },
  computed: {
    categories() {
      return [
        ...this.categoryList
      ]
    }
  },
  onShow() {
    const newlyRegisteredUser = Cache.getItem(Keys.newlyRegisteredUser)
    if (newlyRegisteredUser) {
      // 由注册跳转返回 检查是否有新人优惠券
      this.showReceivePopup = true
      Cache.setItem(Keys.newlyRegisteredUser, false)
    }
    this.user = Cache.getItem(Keys.user)
    let $this = this
    //监听网络状态变化
    uni.onNetworkStatusChange(res => {
      //监听到有网络并且第一次没有加载数据的情况下初始化数据
      if (res.isConnected && $this.networkType === 'none') {
        $this.init()
      }
    })
  },
  methods: {
    async init() {
      // 获取楼层数据
      API_Pages.getIndexPage().then(res => {
        this.floorData = res
        res.page_name && uni.setNavigationBarTitle({ title: res.page_name })
      })
      // 获取分类数据
      API_Goods.getCategory().then(res => {
        res.unshift({ name: '首页', category_id: '' })
        this.categoryList = res
        //小程序发布需过滤医药及食品类目
        // this.categoryList = res.filter(key=> key.category_id != 85 && key.category_id != 4)
      })
      // 获取站点数据
      API_Common.getSiteData().then(res => {
        Cache.setItem(Keys.site, res)
      })
    },
    //搜索
    onSearch() {
      uni.navigateTo({ url: '/pages/search/search' })
    },
    //我的
    onMine() {
      uni.switchTab({ url: '/pages/tabs/mine/mine' })
    },
    //导航栏点击
    tabChangeHome(index) {
      this.tabIndex = index
    },
    //  多语言切换
    handleLangPick(val) {
      this.handleCancelLangPick()
      const code = val[0].value
      if (i18n.locale === code) return
      Cache.setItem(Keys.lang, code)
      // #ifdef APP-PLUS
      plus.runtime.restart()
      // #endif

      // #ifdef H5
      window.location.reload()
      // #endif

      // #ifdef MP
      loadLangAsync(false, code).then(() => this.init())
      // #endif
    },
    // 货币切换
    handleCurrencyPick(val) {
      this.handleCancelCurrencyPick()
      const id = val[0].value
      const currency = this.currencies.find(item => item.id === id)
      this.$store.dispatch('setCurrentCurrency', currency)
    },
    handleShowLangCurrencyPick() {
      uni.showActionSheet({
        title: '切换语言/货币',
        itemList: ['切换语言', '切换货币'],
        success: ({ tapIndex }) => {
          tapIndex === 0
            ? this.handleShowLangSelect()
            : this.handleShowCurrencySelect()
        }
      })
    },
    handleCancelLangPick() {
      this.showLangSelect = false
      setTimeout(() => uni.showTabBar(), 300)
    },
    handleCancelCurrencyPick() {
      this.showCurrencySelect = false
      setTimeout(() => uni.showTabBar(), 300)
    },
    handleShowLangSelect() {
      this.locales = Cache.getItem(Keys.locales) || []
      this.showLangSelect = true
      uni.hideTabBar({ animation: true })
    },
    handleShowCurrencySelect() {
      const currencies = Cache.getItem(Keys.currencies) || []
      this.currencies = currencies.map(item => ({
        ...item,
        label: `${item.currency_code}-${item.symbol}-${item.currency_name}`
      }))
      const { currentCurrency } = this.$store.state
      if (currentCurrency) {
        const index = currencies.findIndex(item => item.id === currentCurrency.id)
        if (index !== -1) {
          this.defaultCurrencyIndex = [index]
        }
      }
      this.showCurrencySelect = true
      uni.hideTabBar({ animation: true })
    }
  }
}
</script>

<style lang="scss" scoped>
.movable-box {
  height: calc(100vh - 100rpx);
  width: 100%;
  .movable-view {
    z-index: 99;
    width: 130rpx;
    height: 130rpx;
  }
  .fixed-box {
    width: 130rpx;
    height: 130rpx;
    background-image: url('https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/hongbao2.png');
    background-size: 100% 100%;
    color: #fff;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding-bottom: 10rpx;
    font-size: 12rpx;
  }
}
.top-warp {
  z-index: 990;
  position: fixed;
  top: --window-top; /* css变量 */
  left: 0;
  width: 100%;
  // background-color: $u-type-error;
  background: #ff5000;
  height: 100rpx;
}
.slot-wrap {
  flex: 1;
  padding-left: 20rpx;
  .search-wrap {
    width: 90%;
    background-color: rgb(242, 242, 242);
    border-radius: 100rpx;
    border: 2rpx solid rgb(255, 255, 255);
    height: 70rpx;
    line-height: 70rpx;
    color: #666;
    font-size: 26rpx;
    padding-left: 30rpx;
    margin: 0 20rpx;
    .u-search-icon {
        margin-right: 20rpx;
    }
  }
}
.navbar-right {
  color: #FFFFFF;
  margin-right: 24rpx;
  display: flex;
  .right-item {
    position: relative;
    color: #FFFFFF;
    display: flex;
    font-size: 40rpx;
    font-weight: 600;
    .icon-lang {
      width: 40rpx;
      height: 40rpx;
    }
  }
}
.floor-view {
  position: relative;
  height: calc(100% - 240rpx);
  overflow: auto;
  margin-top: 100rpx;
  padding-bottom: 140rpx;
}
.background-view {
  position: absolute;
  z-index: -1;
  left: 0;
  top: 0;
  // background-color: $u-type-error;
  background: #ff5000;
  width: 100%;
  height: 200rpx;
  border-bottom-right-radius: 4em 0.2em;
  border-bottom-left-radius: 4em 0.2em;
}
</style>
