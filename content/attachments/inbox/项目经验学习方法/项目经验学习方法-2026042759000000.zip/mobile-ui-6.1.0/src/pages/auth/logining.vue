<template>
    <view class="u-text-center u-p-60" style="background: #FFFFFF;height: 100%;">登录跳转中...</view>
</template>
<script>
    import * as API_Connect from '@/api/connect.js';
    import * as API_Members from '@/api/members.js';
    import Cache, {
        Keys
    } from '@/utils/cache.js';
    import { bindRelation } from '@/utils/distribution.js'

    export default {
        data() {
            return {
            }
        },
        onLoad() {
            let $this = this
            var localurl = window.location.href;
            var oldUuid = Cache.getItem(Keys.oldUuid)
            console.log(oldUuid);
            if (localurl.indexOf("code=") != -1) {
                var obj = getSearchString(window.location.search);
                var code = obj["code"];
                var state = obj["state"];
                console.log("code",code);
                console.log("state",state);
                //微信登陆
                if(state == "weixin"){
                    API_Connect.wxH5Login(code, Cache.getItem("uuid"), oldUuid).then(response=>{$this.loginCallback(response,false)})
                }
                //微博登陆
                if(state == "weibo"){
                    var local = localurl.split("?")[0];
                    var ecode = encodeURIComponent(local);
                    console.log("ecode",ecode)
                    let params = {
                        code:code,
                        uuid:Cache.getItem("uuid"),
                        redirect_uri:local
                    }
                    console.log("params",params)
                    API_Connect.weiboH5Login(params).then(response=>{$this.loginCallback(response,false)})
                }

            }
            //QQ登陆
            if (localurl.indexOf("access_token=") != -1) {
                if (QC.Login.check()) {
                    QC.Login.getMe(function(openId, accessToken) {
                        const access_token = accessToken;
                        API_Connect.qqH5Login(access_token, Cache.getItem("uuid")).then(response=>{$this.loginCallback(response,false)})
                    })
                }
            }
            //支付宝登陆
            if (localurl.indexOf("&source=alipay") != -1) {
                var obj = getSearchString(window.location.search);
                var alipay_code = obj["auth_code"]
                console.log("alipay_code",alipay_code)
                API_Connect.alipayH5Login(alipay_code,Cache.getItem("uuid")).then(response=>{$this.loginCallback(response,false)})
            }
            function getSearchString(Url) {
                var str = Url;
                // 获取URL中?之后的字符（去掉第一位的问号）
                str = str.substring(1, str.length);
                // 以&分隔字符串，获得类似name=xiaoli这样的元素数组
                var arr = str.split("&");
                var obj = new Object();
                // 将每一个数组元素以=分隔并赋给obj对象
                for (var i = 0; i < arr.length; i++) {
                    var tmp_arr = arr[i].split("=");
                    obj[decodeURIComponent(tmp_arr[0])] = decodeURIComponent(tmp_arr[1]);
                }
                return obj;
            }
        },
        onShow() {
            let $this = this
            //监听网络状态变化
            uni.onNetworkStatusChange(res => {
                //监听到有网络并且第一次没有加载数据的情况下初始化数据
                if (res.isConnected && $this.networkType === 'none') {
                    $this.handleChangeCaptchalUrl()
                    $this.getArticleDetail()
                }
            })
        },
        computed: {
        },
        methods: {
            //登录回调
            loginCallback(response,backToBefore) {
                Cache.setItem(Keys.accessToken, response.access_token)
                bindRelation()

                API_Members.getUserInfo().then(res => {
                    Cache.setItem(Keys.user, res)
                    if(backToBefore){
                        uni.navigateBack({
                            delta: 1,
                            animationType: 'slide-out-bottom',
                            animationDuration: 300
                        })
                    }else{
                       //#ifdef H5
                       let lastPage = Cache.getItem(Keys.h5LoginLastPage);
                       console.log("lastPage",lastPage)
                       if(lastPage == undefined || lastPage == ""){
                           lastPage = '/pages/tabs/mine/mine'
                       }
                       window.location.href = window.location.origin+lastPage;
                       //#endif
                       //#ifndef H5
                       uni.switchTab({
                           url: '/pages/tabs/mine/mine'
                       });
                       //#endif
                    }

                })
            }
        }
    }
</script>

<style>
</style>
