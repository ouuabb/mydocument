<template>
    <view class="settlement-wrap">
        <view class="settlement">
            <view class="goods-checbox-view u-flex">
                <view class="u-flex" @click="handleCheckAll">
                    <u-icon :color="all_checked ? '#FA3534' : ''" size="38" :name="all_checked ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
                    <text class="u-m-l-10">全选</text>
                </view>
                <text v-if="checkedCount" class="del-btn" @click="handleBatchDelete">删除已选</text>
            </view>
            <view class="u-flex">
                <view class="u-flex" @click="showDetailDialog = true">
                    <view class="u-margin-right-20">
                        <view class="u-flex u-row-right">
                            <text>合计：</text>
                            <custom-price :price="totalPrice.total_price" :fontWeight="600"></custom-price>
                        </view>
                        <view class="u-flex u-font-24 u-row-right cash-back" v-if="totalPrice.discount_price">
                            <text>优惠：</text>
                            <custom-price :price="totalPrice.discount_price" :size="24" :fontWeight="600"></custom-price>
                        </view>
                    </view>
                    <u-icon name="arrow-up" color="#333" style="margin-right: 10rpx;" />
                </view>
                <u-button
                    shape="circle"
                    size="small"
                    type="error"
                    :disabled="disabledSettleButton"
                    :custom-style="disabledSettleButton ? disabledCustomStyle : customStyle"
                    @click="goSettlement">
                    {{disabledSettleButton ? '不支持合并结算' : '去结算'}}
                </u-button>
            </view>
        </view>

        <!-- 金额明细弹窗 -->
        <u-popup
            v-model="showDetailDialog"
            mode="bottom"
            closeable
            borderRadius="30"
            height="70%"
            @close="showDetailDialog = false">
            <view class="detail-wrap">
                <view class="title">金额明细</view>
                <view class="selected-goods-content" v-if="checkList.length">
                    <view
                        v-for="(goods, index) in checkGoodsList" :key="index + '-' + goods.sku_id"
                        class="goods-img-item">
                        <image :src="goods.goods_image" alt="" class="goods-img"/>
                    </view>
                    <view
                        class="check-tips"
                        @click="showAllGoods = !showAllGoods">
                        已选{{checkedCount}}件商品
                        <u-icon
                            v-if="checkList.length > 4"
                            :name="showAllGoods ? 'arrow-up' : 'arrow-down'"
                            color="#999"
                            style="margin-right: 10rpx;" />
                    </view>
                </view>
                <view class="price-item">
                    <span sf-text-rule="subtotal_excluding_shipping">商品总额(不包含运费)：</span>
                    <custom-price :price="totalPrice.total_price" :size="28" :fontWeight="600"></custom-price>
                </view>
                <view class="price-item">
                    <span>积分抵扣：</span>
                    <span class="point-number">-{{totalPrice.paid_point}}</span>
                </view>
                <view
                class="price-item"
                    v-for="discount in totalPrice.discount_detail_list"
                    :key="discount.promotion_type">
                    <span>{{discount.promotion_type_name}}：</span>
                    <!-- <span class="price">-{{discount.discount_price | unitPrice}}</span> -->
					<custom-price class="price" isNeg :price="discount.discount_price" textColor="#333" fontWeight="500"></custom-price>
                </view>
                <view class="price-item">
                    <span>共优惠：</span>
                    <!-- <span class="price price-color">-{{totalPrice.discount_price | unitPrice}}</span> -->
					<custom-price class="price price-color" isNeg :price="totalPrice.discount_price" fontWeight="500"></custom-price>
                </view>
            </view>
        </u-popup>
    </view>
</template>

<script>
    import * as API_Trade from '@/api/trade.js'
    export default {
        name: 'SettlementBar',
        props: {
            cartList: {
                type: Array
            },
            totalPrice: {
                type: Object
            },
            checkedCount: {
                type: [Number, String]
            },
            allCount: {
                type: [Number, String]
            }
        },
        data() {
            return {
                // 明细弹窗显隐
                showDetailDialog: false,
                customStyle: {
                  background: 'linear-gradient(145deg,#ff9000,#ff5000 77%)',
                  color: '#FFFFFF',
                  fontSize: '26rpx',
                  height: '80rpx'
                },
                disabledCustomStyle: {
                    padding: '0 10px',
                    fontSize: '26rpx',
                    height: '70rpx'
                },
                // 是否展示全部已选商品
                showAllGoods: false
            }
        },
        computed: {
            // 已选商品列表
            checkList() {
                let list = []
                this.cartList.forEach(cart => {
                    let sku_list = cart.sku_list
                    // 促销商品合并检查
                    cart.group_list.forEach(item => {
                        sku_list = sku_list.concat(item.sku_list)
                    })
                    sku_list.forEach(item => {
                        if (item.checked) {
                            list.push(item)
                        }
                    })
                })
                return list
            },
            // 已选商品显示筛选
            checkGoodsList() {
                const checkList = this.$u.deepClone(this.checkList)
                if (this.showAllGoods) {
                    return checkList
                }
                return checkList.splice(0, 4)
            },
            // 是否全部选中
            all_checked() {
                return !!this.checkedCount && this.checkedCount === this.allCount;
            },
            /** 是否可结算 虚拟商品与普通商品部支持混合结算 */
            disabledSettleButton() {
                let haveVirtual = false
                let haveNormal = false
                this.cartList.forEach(cart => {
                    let list = cart.sku_list
                    // 促销商品合并检查
                    cart.group_list.forEach(item => {
                        list = list.concat(item.sku_list)
                    })
                    if (!haveNormal) {
                        haveNormal = list.some(goods => goods.checked && goods.goods_type === 'NORMAL')
                    }
                    if (!haveVirtual) {
                        haveVirtual = list.some(goods => goods.checked && goods.goods_type === 'VIRTUAL')
                    }
                })
                return haveVirtual && haveNormal
            }
        },
        methods: {
            /** 全选状态切换 */
            handleCheckAll(){
                console.log("=====handleCheckAll=====")
                uni.showLoading({title: '加载中',mask:true});
                const checked = this.all_checked ? 0 : 1
                API_Trade.checkAll(checked).then(res => {
                    setTimeout(function () {uni.hideLoading();}, 200)
                    this.$emit('refreshList')
                })
            },

            /** 批量删除 */
            handleBatchDelete() {
                console.log("=====handleBatchDelete=====")
                const checkList = this.$u.deepClone(this.checkList)
                const sku_ids = this.checkList.map(item => item.sku_id)
                uni.showModal({
                    title: '提示',
                    content: '确定要删除这个商品吗？',
                    cancelText: '取消',
                    confirmText: '确定',
                    confirmColor: '#FA3534',
                    success: (res) => {
                        if(res.confirm) {
                            API_Trade.deleteSkuItem(sku_ids).then(() => {
                                uni.showToast({ title: '成功' })
                                this.$emit('refreshList')
                            })
                        }
                    }
                })
            },

            /** 去结算 */
            goSettlement() {
                if(!this.checkedCount) {
                    this.$u.toast('您还没有选中商品哦~')
                } else {
                    uni.navigateTo({
                        url: '/order-module/checkout/checkout'
                    })
                }
            },

        }
    }
</script>

<style lang="scss" scoped>
.detail-wrap {
    padding: 100rpx 10rpx 150rpx;
    .title {
        position: fixed;
        z-index: 2;
        background: #fff;
        height: 90rpx;
        line-height: 90rpx;
        left: 0;
        top: 0;
        right: 0;
        text-align: center;
        font-size: 30rpx;
        font-weight: 500;
        color: #333;
    }
    .selected-goods-content {
        background: #f1f1f1;
        padding: 20rpx 0 0rpx 20rpx;
        border-radius: 6rpx;
        display: flex;
        flex-wrap: wrap;
        .check-tips{
            text-align: center;
            width: 100%;
            margin-bottom: 20rpx;
            color: #999;
            font-size: 24rpx;
        }
        .goods-img-item {
            margin: 0 20rpx 20rpx 0;
            width: calc(100% / 4 - 20rpx);
            height: 0;
            padding-bottom: calc(100% / 4 - 20rpx);
            position: relative;

            .goods-img {
                width: 100%;
                height: 100%;
                border-radius: 10rpx;
                position: absolute;
                top:0;
                left:0;
            }
        }
    }
    .price-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        color: #333;
        margin-top: 10px;
        padding: 0 10rpx;
        .point-number {
            color: #f42424;
            font-weight: 500;
        }
        .price {
            font-weight: 500;
        }
        .price-color {
            color: rgb(250, 53, 52);
        }
    }
}
.settlement-wrap {
    position: fixed;
    z-index: 99;
    bottom: 0;
    padding: 0rpx 20rpx;
    // #ifdef H5
    bottom: 93rpx;
    // #endif
    left: 0;
    margin-top: 100rpx;
    border: solid 2rpx #f2f2f2;
    background-color: #ffffff;
    height: 100rpx;
    width: 100%;
    -webkit-overflow-scrolling: touch;
}


.settlement {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    height: 100%;

    .del-btn {
        color: #FA3534;
        font-size: 24rpx;
        margin-left: 15rpx;
    }
    .cash-back {
        color: #7f828b;
    }
    // .disabled-btn {
    //     padding: 0 10px;
    //     font-size: 26rpx;
    //     height: 80rpx;
    // }
    // .settle-btn {
    //     background: linear-gradient(to right, #FB6C30 0%, #F01026 100%);
    //     color: #FFFFFF;
    //     height: 80rpx;
    //     font-size: 30rpx;
    // }
}


</style>