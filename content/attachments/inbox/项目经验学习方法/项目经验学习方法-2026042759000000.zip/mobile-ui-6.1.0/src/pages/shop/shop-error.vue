<template>
	<view class="shop-error">
		<view class="img">
		    <u-image width="280" height="280" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/mescroll-empty.png"></u-image>
		</view>
        <view class="tip">店铺不存在或者店铺已关闭</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss">
    .shop-error {
        box-sizing: border-box;
        width: 100%;
        padding: 200rpx 50rpx;
        text-align: center;
        .img {
            display: flex;
            justify-content: center;
        }
        .tip {
            margin-top: 20rpx;
            font-size: 24rpx;
            color: gray;
        }
    }
</style>
