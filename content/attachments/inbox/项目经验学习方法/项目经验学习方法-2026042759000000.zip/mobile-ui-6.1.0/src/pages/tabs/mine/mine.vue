<template>
  <view class="mine-container">
    <view class="u-flex-1">
      <view class="header-container">
        <image class="background-img" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/bg/bg6.png" lazy-load="false">
        </image>
        <view class="notice-bar-view" :style="{paddingTop: barHeight + 'px'}">
          <view class="u-flex u-row-between u-p-t-30">
            <view class="u-flex u-p-l-30">
              <view @click="handleJudgeLogin('/mine-module/setting')">
                <u-image width="100" height="100" shape="circle"
                         :src="user.face || defaultFace"></u-image>
              </view>
              <view class="mine-name-view u-m-l-30" v-if="user" @click="handleJudgeLogin('/mine-module/setting')">
                <view class="mine-nickname">{{user.nickname}}</view>
                <view class="level-box" v-if="user.level_name">
                  <image mode="widthFix" class="level-icon" v-if="user.level_icon" :src="user.level_icon" alt="" />
                  <image mode="widthFix" class="level-icon" v-else src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/level.png" alt="" />
                  {{user.level_name}}
                </view>
                <view v-if="!user.mobile">
                  <!-- #ifdef MP -->
                  <button class="bind-phone" size="mini" @getphonenumber="wxMiniBindPhone"
                          open-type="getPhoneNumber">点击绑定手机号
                    <u-icon class="u-m-l-15" name='arrow-right'></u-icon>
                  </button>
                  <!-- #endif -->
                  <!-- #ifndef MP -->
                  <button class="bind-phone" size="mini" @click="bindPhone">点击绑定手机号
                    <u-icon class="u-m-l-15" name='arrow-right'></u-icon>
                  </button>
                  <!-- #endif -->
                </view>
              </view>
              <view class="no-login-view" v-if="!user" @click="handleJudgeLogin('/pages/auth/login')">
                登录/注册
              </view>
            </view>
            <view class="block-jifen" v-if="haveSignActivity">
              <view @click="handleJudgeLogin('/mine-module/signIn/index')" class="mine-jifen">
                <u-icon name="gift" color="#c78a0b" size="26"></u-icon>
                <text class="u-m-l-10">签到有礼</text>
              </view>
            </view>
          </view>

          <view class="mine-common-container">

            <view class="mine-common-view">
              <view class="common-item" @click="handleJudgeLogin('/mine-module/collect')">
                <view class="num">{{ nums.goods_collect_count || '--' }}</view>
                <view class="title">收藏商品</view>
              </view>
              <u-line direction="col" length="50%" margin="30rpx"></u-line>
              <view class="common-item" @click="handleJudgeLogin('/mine-module/points')">
                <view class="num">{{ points.consum_point || '--'}}</view>
                <view class="title">消费积分</view>
              </view>
              <u-line direction="col" length="50%" margin="30rpx"></u-line>
              <view class="common-item" @click="handleJudgeLogin('/mine-module/coupon')">
                <view class="num">{{ coupons || '--' }}</view>
                <view class="title">优惠券</view>
              </view>
            </view>
          </view>
        </view>

      </view>
      <view class="body-view">
        <!-- 我的订单 -->
        <view class="block-view">
          <view class="block-header u-flex u-row-between">
            <view class="title">
              我的订单
            </view>
            <view class="more-text" @click="handleJudgeLogin('/order-module/order/order-list?status=', 'ALL')">
              全部订单
              <u-icon class="u-margin-left-8" name="arrow-right" color="#909399" size="27"></u-icon>
            </view>
          </view>

          <view class="block-body">
            <view class="block-item-5"
                  @click="handleJudgeLogin('/order-module/order/order-list?value=', 'WAIT_PAY')">
              <view class="block-img">
                <image mode="widthFix" class="block-icon"
                       src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/myOrder/待付款.png"></image>
              </view>
              <view class="block-title">待付款</view>
            </view>
            <view class="block-item-5"
                  @click="handleJudgeLogin('/order-module/order/order-list?value=', 'WAIT_SHIP')">
              <view class="block-img">
                <image mode="widthFix" class="block-icon"
                       src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/myOrder/待发货.png"></image>
              </view>
              <view class="block-title">待发货</view>
            </view>
            <view class="block-item-5"
                  @click="handleJudgeLogin('/order-module/order/order-list?value=', 'WAIT_ROG')">
              <view class="block-img">
                <image mode="widthFix" class="block-icon"
                       src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/myOrder/待收货.png"></image>
              </view>
              <view class="block-title">待收货</view>
            </view>
            <view class="block-item-5"
                  @click="handleJudgeLogin('/order-module/order/order-list?value=', 'WAIT_COMMENT')">
              <view class="block-img">
                <image mode="widthFix" style="width: 50rpx; height: 50rpx;"  class="block-icon"
                       src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/myOrder/评价.png"></image>
              </view>
              <view class="block-title">评价</view>
            </view>
            <view class="block-item-5"
                  @click="handleJudgeLogin('/order-module/order/after-sale/after-sale')">
              <view class="block-img">
                <image mode="widthFix" class="block-icon"
                       src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/myOrder/退款.png"></image>
              </view>
              <view class="block-title">退款/退货</view>
            </view>
          </view>
        </view>
        <u-line></u-line>
        <!-- 其它服务 -->
        <view class="block-view">
          <view class="block-header">
            <view class="title">
              其它服务
            </view>
            <view class="more-text">
            </view>
          </view>
          <!-- <u-line></u-line> -->
          <view class="block-body">
            <view class="block-item-4">
              <view class="block-icon shouchang-icon" @click="handleJudgeLogin('/mine-module/collect')">
                <image mode="widthFix" class="image-item"
                       src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/我的收藏.png" alt="" />
              </view>
              <view class="block-title">我的收藏</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/points')">
              <view class="block-icon jifen-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/积分.png" alt="" />
              </view>
              <view class="block-title">我的积分</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/myfootprint')">
              <view class="block-icon zuji-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/足迹.png" alt="" />
              </view>
              <view class="block-title">我的足迹</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/coupon')">
              <view class="block-icon youhuiquan-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/优惠券.png" alt="" />
              </view>
              <view class="block-title">优惠券</view>
            </view>
            <view class="block-item-4"
                  @click="handleJudgeLogin('/mine-module/distribution/distributionManage')">
              <view class="block-icon fenxiao-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/分销管理.png" alt="" />
              </view>
              <view class="block-title">分销管理</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/profile')">
              <view class="block-icon wode-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/个人信息更改.png"
                       alt="" />
              </view>
              <view class="block-title">个人信息</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/address')">
              <view class="block-icon dizhi-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/地址.png" alt="" />
              </view>
              <view class="block-title">地址管理</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/website-message')">
              <view class="block-icon xiaoxi-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/站内消息.png" alt="" />
              </view>
              <view class="block-title">站内消息</view>
            </view>

            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/account-safe')">
              <view class="block-icon anquan-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/账号安全.png" alt="" />
              </view>
              <view class="block-title">账号安全</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/members-asks')">
              <view class="block-icon zixun-icon">
                <image mode="widthFix" class="image-item" style="width: 50rpx; height: 50rpx;" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/咨询管理.png" alt="" />
              </view>
              <view class="block-title">咨询管理</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/increase-ticket')">
              <view class="block-icon zengpiao-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/增票资质.png" alt="" />
              </view>
              <view class="block-title">增票资质</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/my-receipt/receipt')">
              <view class="block-icon fapiao-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/我的发票.png" alt="" />
              </view>
              <view class="block-title">我的发票</view>
            </view>
            <view class="block-item-4" @click="handleJudgeLogin('/mine-module/account-balance')">
              <view class="block-icon yue-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/账户余额.png" alt="" />
              </view>
              <view class="block-title">账户余额</view>
            </view>
            <view @click="handleJudgeLogin('/mine-module/setting')" class="block-item-4">
              <view class="block-icon setting-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/设置.png" alt="" />
              </view>
              <view class="block-title">设置</view>
            </view>
            <view @click="handleJudgeLogin('/pages/shop/apply')" class="block-item-4">
              <view class="block-icon setting-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/店铺-fill.png" alt="" />
              </view>
              <view class="block-title">{{user.have_shop ? '我的店铺' : '店铺入驻'}}</view>
            </view>

            <view @click="handleJudgeLogin('/mine-module/evaluation-list')" class="block-item-4">
              <view class="block-icon iconfontevaluate-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/评价管理.png" alt="" />
              </view>
              <view class="block-title">评价管理</view>
            </view>
            <view @click="handleJudgeLogin('/mine-module/help-center')" class="block-item-4">
              <view class="block-icon help-icon">
                <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/帮助中心.png" alt="" />
              </view>
              <view class="block-title">帮助中心</view>
            </view>
            <view @click="handleJudgeLogin('/order-module/order/complaint-apply/apply-list')" class="block-item-4">
                <view class="block-icon wode-icon">
                  <image mode="widthFix" class="image-item" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/otherServices/交易投诉.png" alt="" />
                </view>
                <view class="block-title">交易投诉</view>
            </view>
          </view>
        </view>
      </view>
    </view>
    <!-- 为你推荐商品 -->
    <goods-recommend ref="goodsRecommend" title="为你推荐"></goods-recommend>
    <u-back-top :scroll-top="scrollTop" :customStyle="customStyle" :iconStyle="iconStyle"></u-back-top>
    <u-mask :show="show_message_mask" class="message-mask" :custom-style="{ background: 'rgba(0,0,0,0)' }" :zoom="false"
      @click="show_message_mask = false">
      <view class="message-menus" :style="{ top: `calc(${barHeight}px + 88rpx)` }">
        <view class="item-menus" @tap="handleJudgeLogin('/chat-module/chat-list')">
          在线客服{{ unread_chat_num > 0 ? `(${unread_chat_num > 99 ? '99+' : unread_chat_num})` : '' }}
        </view>
        <view class="item-menus" @tap="handleJudgeLogin('/mine-module/website-message')">站内消息</view>
      </view>
    </u-mask>

    <!-- 新用户优惠券领取提示 -->
    <coupon-receive v-if="showReceivePopup" />
  </view>
</template>

<script>
import * as API_Members from '@/api/members.js'

import Cache, { Keys } from '@/utils/cache.js'
import * as API_Connect from '@/api/connect.js'
import * as API_Message from '@/api/message'
import * as API_Promotions from '@/api/promotions'
import config from '@/config/config'
import CouponReceive from '../home/components/CouponReceive'

export default {
  components: {
    CouponReceive
  },
  data() {
    return {
      config,
      nums: '',
      points: '', //积分
      coupons: '', //优惠券
      defaultFace: 'https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-noface.jpg',
      // #ifdef MP
      barHeight: this.customBar, //状态栏+导航栏高度
      user: null,
      // #endif
      // #ifdef APP-PLUS || H5
      barHeight: this.statusBar, //状态栏高度
      user: Cache.getItem(Keys.user),
      // #endif
      scrollTop: 0, //滚动高度
      customStyle: {
        background: '#B2B2B2'
      },
      iconStyle: {
        color: '#FFFFFF',
        fontSize: '36rpx'
      },
      site: Cache.getItem(Keys.site),
      show_message_mask: false,
      unread_chat_num: 0,
      unread_timer: '',
      showReceivePopup: false,
      haveSignActivity: false
    }
  },
  //每次进入页面都会调用
  onShow() {
    const newlyRegisteredUser = Cache.getItem(Keys.newlyRegisteredUser)
    if (newlyRegisteredUser) {
      // 由注册跳转返回 检查是否有新人优惠券
      this.showReceivePopup = true
    }
    const cacheUser = Cache.getItem(Keys.user)
    if (cacheUser) {
      this.user = cacheUser
      this.initPage()
      getApp().getSiteData()
    } else {
      this.user = ''
      this.nums = ''
      this.points = ''
      this.coupons = ''
    }
  },
  onLoad() {
    //监听退出登录消息
    uni.$on('logout', function (data) {
      this.user = ''
      this.nums = ''
      this.points = ''
      this.coupons = ''
    })
  },
  // 下拉刷新
  onPullDownRefresh() {
    const $this = this
    setTimeout(function () {
      //停止刷新
      uni.stopPullDownRefresh()
      // 这里放刷新数据的方法
      if ($this.user) {
        $this.initPage()
      }
    }, 1000)
  },
  //监听导航栏自定义按钮事件
  onNavigationBarButtonTap(e) {
    if (e.index == 0) {
      this.toMessage()
    }
    if (e.index == 1) {
      this.onSetting()
    }
  },
  // 滚动到底部
  onReachBottom() {
    this.$refs.goodsRecommend.params.page_no += 1
    this.$refs.goodsRecommend.getGoodsList()
  },
  //滚动距离
  onPageScroll(e) {
    this.scrollTop = e.scrollTop
  },
  methods: {
    initPage() {
      this.getMember()
      this.getUnreadChatNum()
      this.getStatisticsNum()
      this.getPoints()
      this.getCoupons()
      this.showReceivePopup = false


    },

    /** 获取签到活动数据 */
    getSignActivity() {
      API_Promotions.getSignActivity().then(res => {
        if (res) {
          this.haveSignActivity = true
        }
      })
    },

    //点击事件
    handleJudgeLogin(url, value) {
      if (url === '/mine-module/test') {
        uni.navigateTo({ url: url })
        return;
      }
      this.showReceivePopup = false
      let $this = this
      uni.getNetworkType({
        success(res) {
          if (res.networkType !== 'none') {
            $this.judgeLogin(() => {
              if (value) {
                uni.navigateTo({ url: url + value })
              } else {
                uni.navigateTo({ url: url })
              }
            }, 'force')
          } else {
            $this.$u.toast('当前无网络，请检查后重试')
          }
        }
      })
    },
    wxMiniBindPhone(e) {
      if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
        return
      }
      const encrypted = e.detail.encryptedData
      const iv = e.detail.iv
      API_Connect.wxMiniBindPhone(encrypted, iv).then(res => {
        if (res.code === 200) {
          var user = Cache.getItem(Keys.user)
          user.mobile = res.mobile
          Cache.setItem(Keys.user, user)
          this.user = user
          this.getMember()
        } else {
          uni.showModal({
            title: '提示',
            content: `${res.code === 501 ? '已经绑定过其他会员' : '未绑定手机号'}, 去手动设置？`,
            cancelText: '取消',
            confirmText: '确定',
            success: res => {
              if (res.confirm) {
                uni.navigateTo({ url: '/pages/auth/bind-phone' })
              }
            }
          })
        }
      })
    },
    bindPhone() {
      uni.navigateTo({ url: '/pages/auth/bind-phone' })
    },
    //获取用户信息
    getMember() {
      API_Members.getUserInfo().then(res => {
        this.user = res
        Cache.setItem(Keys.user, this.user)
      })
    },
    //获取统计数量
    getStatisticsNum() {
      API_Members.getStatisticsNum().then(res => {
        this.nums = res
      })
    },
    // 获取消费积分
    getPoints() {
      API_Members.getPoints().then(response => {
        this.points = response
      })
    },
    //获取可用优惠券
    getCoupons() {
      const params = {
        page_no: 1,
        page_size: 10,
        status: 1
      }
      API_Members.getCoupons(params).then(response => {
        this.coupons = response.data_total
      })
    },
    //设置
    onSetting() {
      this.handleJudgeLogin('/mine-module/setting')
    },
    toMessage() {
      if (config.im) {
        this.show_message_mask = true
      } else {
        this.handleJudgeLogin('/mine-module/website-message')
      }
    },
    // 获取未读客服IM消息数量
    getUnreadChatNum() {
      if (!config.im || !this.user) return
      clearTimeout(this.unread_timer)
      API_Message.getUnreadChatNum().then(res => {
        this.unread_chat_num = res
        this.unread_timer = setTimeout(this.getUnreadChatNum, 5000)
      })
    }
  }
}
</script>

<style lang="scss">
.mine-container ::v-deep {
  .u-p-t-30{
    padding-top:0 !important;
  }
}
.bind-phone {
  font-size: 22rpx !important;
  color: #FFFFFF;
  background-color: #ff5000;
  margin: 10rpx 0;
  border-radius: 30rpx;

  &:after {
    border: none !important;
  }
}

.wrap {
  display: flex;
  flex-direction: column;
  height: calc(100vh - var(--window-top));
  width: 100%;
}

.mine-container {
  background-color: #fff;
}

.header-container {
  width: 100%;
  position: relative;
  .background-img {
    width: 100%;
    // #ifdef MP
    height: 470rpx;
    // #endif
    // #ifndef MP
    height: 440rpx;
    // #endif

  }
  .notice-bar-view {
    // #ifndef MP
    padding-top: 40px !important;
    // #endif
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    margin: 0 20rpx;
    height: 320rpx;
    border-radius: 10rpx;

    .mine-name-view {
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: flex-start;

      .mine-nickname {
        font-size: 40rpx;
        font-weight: 500;
      }
      .level-box {
        padding: 0 22rpx 0 15rpx;
        font-size: 24rpx;
        height: 45rpx;
        background: rgb(255, 80, 0);
        border-radius: 32rpx;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-top: 10rpx;
        .level-icon {
          width: 35rpx !important;
          height: 35rpx !important;
          margin-right: 10rpx;
        }
      }

      .mine-uname {
        font-size: 25rpx;
        margin-top: 7rpx;
      }
    }

    .no-login-view {
      margin-left: 30rpx;
      font-size: 30rpx;
      color: #fff;
    }

    .mine-jifen {
      font-size: 22rpx;
      padding: 12rpx 25rpx;
      border-top-left-radius: 40rpx;
      border-bottom-left-radius: 40rpx;
      color: #c78a0b;
      background: linear-gradient(to right, #fded5d, #fec923);
      margin-right: -20rpx;
    }

    ::v-deep {
      .u-badge {
        line-height: 20rpx !important;
        font-size: 20rpx !important;
      }
    }
    .mine-common-container {
      padding: 0 6%;
      display: flex;
      justify-content: center;

      .mine-common-view {
        display: flex;
        flex: 1;
        flex-direction: row;
        justify-content: space-between;
        // #ifdef MP
        margin-top: 50rpx;
        // #endif
        // #ifndef MP
        margin-top: 80rpx;
        // #endif
        padding: 10rpx 30rpx 80rpx;
        background-color: rgba(255, 255, 255, 0.5);
        border-radius: 25rpx;

        .common-item {
          display: flex;
          flex: 1;
          flex-direction: column;
          align-items: center;
          padding: 6rpx 0;
          color: black;

          .num {
            font-size: 34rpx;
            font-weight: 600;
            color: #333;
            margin-bottom: 15rpx;
          }

          .title {
            display: flex;
            flex: 1;
            color: #999;
            flex-wrap: nowrap;
            font-size: 24rpx;
          }
        }
      }
    }

  }

}




.mine-header {
  height: 220rpx;
  color: #F2F2F2;
  // background: linear-gradient(to right, #6f25f3, #6d25f2);
  background: withe;

  .mine-setting {
    position: relative;
  }
}

.body-view {
  // margin-top: 10rpx;

  .block-view {
    background-color: #fff;
    margin: 10rpx;
    border-radius: 10rpx;
    padding: 10rpx 0;

    .block-header {
      font-size: 28rpx;
      font-weight: 600;
      margin: 20rpx 0;

      .title {

        padding: 0 20rpx;
        font-size: 30rpx;
      }

      .more-text {
        color: #909399;
        font-size: 26rpx;
        font-weight: 400;
        margin-right: 20rpx;
      }
    }

    .block-body {
      display: flex;
      flex-direction: row;
      justify-content: left;
      flex-wrap: wrap;
      margin: 20rpx 0;

      .block-item-5 {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;

        .pay-icon {
          background: linear-gradient(to right, #ff557f 0%, #ffaa7f 100%);
        }

        .send-icon {
          background: linear-gradient(to right, #558AF3 0%, #72B7EF 100%);
        }

        .deliver-icon {
          background: linear-gradient(to right, #00C6AF 0%, #8DE5C1 100%);
        }

        .message-icon {
          background: linear-gradient(to right, #FE5500 0%, #E9F000 100%);
        }

        .service-icon {
          background: linear-gradient(to right, #EB9A3B 0%, #FACD80 100%);
        }

        .block-img {
          border-radius: 50%;
          width: 70rpx;
          height: 70rpx;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 10rpx;

          .block-icon {
            width: 70rpx;
            height: 70rpx;
          }
        }

        .block-title {
          font-size: 24rpx;
          color: #606266;
        }
      }



      .block-item-4 {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 20rpx 0;
        flex: 0 0 calc(25%);

        .block-icon {
          width: 70rpx;
          height: 70rpx;
          margin: 0 16rpx 16rpx 16rpx;
          display: flex;
          align-items: center;
          justify-content: center;
          .image-item {
            width: 60rpx;
            height: 60rpx;
          }
        }

        .block-icon1 {
          width: 70rpx;
          height: 70rpx;
          margin: 0 38rpx 16rpx 16rpx;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .block-title {
          font-size: 24rpx;
          color: #606266;
        }
      }

      .block-bottom {
        display: flex;
        width: 100%;
        margin-top: 100rpx;
      }
    }

  }

}

.message-mask {
  .message-menus {
    position: absolute;
    right: 10rpx;
    background-color: #424242;
    border-radius: 10rpx;
    padding: 20rpx;
    box-sizing: border-box;
    box-shadow: 0 0 20rpx 0 rgba(0, 0, 0, .5);

    &::after {
      content: '';
      position: absolute;
      top: -10rpx;
      right: 14rpx;
      width: 40rpx;
      height: 40rpx;
      background-color: #424242;
      border-radius: 4rpx;
      transform: rotate(45deg);
    }

    .item-menus {
      display: flex;
      align-items: center;
      height: 60rpx;
      color: #9e9e9e;
    }
  }
}
</style>
