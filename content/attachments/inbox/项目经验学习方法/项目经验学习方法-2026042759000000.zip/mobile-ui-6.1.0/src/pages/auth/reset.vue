<template>
	<view class="reset-container">
        <u-gap height="40" bg-color="#FFFFFF"></u-gap>
        <view class="reset-view">
            <view class="form-view" v-if="step === 1">
                <u-form :model="validAccountForm" ref="validAccountForm">
                    <u-form-item label-position="top">
                        <u-input v-model="validAccountForm.account" placeholder="请输入账户名" />
                    </u-form-item>
                    <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
                        <u-input v-model="validAccountForm.img_code" placeholder="请输入图片验证码" maxlength="4"/>
                        <u-image slot="right" width="120" height="60" :src="captcha_url" @click="handleChangeCaptchalUrl" ></u-image>
                    </u-form-item>
                </u-form>
                <u-button :disabled="val_disabled_account" class="u-m-20" type="error" shape="circle" @click="handleValidAccount">验证账户</u-button>
            </view>
            <view class="form-view" v-if="step === 2">
                <u-form :model="validMobileForm" ref="validMobileForm">
                    <u-form-item label-position="top">
                        <u-input v-model="validMobileForm.mobile" disabled maxlength="11"/>
                    </u-form-item>
                    <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
                        <u-input v-model="validMobileForm.img_code" placeholder="请输入图片验证码" maxlength="4"/>
                        <u-image slot="right" width="120" height="60" :src="captcha_url" @click="handleChangeCaptchalUrl" ></u-image>
                    </u-form-item>
                    <u-form-item label-position="top">
                        <u-input v-model="validMobileForm.sms_code" placeholder="请输入短信验证码" maxlength="6"/>
                        <u-button slot="right" type="error" size="mini" @click="handleCode">{{codeTips}}</u-button>
                        <u-verification-code seconds="60" ref="uCode" @change="handleCodeChange"></u-verification-code>
                    </u-form-item>
                </u-form>
                <u-button :disabled="val_disabled_mobile" class="u-m-20" type="error" shape="circle" @click="handleNextStep">下一步</u-button>
            </view>
            <view class="form-view" v-if="step === 3">
                <u-form :model="changePasswordForm" ref="changePasswordForm">
                    <u-form-item label-position="top">
                        <u-input v-model="changePasswordForm.password" type="password" placeholder="请输入密码" maxlength="20"/>
                    </u-form-item>
                    <u-form-item label-position="top">
                        <u-input v-model="changePasswordForm.rep_password" type="password" placeholder="请确认密码" maxlength="20"/>
                    </u-form-item>
                </u-form>
                <u-button :disabled="val_disabled_password" class="u-m-20" type="error" shape="circle" @click="submitChangeForm">确认修改</u-button>
            </view>
        </view>
        <!-- 腾讯天御验证码-小程序 -->
        <!-- #ifdef MP-WEIXIN -->
        <t-captcha
            id="registerCaptcha"
            :app-id="validator.tencent.mini_captcha_app_id"
            @verify="handlerVerify"
            @ready="handlerReady"
            @close="handlerClose"
            @error="handlerError" />
        <!-- #endif -->
	</view>
</template>

<script>
    import * as API_Common from '@/api/common.js';
    import * as API_Passport from '@/api/passport.js';
    import Cache,{Keys} from '@/utils/cache.js';
    import { Foundation } from '@/app-utils/index.js'

    export default {
        data() {
          return {
              uuid: Cache.getItem('uuid'),
              step: 1,
              validAccountForm: {
                  account: '',
                  img_code: ''
              }, // 校验账户信息 表单
              validMobileForm: {
                  mobile: '',
                  img_code: '',
                  sms_code: ''
              }, //校验手机 表单
              changePasswordForm: {
                  password: '',
                  rep_password: ''
              },//修改密码 表单
              captcha_url: '', //图片验证码
              codeTips: '获取验证码',
              // 验证类型
              validator: {}
          };
        },
        computed: {
            // 验证账户按钮 按钮是否禁用
            val_disabled_account() {
                const { account, img_code } = this.validAccountForm
                if (this.validator.validator_type === 'IMAGE') {
                  return !(account && img_code)
                }
                return !account
            },
            // 验证手机号 按钮是否禁用
            val_disabled_mobile() {
                const { img_code, sms_code } = this.validMobileForm
                if (this.validator.validator_type === 'IMAGE') {
                  return !(img_code && sms_code)
                }
                return !sms_code
            },
            // 确认修改密码 按钮是否禁用
            val_disabled_password() {
                const { password, rep_password } = this.changePasswordForm
                return (!password || !rep_password) || (password !== rep_password)
            }
        },
        onLoad() {
            this.handleChangeCaptchalUrl()
            this.getValidator()
        },
        methods: {
            /** 获取验证码方式 */
            getValidator(){
              API_Common.getValidator().then(res => {
                this.validator = res
              })
            },
            // 获取图片验证码
            handleChangeCaptchalUrl() {
                const uuid = this.step === 1 ? this.uuid : this.validMobileForm.uuid
                this.captcha_url = API_Common.getValidateCodeUrl(uuid, 'FIND_PASSWORD')
            },
            /** 验证账户提交 */
            validAccountSubmit() {
              const { uuid } = this
              const { account, img_code, randstr, ticket } = this.validAccountForm
              const validator_type = this.validator.validator_type
              const params = {
                uuid,
                account,
                scene: 'FIND_PASSWORD'
              }
              if (validator_type === 'IMAGE' && !img_code) {
                this.$u.toast('请输入图片验证码')
                return
              }
              if (validator_type === 'IMAGE') {
                  params.captcha = img_code
              } else if (validator_type === 'TENCENT') {
                  params.randstr = randstr
                  params.ticket = ticket
              }
              API_Passport.validAccount(params).then((response) => {
                  this.validMobileForm.mobile = Foundation.formatMobile(response.mobile)
                  this.validMobileForm.uname = response.uname
                  this.validMobileForm.uuid = response.uuid
                  this.step = 2
                  this.handleChangeCaptchalUrl()
              }).catch(() => {
                  this.handleChangeCaptchalUrl
              })
            },
            // 验证账户
            handleValidAccount() {
              const validator_type = this.validator.validator_type
              //如果是图片验证码
              if (validator_type === 'IMAGE') {
                this.validAccountSubmit()
              } else if(validator_type === 'TENCENT') {
                //如果是腾讯验证码
                this.handlerTenCent(this.validAccountCallBack)
              }
            },
            /** 验证账户图片验证回调 */
            validAccountCallBack(res) {
              if (res.ret === 0) {
                this.validAccountForm.randstr = res.randstr
                this.validAccountForm.ticket = res.ticket

                this.validAccountSubmit()
              }
            },
            // 获取短信验证码
            handleCode() {
                if(this.$refs.uCode.canGetCode) {
                  const validator_type = this.validator.validator_type
                  //如果是图片验证码
                  if (validator_type === 'IMAGE') {
                    this.sendFindPasswordSms()
                  } else if(validator_type === 'TENCENT') {
                    //如果是腾讯验证码
                    this.handlerTenCent(this.sendMsgCallback)
                  }
                } else {
                  this.$u.toast('倒计时结束后再发送')
                }
            },
            handlerTenCent(callback){
              // #ifdef H5
              try {
                const captcha = new TencentCaptcha(this.validator.tencent.captcha_app_id, callback, {})
                // 调用方法，显示验证码
                captcha.show()
              } catch (error) {
                // 加载异常，调用验证码js加载错误处理函数
                this.loadErrorCallback()
              }
              // #endif
              // #ifdef MP-WEIXIN
              this.selectComponent('#captcha').show()
              // #endif
            },
            /** 图片滑动验证回调 */
            sendMsgCallback(res) {
                if (res.ret === 0) {
                  this.validMobileForm.randstr = res.randstr
                  this.validMobileForm.ticket = res.ticket
                  this.sendFindPasswordSms()
                }
            },
            sendFindPasswordSms() {
              const { uuid, img_code, randstr, ticket } = this.validMobileForm
              const validator_type = this.validator.validator_type

              if (validator_type === 'IMAGE' && !img_code) {
                this.$u.toast('请输入图片验证码')
                return
              }
              const params = {
                uuid,
                scene: 'FIND_PASSWORD'
              }
              if (validator_type === 'IMAGE') {
                  params.captcha = img_code
              } else if (validator_type === 'TENCENT') {
                  params.randstr = randstr
                  params.ticket = ticket
              }
              API_Passport.sendFindPasswordSms(params).then(res => {
                  this.$u.toast('验证码已发送')
                  // 通知验证码组件内部开始倒计时
                  this.$refs.uCode.start()
              }).catch(this.handleChangeCaptchalUrl)
            },
            //验证码发生变化时
            handleCodeChange(text) {
            	this.codeTips = text;
            },
            //下一步 验证短信验证码
            handleNextStep() {
                const { uuid, sms_code } = this.validMobileForm
                API_Passport.validFindPasswordSms(uuid, sms_code).then(() => {
                    this.step = 3
                    this.handleChangeCaptchalUrl()
                }).catch(this.handleChangeCaptchalUrl)
            },
            //找回密码
            submitChangeForm() {
                const { uuid } = this.validMobileForm
                const { password } = this.changePasswordForm
                API_Passport.changePassword(uuid, password).then(() => {
                    this.$u.toast('密码找回成功，请牢记您的新密码')
                    uni.navigateBack()
                }).catch(this.handleChangeCaptchalUrl)
            }
        }
	}
</script>

<style lang="scss" scoped>
    .reset-container {
        .reset-view {
            background-color: #FFFFFF;
            margin: 30rpx;
            border-radius: 20rpx;
            padding: 20rpx 40rpx;
            box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
        }
    }
</style>
