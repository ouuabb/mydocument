<template>
    <view class="auth-mobile-wrap">
        <view class="img-box">
            <image :src="face" alt="" class="user-img"/>
        </view>
        <button
            class="auth-btn"
            open-type="getPhoneNumber"
            @getphonenumber="getPhoneNumberEvent">授权手机号一键绑定</button>


        <view class="agreement u-flex">
            <u-checkbox v-model="policyCheck" size="24" active-color="#FA3534" @change="checkboxChange"></u-checkbox>
            <view class="agreement-text">
            我已阅读并同意
             <text class="txt" @click="showPolicy = true">《{{ site.site_name }}隐私政策》</text> -->
            </view>
        </view>

        <!-- 隐私政策弹出层 -->
        <u-popup class="policy-view" v-model="showPolicy" mode="bottom" length="70%" border-radius="20" :safe-area-inset-bottom="true"> -->
            <view class="u-p-30 u-text-center" style="font-weight: 600;">
                {{ policy.article_name }}
            </view>
            <scroll-view scroll-y="true" class="policy-content" :style="{height: scrollHeight * 0.7 - 30 + 'px'}">
                <rich-text :nodes="policy.nodes"></rich-text>
            </scroll-view>
        </u-popup>
    </view>
</template>

<script>
    import * as API_Connect from '@/api/connect.js'
    import * as API_Article from '@/api/article.js'
    import parseHtml from '@/common/html-parser.js'
    import Cache, {
        Keys
    } from '@/utils/cache.js';

    export default {
        data() {
            return {
                // policyCheck: true, //已阅读并同意协议
                site: Cache.getItem(Keys.site),
                // showPolicy: false, //显示协议
                policy: '', //协议内容
                face: '',
                back_url: ''
            };
        },
        onLoad(options) {
            const user = Cache.getItem(Keys.user)
            if (user) {
                this.face = user.face
            }
            if (options.back_url) {
                this.back_url = decodeURIComponent(options.back_url)
            }
            this.getArticleDetail()
        },

        methods: {
            //获取隐私政策
            getArticleDetail() {
                API_Article.getArticlesByPosition('REGISTRATION_AGREEMENT').then(response => {
                    response.content = response.content.replace(new RegExp('<' + 'img', 'gi'), '<' + 'img style="max-width:100%;height:auto"')
                    response.nodes = parseHtml(response.content)
                    this.policy = response
                })
            },
            //选择阅读并同意协议
            // checkboxChange(e) {
            //     this.policyCheck = e.value
            // },
            getPhoneNumberEvent(e) {
                if (!e.detail.iv) {
                    uni.showToast({
                        title:'获取手机号失败',
                        icon:'none'
                    })
                    return
                }
                const obj = {
                    iv: e.detail.iv,
                    encryptedData: e.detail.encryptedData
                }
                this.bindMobile(obj)
            },

            /** 绑定手机号 */
            bindMobile(params) {
                API_Connect.wxMiniBindPhone(params.encryptedData, params.iv).then(res => {
                    if (res.code === 200) {
                        // 更新用户数据
                        const user = Cache.getItem(Keys.user)
                        user.mobile = res.phone
                        Cache.setItem(Keys.user, user)
                        if (this.back_url) {
                            uni.reLaunch({
                                url: this.back_url
                            })
                        } else {
                            uni.switchTab({ url: '/pages/tabs/mine/mine' })
                        }
                    } else {
                        uni.showModal({
                            title: '提示',
                            content: `${res.code === 501 ? '已经绑定过其他会员' : '未绑定手机号'}, 去手动设置？`,
                            cancelText: '取消',
                            confirmText: '确定',
                            success: res => {
                                if (res.confirm) {
                                    uni.navigateTo({ url: '/pages/auth/bind-phone' })
                                }
                            }
                        })
                    }
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .auth-mobile-wrap {
        height: 100vh;
        background: #fff;
        padding: 60rpx;
        box-sizing: border-box;
        position: relative;
        .img-box {
            text-align: center;
            padding-bottom: 100rpx;
        }
        .user-img {
            width: 120rpx;
            height: 120rpx;
            border-radius: 50%;
        }
        .agreement {
            position: absolute;
            bottom: 80rpx;
            ::v-deep .u-checkbox {
                display: inline-block;
            }
            .agreement-text {
            font-size: 22rpx;
            .txt {
                color: $u-type-error;
            }
            }
        }
        .auth-btn {
            border-radius: 40rpx;
            height: 70rpx;
            line-height: 70rpx;
            color: #fff;
            font-size: 26rpx;
            background: linear-gradient(to right, #FD5632 0%, #EF0D25 100%) !important;
            &:after {
                border: none !important;
            }
        }
    }
</style>
