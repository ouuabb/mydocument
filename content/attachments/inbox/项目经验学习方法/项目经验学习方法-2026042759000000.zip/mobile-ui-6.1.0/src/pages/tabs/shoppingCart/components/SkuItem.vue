<template>
    <view>
        <u-swipe-action
            :show="sku.show"
            :index="sku.sku_id"
            v-for="(sku) in skuList"
            :key="sku.sku_id"
            :options="options"
            @click="handleDelete">
            <view class="cart-list" :class="sku.invalid === 1 ? 'invalid' : ''" >
                <view class="cart-item u-flex u-col-center">
                    <view class="goods-checkbox-view" @click="handleCheckSku(sku)">
                        <u-icon
                            v-if="sku.invalid === 1"
                            color="#efefef"
                            size="38"
                            name="choose"
                            custom-prefix="custom-icon"></u-icon>
                        <u-icon
                            v-else
                            :color="sku.checked === 1 ? '#FA3534' : '#999'"
                            size="38"
                            :name="sku.checked === 1 ? 'xuanze' : 'choose'"
                            custom-prefix="custom-icon"></u-icon>
                    </view>
                    <view class="u-flex u-flex-1" style="padding-left: 10rpx;">
                        <navigator :url="'/goods-module/goods?goods_id=' + sku.goods_id  + '&&sku_id=' + sku.sku_id" hover-class="none" class="goods-img-view">
                            <view class="sku-img">
                                <u-image border-radius="10" width="180" height="180" :src="sku.goods_image"></u-image>
                                <view class="invalid-mask" v-if="sku.invalid === 1">
                                    {{sku.error_message}}
                                </view>
                            </view>
                        </navigator>
                        <view class="goods-info-view u-flex-1">
                            <navigator :url="'/goods-module/goods?goods_id=' + sku.goods_id  + '&&sku_id=' + sku.sku_id" hover-class="none" class="u-line-2 goods-title">
                                <view class="goods-tag" v-if="sku.goods_type === 'VIRTUAL'">虚拟商品</view>
                                {{ sku.name }}
                            </navigator>
                            <view class="goods-spec-view" v-if="sku.spec_list && sku.spec_list.length">
                                <text class="goods-spec">{{sku.spec_list | formatterSkuSpec }}</text>
                            </view>
                            <view class="promotion-view" v-if="sku.promotion_tags && sku.promotion_tags.length">
                                <u-tag
                                    class="u-m-r-20"
                                    type="error"
                                    mode="plain"
                                    v-for="(tag, tagIndex) in sku.promotion_tags"
                                    :key="tagIndex"
                                    :text="tag"  />
                            </view>
                            <view class="u-flex u-row-between u-m-t-10">
                                <custom-price :price="sku.original_price" :fontWeight="600" :size="33"></custom-price>
                                <span class="point-number" v-if="sku.point_disable === 1 && sku.point"> + {{sku.point}}积分</span>
                                <view v-if="sku.invalid === 1">x {{sku.num}}</view>
                                <view v-else>
                                    <u-number-box
                                        :min="1"
                                        :max="sku.enable_quantity"
                                        :value="sku.num"
                                        @minus="handleBuyNum"
                                        @blur="handleBuyNum"
                                        @plus="handleBuyNum"
                                        :index="sku.sku_id" >
                                    </u-number-box>
                                </view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </u-swipe-action>
    </view>
</template>

<script>
import * as API_Trade from '@/api/trade.js'
import { RegExp } from '@/app-utils/index.js'

export default {
  name: 'SkuItem',
  props: {
    skuList: {
      type: Array
    }
  },
  data() {
    return {
      // swipe config
      options: [
        {
          text: '删除',
          style: {
            backgroundColor: '#FA3534'
          }
        }
      ]
    }
  },
  methods: {
    /** 购买数量发生变化(避免使用@change事件带来的多次请求) */
    async handleBuyNum(e) {
      console.log('购买数量发生变化='+JSON.stringify(e))
      if (!RegExp.integer.test(e.value)) {
        this.$u.toast('请输入大于0的正整数')
        return
      }
      if (e.value > 2000000000 ) {
        this.$u.toast('请输入小于2000000000的正整数')
        return
      }
      const skuId = e.index
      const num = e.value
      try {
        uni.showLoading({ title: '请稍候...', mask: true })
        await API_Trade.updateSkuNum(skuId, num)
        this.$emit('refreshList')
      } catch (e) {
        const sku = this.skuList.find(item => item.sku_id === skuId)
        if (!sku) return
        let oldNum = sku.num
        sku.num = 1
        this.$nextTick(() => {
          sku.num = oldNum
          this.$forceUpdate()
        })
      }
    },

    /** 商品选中切换 */
    handleCheckSku(sku){
      if (sku.invalid === 1) return
      console.log("=====handleCheckSku=====")
      uni.showLoading({title: '加载中',mask:true});
      const checked = sku.checked ? 0 : 1
      API_Trade.updateSkuChecked(sku.sku_id, checked).then(res => {
        setTimeout(function () {uni.hideLoading();}, 200)
        this.$emit('refreshList')
      })
    },

    /** 左滑点击删除 */
    handleDelete(sku_id) {
      console.log("=====handleDelete=====")
      uni.showModal({
        title: '提示',
        content: '确定要删除这个商品吗？',
        cancelText: '取消',
        confirmText: '确定',
        confirmColor: '#FA3534',
        success: (res) => {
          if(res.confirm) {
            API_Trade.deleteSkuItem(sku_id).then(() => {
              uni.showToast({ title: '成功' })
              this.$emit('refreshList')
            })
          }
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.cart-list {
    padding: 10rpx 20rpx;
    box-sizing: border-box;
    overflow: hidden;
    background-color: #FFFFFF;
    &.invalid {
        background: rgba(245,245,245, .6) !important;
    }
    &.invalid .cart-item {
        filter: grayscale(1);
    }
    .error-message {
        padding-left: 17%;
        color: #FA3534;
    }
    .cart-item {
        width: 100%;
        // background-color: #FFFFFF;
        .sku-img {
            width: 180rpx;
            height: 180rpx;
            position: relative;
            .invalid-mask {
                background: rgba(0,0,0,.3);
                width: 100%;
                height: 100%;
                position: absolute;
                top: 0;
                left: 0;
                color: #fff;
                font-weight: 500;
                text-align: center;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 22rpx;
            }
        }
        .goods-checkbox-view {
            line-height: 200rpx;
            display: flex;
            justify-content: center;
        };
        .goods-img-view {
            padding: 10rpx;
        };
        .goods-info-view {
            padding: 15rpx;
            padding-right: 20rpx;
            .point-number {
                color: #f42424;
                font-weight: 500;
            }
            .goods-tag {
                padding: 2rpx 4rpx;
                color: #f42424;
                border:2rpx solid #f42424;
                border-radius: 8rpx;
                margin-right: 10rpx;
                display: inline-block;
                font-size: 22rpx;
            }
            .goods-title {
                min-height: 60rpx;
            }
            .goods-spec-view {
                margin: 15rpx 0;
                height: 28rpx;
                .goods-spec {
                    color: #909399;
                    background-color: #f3f4f6;
                    padding: 0 5rpx;
                    font-size: 24rpx;
                }
            }
            .promotion-view {
                margin-top: 20rpx;
            }
            .act-view {
                margin: 10rpx 0;
                padding: 10rpx;
                color: #909399;
                background-color: #FDF3F3;
                .act-item-cont {
                    margin-left: 20rpx;
                    font-size: 22rpx;
                }
            }
        }
    }
}
</style>