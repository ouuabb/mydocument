<template>
  <web-view v-if="url" :src="url"/>
  <view v-else>没有要加载的URL</view>
</template>

<script>
export default {
  name: 'webview',
  data() {
    return {
      url: ''
    }
  },
  onLoad(params) {
    this.url = decodeURIComponent(params.url)
  }
}
</script>

<style lang="scss" scoped>

</style>
