<template>
    <view class="bind-mobile-container">
        <u-gap height="40" bg-color="#FFFFFF" v-show="step === 1"></u-gap>
        <view class="bind-mobile" >
            <u-form :model="bindMobileForm" ref="bindMobileForm">
                <u-form-item label-position="top">
                    <view class="u-flex">
                        <area-select
                        ref="areaSelect" />
                        <u-input
                            v-model="bindMobileForm.mobile"
                            placeholder="请输入新的手机号"
                            maxlength="11"
                            clearable />
                    </view>
                </u-form-item>
                <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
                    <u-input v-model="bindMobileForm.img_code" placeholder="请输入图片验证码" maxlength="4" clearable />
                    <u-image slot="right" width="150" height="70" :src="valid_img_url" @click="getValidImgUrl"></u-image>
                </u-form-item>
                <u-form-item label-position="top">
                    <u-input v-model="bindMobileForm.sms_code" placeholder="请输入短信验证码" maxlength="6" clearable />
                    <u-button slot="right" type="error" size="mini" @click="getCode">{{ bindMobileCodeTips }}</u-button>
                    <u-verification-code seconds="60" ref="uCode" @change="bindMobileCode"></u-verification-code>
                </u-form-item>
            </u-form>
            <u-button :disabled="val_disabled_bind" class="u-m-20" type="error" shape="circle" @click="submitBindForm">保存</u-button>
        </view>
        <view class="bind-success u-flex" v-show="step === 2">
            <image class="icon-success" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-success.png"></image>
            <view class="success-title">
                您的手机号已成功绑定为：
                <view>
                    {{ bindMobileForm.mobile }}
                </view>
            </view>
        </view>
        <!-- 腾讯天御验证码-小程序 -->
        <!-- #ifdef MP-WEIXIN -->
        <t-captcha
            id="captcha"
            :app-id="validator.tencent.mini_captcha_app_id"
            @verify="handlerVerify"
            @ready="handlerReady"
            @close="handlerClose"
            @error="handlerError" />
        <!-- #endif -->
    </view>
</template>

<script>
    import * as API_Common from '@/api/common.js'
    import * as API_Safe from '@/api/safe.js'
    import Cache, {
        Keys
    } from '@/utils/cache.js';
    import areaSelect from '@/components/areaSelect/areaSelect'

    export default {
        components: {
            areaSelect
        },
        data() {
            return {
                uuid: Cache.getItem('uuid'),
                bindMobileCodeTipsText: '',
                valid_img_url: '',
                step: 1,
                bindMobileForm: {
                    mobile: '',
                    img_code: '',
                    sms_code: ''
                },
                // 验证类型
                validator: {}
            };
        },
        onLoad() {
            this.$nextTick(this.getValidImgUrl)
            this.getValidator()
        },
        computed: {
            /** 保存 按钮是否禁用 */
            val_disabled_bind() {
                const {
                    mobile,
                    img_code,
                    sms_code
                } = this.bindMobileForm
                return !(mobile && img_code && sms_code)
            },
            bindMobileCodeTips: {
                get() {
                    return this.bindMobileCodeTipsText || '获取验证码'
                },
                set(val) {
                    this.bindMobileCodeTipsText = val
                }
            }
        },
        methods: {
            /** 获取验证码方式 */
            getValidator(){
                API_Common.getValidator().then(res => {
                    this.validator = res
                })
            },
            /** 获取图片验证码URL */
            getValidImgUrl() {
                this.valid_img_url = API_Common.getValidateCodeUrl(this.uuid, 'BIND_MOBILE')
            },
            /** 绑定手机号 发送验证码 */
            getCode() {
                const validator_type = this.validator.validator_type
                if (this.$refs.uCode.canGetCode) {
                    //如果是图片验证码
                    if (validator_type === 'IMAGE') {
                        this.sendBindMobileSms()
                    } else if(validator_type === 'TENCENT') {
                        //如果是腾讯验证码
                        this.handlerTenCent(this.sendMsgCallback)
                    }

                } else {
                    this.$u.toast('倒计时结束后再发送');
                }
            },
            handlerTenCent(callback){
                // #ifdef H5
                try {
                    const captcha = new TencentCaptcha(this.validator.tencent.captcha_app_id, callback, {})
                    // 调用方法，显示验证码
                    captcha.show()
                } catch (error) {
                // 加载异常，调用验证码js加载错误处理函数
                this.loadErrorCallback()
                }
                // #endif

                // #ifdef MP-WEIXIN
                this.selectComponent('#captcha').show()
                // #endif
            },
            /** 图片滑动验证回调 */
            sendMsgCallback(res) {
                if (res.ret === 0) {
                    this.bindMobileForm.randstr = res.randstr
                    this.bindMobileForm.ticket = res.ticket
                    this.sendBindMobileSms()
                }
            },
            sendBindMobileSms() {
                const { uuid } = this
                const {
                    mobile,
                    img_code,
                    randstr,
                    ticket
                } = this.bindMobileForm
                const { mobile_regex, formatValid } = this.$refs.areaSelect
                const validator_type = this.validator.validator_type
                const mobileReg = new RegExp(mobile_regex)
                const params = {
                    scene: 'BIND_MOBILE',
                    uuid,
                }
                if (!mobileReg.test(formatValid(mobile))) {
                    this.$u.toast('请输入正确格式的手机号码！')
                    return
                }
                if (validator_type === 'IMAGE' && !img_code) {
                    this.$u.toast('请填写图片验证码')
                    return
                }
                if (validator_type === 'IMAGE') {
                    params.captcha = img_code
                } else if (validator_type === 'TENCENT') {
                    params.randstr = randstr
                    params.ticket = ticket
                }
                API_Safe.sendBindMobileSms(mobile, params).then(res => {
                    this.$u.toast('验证码已发送')
                    /** 通知验证码组件内部开始倒计时 */
                    this.$refs.uCode.start()
                });
            },
            bindMobileCode(text) {
                this.bindMobileCodeTips = text
            },
            /** 绑定手机号 */
            submitBindForm() {
                let {
                    mobile,
                    sms_code
                } = this.bindMobileForm
                const { mobile_regex, formatValid, mobileValue } = this.$refs.areaSelect
                const mobileReg = new RegExp(mobile_regex)
                if (!mobileReg.test(formatValid(mobile))) {
                    this.$u.toast('请输入正确格式的手机号码！')
                    return
                }
                mobile = mobileValue(mobile)
                API_Safe.bindMobile(mobile, sms_code).then(() => {
                    this.$u.toast('保存成功')
                    this.step = 2
                    this.bindMobileForm.mobile = mobile
                    const user = Cache.getItem(Keys.user);
                    user.mobile = mobile
                    Cache.setItem(Keys.user, user)
                    uni.switchTab({
                        url: '/pages/tabs/mine/mine'
                    })
                })
            }
        }
    }
</script>

<style lang="scss" scoped>
    .bind-mobile-container {
        .bind-mobile {
            background-color: #FFFFFF;
            margin: 30rpx;
            border-radius: 20rpx;
            padding: 20rpx 40rpx;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);

            ::v-deep.u-label {
                flex: 0 0 180rpx !important;
            }
        }

        .bind-success {
            padding-top: 100rpx;
            width: 100%;
            justify-content: center;

            .icon-success {
                width: 100rpx;
                height: 100rpx;
                margin-right: 30rpx;
            }

            .success-title {
                font-size: 32rpx;
                color: #333;
            }
        }
    }
</style>
