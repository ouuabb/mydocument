<template>
	<u-popup width="80%" v-model="showCouponPop" mode="center">
		<view>
			<view class="popup-wrap" v-if="couponList && couponList.length">
				<view class="title">恭喜您获得</view>
				<view class="sub-title">{{ couponList.length }}张优惠券</view>
				<view class="coupon-content">
					<view class="coupon-item" v-for="(coupon, index) in couponList" :key="index">
						<view class="coupon-left">
							<!-- <view class="price">
								<text class="unit">{{ MixinUnitOfCurrency }}</text>
								{{ coupon.coupon_price }}
							</view> -->
							<view class="price">
								<custom-price :price="coupon.coupon_price" :size="40" fontWeight="700" textColor="#338d44"></custom-price>
							</view>

							<view class="tips">
								满<custom-price :price="coupon.coupon_threshold_price" :size="22" textColor="#338d44"></custom-price><!--{{ coupon.coupon_threshold_price }}-->使用
							</view>
						</view>
						<view class="coupon-right">
							<view class="name">{{ coupon.title }}</view>
							<view class="date">有效期至{{ coupon.end_time | unixToDate }}</view>
						</view>
					</view>
				</view>
			</view>
			<view class="btn-box">
				<view class="btn-icon" @click="handleClose">
					<u-icon name="close" size="35" color="#fff"></u-icon>
				</view>
			</view>
		</view>
	</u-popup>
</template>

<script>

import * as API_Promotions from '@/api/promotions.js'
import Cache, { Keys } from '@/utils/cache.js'

export default {
	name: 'CouponReceive',
	options: {
		styleIsolation: 'shared', // 解除样式隔离
	},
	data() {
		return {
			// 优惠券弹窗显隐
			showCouponPop: false,
			couponList: []
		}
	},
	created() {
		this.getNewcomerCoupon()
	},
	methods: {
		/** 获取新人优惠券 */
		getNewcomerCoupon() {
			API_Promotions.getNewcomerCoupon().then(res => {
				if (res.newcomer_is_open) {
					this.couponList = res.newcomer_coupon_list
					this.showCouponPop = true
				}
			})
		},
		/** 关闭弹窗 */
		handleClose() {
			this.showCouponPop = false
			Cache.setItem(Keys.newlyRegisteredUser, false)
		}
	}
}
</script>

<style lang="scss" scoped>
::v-deep .u-mode-center-box {
	background-color: rgba(0, 0, 0, 0) !important;
}

.btn-box {
	text-align: center;
	margin-top: 30rpx;

	.btn-icon {
		margin: 0 auto;
		border: 1px solid #fff;
		border-radius: 50%;
		width: 60rpx;
		height: 60rpx;
    display: flex;
    justify-content: center;
    align-items: center;
	}
}

.popup-wrap {
	width: 100%;
	height: 100%;
	background-image: url(https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/bg/bg5.png);
	background-size: 100% 100%;
	position: relative;
	padding: 20rpx;

	.title {
		text-align: center;
		font-size: 36rpx;
		color: #fff;
		padding: 20rpx 0;
	}

	.sub-title {
		text-align: center;
		color: #fff;
		font-size: 22rpx;
	}

	.coupon-content {
        min-height: 200rpx;
		max-height: 800rpx;
		overflow: auto;

		.coupon-item {
			background: #fff;
			height: 140rpx;
			border-radius: 4rpx;
			text-align: center;
			margin: 10rpx 0;
			display: flex;
			align-items: center;

			.coupon-right {
				text-align: left;
				padding-left: 20rpx;
				box-sizing: border-box;

				.name {
					color: #333;
					font-size: 26rpx;
					font-weight: 600;
					margin-bottom: 30rpx;
				}

				.date {
					font-size: 22rpx;
					color: #999;
				}
			}

			.coupon-left {
				color: #338d44;
				background: rgba(235, 246, 237, 1);
				width: 30%;
				height: 100%;
				display: flex;
				flex-direction: column;
				justify-content: center;

				.tips {
					display: flex;
					font-size: 22rpx;
				}

				.price {
					font-size: 60rpx;
					line-height: 60rpx;
					font-weight: 700;

					.unit {
						font-size: 30rpx;
					}
				}
			}
		}
	}
}</style>
