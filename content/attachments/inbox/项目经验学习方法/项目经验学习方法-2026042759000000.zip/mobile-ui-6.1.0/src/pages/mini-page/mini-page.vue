<template>
    <decor-modules v-if="page_id" :page-id="page_id" />
</template>

<script>
import decorModules from '../../components/decor-modules/decor-modules'

export default {
  name: 'mini-page',
  components: { decorModules },
  data() {
    return {
      page_id: ''
    }
  },
  onLoad(params) {
    this.page_id = params.id
  },
  onPageScroll(event) {
    uni.$emit('mini-page-scroll', event.scrollTop)
  }
}
</script>

<style lang="scss" scoped>

</style>
