<template>
    <view class="success-container">
        <image class="img" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-apply-shop-success.png" mode="widthFix"></image>
        <view class="tip">申请开店成功，等待审核......</view>
        <view class="back-index" @click="handleHome">返回首页</view>
    </view>
</template>

<script>
    export default {
        data() {
            return {

            };
        },
        methods: {
            handleHome() {
                uni.switchTab({
                    url: '/pages/tabs/home/home'
                })
            }
        }
    }
</script>

<style lang="scss">
    .success-container {
        text-align: center;
        background-color: #FFFFFF;
        height: 100%;

        .img {
            margin: auto;
        }

        .tip {
            display: block;
            color: #c94136;
            font-size: 52rpx;
            font-family: '微软雅黑';
            margin-top: 100rpx;
        }

        .back-index {
            display: block;
            width: 300rpx;
            height: 100rpx;
            line-height: 100rpx;
            text-align: center;
            color: #fff;
            font-size: 44rpx;
            background-color: #c94136;
            border-radius: 10rpx;
            margin: 100rpx auto;
            font-family: '微软雅黑';
        }
    }
</style>
