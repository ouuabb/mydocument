<template>
  <view class="container">
    <u-steps class="u-p-t-20" :list="numList" mode="number" :current="4" active-color="#FA3534"></u-steps>
    <view class="item-container">
      <view class="title">店铺信息</view>
      <view class="content">
        <u-form :model="shopInfoForm" ref="shopInfoForm" label-width="210" :error-type="errorType">
          <u-form-item label="店铺名称：" prop="shop_name" required>
            <u-input v-model="shopInfoForm.shop_name" placeholder="请输入店铺名称" :maxlength="200" clearable>
            </u-input>
          </u-form-item>
          <addressFiled
            :defaultForm="shopInfoForm"
            label="店铺所在地"
            prefix="shop_"
            @handlerRegionJson="handlerRegionJson"
          />
          <u-form-item label="店铺详细地址：" prop="shop_add" required>
            <u-input v-model="shopInfoForm.shop_add" placeholder="请输入店铺详细地址" :maxlength="200" clearable>
            </u-input>
          </u-form-item>
          <u-form-item label="经营类目：" prop="shop_img" label-position="top" required>
            <view class="">
              <u-checkbox v-model="checkAll" :icon-size="20" @change="handleCheckAllChanged" active-color="#FA3534">
                全选
              </u-checkbox>
              <u-checkbox-group @change="handleCheckedCategorysChange">
                <u-checkbox v-for="cate in categorys" v-model="cate.checked" :name="cate.id" :key="cate.id"
                  :icon-size="20" active-color="#FA3534">
                  {{ cate.name }}
                </u-checkbox>
              </u-checkbox-group>
            </view>
          </u-form-item>
          
        </u-form>
      </view>
    </view>
    <view class="next-btns u-text-center u-p-b-20">
      <u-button class="u-m-r-40" size="mini" @click="handleBackStep">上一步</u-button>
      <u-button size="mini" @click="handleNextStep">提交申请</u-button>
    </view>
  </view>
</template>

<script>
import * as API_Shop from '@/api/shop'
import * as API_Goods from '@/api/goods'
import { i18n as openI18n } from '@/config/config'
import addressFiled from '@/components/addressFiled/addressFiled'
import { api } from '@/config/config'
import Cache, { Keys } from '@/utils/cache'

export default {
  components: {
    addressFiled
  },
  data() {
    const req_rule = (message, trigger) => ({
      required: true,
      message,
      trigger: [trigger || 'blur']
    })
    const len_rule = (min, max) => ({
      min,
      max,
      message: `'长度在 ${min} 到 ${max} 个字符`
    })
    return {
      openI18n,
      numList: [
        { name: '入驻协议' },
        { name: '基本信息' },
        { name: '认证信息' },
        { name: '资质信息' },
        { name: '店铺信息' }
      ],
      shopInfoForm: {
        shop_name: '',
        shop_region: '',
        shop_address: '',
        shop_add: '',
        goods_management_category: [],
        
      },
      rules: {
        shop_name: [req_rule('请输入店铺名称！')],
        shop_region: [{
          validator: (rule, value, callback) => {
            if (!value) {
              callback(new Error('请选择店铺所在地！'))
            } else {
              callback()
            }
          },
          trigger: 'blur'
        }],
        shop_add: [req_rule('请输入店铺详细地址！')],
        goods_management_category: [req_rule('请选择经营类目！')],
        
      },
      errorType: ['toast'],
      action: `${api.buyer}/buyer/uploaders`,
      header: this.MixinUploadHeader(),
      checkAll: false, // 全选
      categorys: [], //分类
      regionJSon: ''
    }
  },
  onLoad() {
    Promise.all([
      API_Shop.getApplyShopInfo(),
      API_Goods.getCategory()
    ]).then(responses => {
      const shopInfo = responses[0]
      const categories = responses[1] || []
      shopInfo.goods_management_category = (shopInfo.goods_management_category || '').split(',')
      const selectedLen = shopInfo.goods_management_category.length
      if (selectedLen && selectedLen === categories.length) {
        this.checkAll = true
      }
      this.shopInfoForm = shopInfo
      // 设置分类信息
      this.categorys = categories.map(item => ({
        id: String(item.category_id),
        name: item.name,
        checked: !!shopInfo.goods_management_category.find(cateId => cateId === String(item.category_id))
      }))
    })
  },
  onReady() {
    this.$refs.shopInfoForm.setRules(this.rules)
  },
  methods: {
    // 经营类目全选框发生改变
    handleCheckAllChanged(checked) {
      this.shopInfoForm.goods_management_category = checked.value ? this.categorys.map(item => item.id) : []
      this.categorys.forEach(item => {
        if (checked.value) {
          item.checked = true
        } else {
          item.checked = false
        }
      })
    },
    // 选中的经营类目发生改变
    handleCheckedCategorysChange(value) {
      const checkedCount = value.length
      const categorysCount = this.categorys.length
      this.checkAll = checkedCount === categorysCount
      this.shopInfoForm.goods_management_category = value
    },
    // 上一步
    handleBackStep() {
      uni.navigateBack()
    },
    // 下一步
    handleNextStep() {
      const params = JSON.parse(JSON.stringify(this.shopInfoForm))
      if (!params.goods_management_category.length) {
        return this.$u.toast('请至少选择一个经营类目')
      }
      
      params.shop_region = this.regionJSon
      params.goods_management_category = params.goods_management_category.join(',')
      this.$refs.shopInfoForm.validate(valid => {
        if (valid) {
          API_Shop.applyShopStep(4, params).then(response => {
            this.$u.route('/pages/shop/apply/success')
          })
        }
      })
    },
    handlerRegionJson(obj) {
      this.regionJSon = obj
    }
  }
}
</script>

<style lang="scss">
::v-deep {
  .u-field {
    padding: 20rpx 0 !important;
  }
}
.container {
  min-height: 100%;
  background-color: #FFFFFF;

  .item-container {
    border-top: 1px dashed #E1E1E1;
    margin: 20rpx 0;

    .title {
      margin: 20rpx 0;
      font-size: 40rpx;
      font-weight: 600;
      text-align: center;
    }

    .content {
      padding: 0 30rpx;
    }

    .licence-range {
      margin-left: 260rpx;
    }
  }
}
</style>
