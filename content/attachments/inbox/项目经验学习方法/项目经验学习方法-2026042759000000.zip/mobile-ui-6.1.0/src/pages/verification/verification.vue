<template>
  <view class="verification-wrap">
    <template v-if="isSuccess">
      <view class="success-box">
        <view class="tips">
          <u-icon class="icon" name="checkmark-circle-fill" color="#19be6b" />
          核销成功
        </view>
        <!-- #ifdef H5 -->
        <view class="scan-code-h5">继续核销请使用微信扫码</view>
        <!-- #endif -->
        <!-- #ifndef H5 -->
        <view class="scan-code" @click="handleScanCode">继续扫码核销</view>
        <!-- #endif -->

      </view>
    </template>
    <template v-else>
      <view class="title">请输入核销密码：</view>
      <div class="input-box">
        <u-message-input :maxlength="6" :dot-fill="true" inputType="text"
          @finish="virtualGoodsVerification"></u-message-input>
      </div>
    </template>
  </view>
</template>

<script>
import * as API_Order from '@/api/order.js'
import md5Libs from '@/uview-ui/libs/function/md5.js'
import { Foundation } from '@/app-utils/index.js'

export default {
  data() {
    return {
      isSuccess: false,
      seller_id: '', // 店铺ID
      redeem_code: '' // 兑换code
    }
  },
  onLoad(options) {
    this.seller_id = options.seller_id || ''
    this.redeem_code = options.redeem_code || ''
  },
  methods: {
    /** 扫码 */
    handleScanCode() {
      uni.scanCode({
        success: (res) => {
          console.log('扫码内容：' + res.result)
          const codeData = Foundation.queryURLparamsReg(res.result)
          if (codeData) {
            this.seller_id = codeData.seller_id || ''
            this.redeem_code = codeData.redeem_code || ''
            this.isSuccess = false
          }
        }
      })
    },
    /** 商品核销 */
    virtualGoodsVerification(password) {
      const redeem_password = md5Libs.md5(password)
      API_Order.virtualGoodsVerification({
        redeem_password,
        redeem_code: this.redeem_code,
        seller_id: this.seller_id
      }).then(res => {
        this.$u.toast('核销成功！')
        this.isSuccess = true
      })
    }

  }
}
</script>

<style lang="scss" scoped>
.verification-wrap {
  background: #fff;
  height: 100%;
  padding: 40px 20px;
  .success-box {
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 60%;
    .scan-code {
      margin-top: 50rpx;
      text-decoration: underline;
    }
    .scan-code-h5 {
      margin-top: 50rpx;
    }
    .icon {
      margin-right: 20rpx;
    }
    .tips {
      font-size: 48rpx;
      color: #19be6b;
    }
  }

  .title {
    font-size: 20px;
    text-align: center;
  }

  .input-box {
    display: flex;
    width: 100%;
    align-items: center;
    justify-content: center;
    margin-top: 50%;
  }

  .input-item {
    text-align: center;
    width: 30px;
    height: 30px;
    margin-right: 10px;
    font-size: 14px;
    color: #333333;
    text-align: center;
    outline: none;
    border: solid 1px #DCDFE6;
  }
}
</style>

