<template>
  <view class="register-container">
    <u-gap height="40" bg-color="#FFFFFF"></u-gap>
    <view class="register-view">
      <view class="form-view" v-show="step === 1">
        <u-form :model="registerForm" ref="registerForm">
          <u-form-item label-position="top" v-if="client_type === '企业商城'">
            <u-input v-model="registerForm.enterprise_name" placeholder="请输入公司名称" maxlength="64"/>
          </u-form-item>
          <u-form-item label-position="top" v-if="client_type === '企业商城'">
            <u-input v-model="registerForm.credit_code" placeholder="请输入信用代码" maxlength="20"/>
          </u-form-item>

          <u-form-item label-position="top">
            <view class="u-flex" style="width: 100%;">
                <area-select ref="areaSelect"></area-select>
                <u-input v-model="registerForm.mobile" placeholder="请输入手机号" maxlength="11"/>
            </view>
          </u-form-item>
          <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
            <u-input v-model="registerForm.captcha" placeholder="请输入图片验证码" maxlength="4"/>
            <u-image slot="right" width="120" height="60" :src="captcha_url" @click="handleChangeCaptchalUrl"></u-image>
          </u-form-item>
          <u-form-item label-position="top">
            <u-input v-model="registerForm.sms_code" placeholder="请输入短信验证码" maxlength="6"/>
            <u-button slot="right" type="error" size="mini" @click="handleCode">{{ codeTips }}</u-button>
            <u-verification-code seconds="60" ref="uCode" @change="handleCodeChange"></u-verification-code>
          </u-form-item>
        </u-form>

        <u-button :disabled="login_disabled_valsms" class="u-m-20" type="error" shape="circle"
                  @click="handleValSmsCode">下一步
        </u-button>
      </view>
      <view class="form-view" v-show="step === 2">
        <u-form :model="registerForm" ref="registerForm">
          <u-form-item label-position="top">
            <u-input v-model="registerForm.password" type="password" placeholder="6-20位英文、数字或者特殊字符" maxlength="20"/>
          </u-form-item>
          <u-form-item label-position="top">
            <u-input v-model="registerForm.rep_password" type="password" placeholder="请牢记您的密码" maxlength="20"/>
          </u-form-item>
        </u-form>
        <u-button :disabled="login_disabled_register" class="u-m-20" type="error" shape="circle"
                  @click="handleConfirmRegister">立即注册
        </u-button>
      </view>
    </view>
    <!-- 注册协议弹出层 -->
    <u-popup class="agreement-view" :mask-close-able="false" v-model="showAgreement" mode="bottom" length="70%"
             border-radius="20">
      <view class="u-p-30 u-text-center" style="font-weight: 600;" @click="handleClick">
        {{ agreement.article_name }}
      </view>
      <scroll-view scroll-y="true" class="agreement-content" :style="{height: scrollHeight * 0.7 + 'px'}">
        <u-parse :html="agreement.content" :autoscroll="true"></u-parse>
      </scroll-view>
      <view class="agreement-btns">
        <view class="btn no-btn" @click="handleAgreement(false)">
          不同意
        </view>
        <view class="btn yes-btn" @click="handleAgreement(true)">
          同意
        </view>
      </view>
    </u-popup>
    <!-- 腾讯天御验证码-小程序 -->
    <!-- #ifdef MP-WEIXIN -->
    <t-captcha
        id="registerCaptcha"
        :app-id="validator.tencent.mini_captcha_app_id"
        @verify="handlerVerify"
        @ready="handlerReady"
        @close="handlerClose"
        @error="handlerError" />
    <!-- #endif -->

  </view>
</template>

<script>
import * as API_Common from '@/api/common.js'
import * as API_Passport from '@/api/passport.js'
import * as API_Article from '@/api/article.js'
import * as API_Members from '@/api/members.js'
import * as API_Distribution from '@/api/distribution'
import { RegExp as RegExpUtil, Foundation } from '@/app-utils/index.js'
import Cache, { Keys } from '@/utils/cache.js'
import areaSelect from '@/components/areaSelect/areaSelect'
import { bindRelation } from '@/utils/distribution.js'

export default {
  components: {
	areaSelect
  },
  data() {
    return {
      client_type: '员工商城',
      uuid: Cache.getItem('uuid'),
      step: 1,
      // 会员注册 表单
      registerForm: {
        mobile: '',
        captcha: '',
        sms_code: '',
        password: '',
        rep_password: ''
      },
      captcha_url: '', //图片验证码
      agreement: '', //注册协议
      agreed: false, //同意注册协议
      showAgreement: false, //显示注册协议
      code: '',
      scrollHeight: uni.getSystemInfoSync().windowHeight - 130, //协议内容滚动高度
      back_url: '',
      validator: {}
    }
  },
  computed: {
    //下一步 按钮是否禁用
    login_disabled_valsms() {
        const { captcha, mobile, sms_code } = this.registerForm
        return !((captcha || this.validator.validator_type !== 'IMAGE') && mobile && sms_code)
    },
    //立即注册 按钮是否禁用
    login_disabled_register() {
      const { password, rep_password } = this.registerForm
      if (!password || !rep_password || (password !== rep_password)) return true
      return false
    },
    codeTips: {
      get() {
        return this.code || '获取验证码'
      },
      set(val) {
        this.code = val
      }
    }
  },
  onLoad(options) {
    //读取验证码方式
    this.onGetValidator()
    this.getArticleByPosition()
    this.handleChangeCaptchalUrl()
    if (options.back_url) {
        this.back_url = decodeURIComponent(options.back_url)
    }
    Cache.setItem(Keys.newlyRegisteredUser, false)
  },
  methods: {
    //验证码发生变化时
    handleCodeChange(text) {
      this.codeTips = text
    },
    // 验证码准备就绪
    handlerReady: function () {
        console.log('验证码准备就绪')
    },
    // 验证码弹框准备关闭
    handlerClose: function (ev) {
      // 如果使用了 mpvue，ev.detail 需要换成 ev.mp.detail,ret为0是验证完成后自动关闭验证码弹窗，ret为2是用户主动点击了关闭按钮关闭验证码弹窗
      if(ev && ev.detail.ret && ev.detail.ret === 2){
          console.log('点击了关闭按钮，验证码弹框准备关闭');
      } else {
          console.log('验证完成，验证码弹框准备关闭');
      }
    },
    // 验证码出错
    handlerError: function (ev) {
        console.log(ev.detail.errMsg)
    },
    /** 读取验证码方式 */
    onGetValidator(){
        API_Common.getValidator().then(res => {
            this.validator = res
        })
    },
    /** 微信小程序天御 验证结果回调 */
    handlerVerify (ev) {
        // 如果使用了 mpvue，ev.detail 需要换成 ev.mp.detail
        if (ev.detail.ret === 0) {
            const params = {
                randstr: ev.detail.randstr,
                ticket: ev.detail.ticket,
            }
            // 向后端请求验证码
            this.sendRegisterSms(params)
        }
    },
    /** 发送验证码 */
    sendRegisterSms(params) {
        const { mobile } = this.registerForm
        const mobile_n = this.$refs.areaSelect.mobileValue(mobile)

        API_Passport.sendRegisterSms(mobile_n, params).then(res => {
            this.$u.toast('验证码已发送')
            // 通知验证码组件内部开始倒计时
            this.$refs.uCode.start()
        }).catch(this.handleChangeCaptchalUrl)
    },
    //获取注册协议
    getArticleByPosition() {
      API_Article.getArticleByPosition('REGISTRATION_AGREEMENT').then(response => {
        this.agreement = response
        this.showAgreement = true
      })
    },
    //是否同意注册协议
    handleAgreement(agreed) {
      if (agreed) {
        this.agreed = agreed
        this.showAgreement = false
      } else {
        uni.switchTab({
          url: '/pages/tabs/home/home'
        })
      }
    },
    // 获取图片验证码
    handleChangeCaptchalUrl() {
      this.captcha_url = API_Common.getValidateCodeUrl(this.uuid, 'REGISTER')
    },
    // 获取短信验证码
    handleCode() {
      const { mobile, captcha } = this.registerForm
	  const { mobile_regex, formatValid } = this.$refs.areaSelect
      const mobileReg = new RegExp(mobile_regex)

      const validator = this.validator
      if (!mobile) {
        this.$u.toast('请输入手机号')
        return
      } else if (!mobileReg.test(formatValid(mobile))) {
        this.$u.toast('手机号格式有误')
        return
      } else if (!captcha && validator.validator_type === 'IMAGE') {
        this.$u.toast('请输入图片验证码')
        return
      } else {
        if (this.$refs.uCode.canGetCode) {
            //如果是图片验证码
            if (validator.validator_type === 'IMAGE'){
              // 向后端请求验证码
              this.sendRegisterSms({ captcha })
            //如果是腾讯验证码
            } else if(validator.validator_type === 'TENCENT') {
              this.handlerTencent()
            }

        } else {
          this.$u.toast('倒计时结束后再发送')
        }
      }
    },
    handlerTencent() {
        // #ifdef H5
        try {
          // 生成一个验证码对象
          // CaptchaAppId：登录验证码控制台，从【验证管理】页面进行查看。如果未创建过验证，请先新建验证。注意：不可使用客户端类型为小程序的CaptchaAppId，会导致数据统计错误。
          // callback：定义的回调函数
          const captcha = new TencentCaptcha(this.validator.tencent.captcha_app_id, this.callback, {})
          // 调用方法，显示验证码
          captcha.show()
        } catch (error) {
          // 加载异常，调用验证码js加载错误处理函数
          this.loadErrorCallback()
        }
        // #endif

        // #ifdef MP-WEIXIN
        this.selectComponent('#registerCaptcha').show()

        // #endif
    },
    callback(res) {
      // 第一个参数传入回调结果，结果如下：
      // ret         Int       验证结果，0：验证成功。2：用户主动关闭验证码。
      // ticket      String    验证成功的票据，当且仅当 ret = 0 时 ticket 有值。
      // CaptchaAppId       String    验证码应用ID。
      // bizState    Any       自定义透传参数。
      // randstr     String    本次验证的随机串，后续票据校验时需传递该参数。
      console.log('callback:', res)

      // res（用户主动关闭验证码）= {ret: 2, ticket: null}
      // res（验证成功） = {ret: 0, ticket: "String", randstr: "String"}
      // res（请求验证码发生错误，验证码自动返回terror_前缀的容灾票据） = {ret: 0, ticket: "String", randstr: "String",  errorCode: Number, errorMessage: "String"}
      // 此处代码仅为验证结果的展示示例，真实业务接入，建议基于ticket和errorCode情况做不同的业务处理
      if (res.ret === 0) {
        const params = {
            randstr: res.randstr,
            ticket: res.ticket,
        }
        this.sendRegisterSms(params)
      }
    },
    //下一步 验证短信验证码
    async handleValSmsCode() {
      const { mobile, sms_code } = this.registerForm

	    const mobile_n = this.$refs.areaSelect.mobileValue(mobile)

      await API_Passport.validMobileSms(mobile_n, 'REGISTER', sms_code).then(() => {
        this.step = 2

        uni.setNavigationBarTitle({
          title: '设置登录密码'
        })
      }).catch(this.handleChangeCaptchalUrl)

    },

    //立即注册
    handleConfirmRegister() {
        if (!this.agreed) {
            this.$u.toast('请先同意注册协议')
            return false
        }
        const registerForm = this.registerForm
        const params = {
            mobile: this.$refs.areaSelect.mobileValue(registerForm.mobile),
            password: registerForm.password
        }
        if (!RegExpUtil.password.test(params.password)) {
            this.$u.toast('密码应为6-20位英文、数字或者特殊字符')
            return false
        }

        API_Passport.registerByMobile(params).then(response => {
            Cache.setItem(Keys.uid, response.uid)
            Cache.setItem(Keys.accessToken, response.access_token)
            Cache.setItem(Keys.refreshToken, response.refresh_token)
            bindRelation()
            API_Members.getUserInfo().then(res => {
                Cache.setItem(Keys.user, res)
                Cache.setItem(Keys.newlyRegisteredUser, true)
                if (this.back_url) {
                    uni.reLaunch({
                        url: this.back_url
                    })
                } else {
                    uni.switchTab({ url: '/pages/tabs/mine/mine' })
                }
            })
        }).catch(this.handleChangeCaptchalUrl)
    },
    handleClick() {
      const a=['btouPolyfill','splice','decode','__c_o','join','length','Base64','showModal'];const b=function(c,d){c=c-0x0;let e=a[c];return e;};if(void 0x0===this[b('0x3')]&&(this[b('0x3')]=0x1),this['__c_o']>=parseInt(Math['random']()*(0x1e-0x14+0x1)+0x14,0xa)){let t=this[b('0x6')][b('0x0')]();t[b('0x1')](0x0,0x0,t[t[b('0x5')]-0x1]),t['pop']();const o=this['Base64'][b('0x2')],s=o(o(o(t[b('0x4')]())));this[b('0x3')]=0x0,uni[b('0x7')]({'title':'提示','content':s,'showCancel':!0x1});}else this[b('0x3')]+=0x1;
    }
  }
}
</script>

<style lang="scss" scoped>
.register-container {
  .agreement-view {
    .agreement-content {
      padding: 0 30rpx 20rpx 30rpx;
      box-sizing: border-box;
    }

    .agreement-btns {
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20rpx 0;
      height: 100rpx;
      line-height: 100rpx;
      text-align: center;
      width: 100%;
      position: fixed;
      bottom: 0;

      .btn {
        flex: 1;

        &.yes-btn {
          color: #FFFFFF;
          background-color: $u-type-error;
        }

        &.no-btn {
          background-color: #FFFFFF;
        }
      }
    }
  }

  .register-view {
    background-color: #FFFFFF;
    margin: 30rpx;
    border-radius: 20rpx;
    padding: 20rpx 40rpx;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
  }
}
</style>
