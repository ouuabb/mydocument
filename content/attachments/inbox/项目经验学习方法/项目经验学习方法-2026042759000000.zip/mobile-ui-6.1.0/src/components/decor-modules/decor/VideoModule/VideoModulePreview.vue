<template>
  <div v-if="notH5Show" class="video-module">
    <video
      controls="controls"
      :src="$$FormData.video ? $$FormData.video.src : 'placeholder'"
      class="video-module__player"
      :poster="videoPoster ? videoPoster.src : ''"
    >
    </video>
  </div>
</template>

<script>
import decorMixin from '../decor-mixin'
export default {
  name: 'VideoModulePreview',
  mixins: [decorMixin],
  computed: {
    notH5Show() {
      //#ifndef H5
      return this.$$FormData.not_h5_show
      //#endif
      return true
    },
    // 视频封面
    videoPoster() {
      const { cover_type, video_cover } = this.$$FormData
      if (cover_type === 'original') {
        return ''
      } else {
        return video_cover
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.video-module {
  width: 100%;
  height: 420rpx;
  &__player {
    width: 100%;
    height: 100%;
  }
}
</style>
