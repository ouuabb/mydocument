<template>
	<view  class="empty-box" :style="{top: `${top}rpx`}">
		<image
			:style="{marginTop: `${marginTop}`}"
			class="empty-image"
			:src="`https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/${imageName}`"
			mode="widthFix"
			lazy-load="false">
		</image>
		<view class="tips">{{tipsText}}</view>
	</view>
</template>

<script>
    /**
     * 空数据提示
     *
     * ===== 使用场景 ======
     * 地址列表、商品列表
     *
     * ===== 参数 =====
     * imageName        图片名称
     * tipsText         提示内容
     */
	export default {
		props:{
			imageName: {
				type: String,
				default: ''
			},
			tipsText: {
				type: String,
				default: ''
			},
			marginTop: {
				type: String,
				default: '40%'
			},
			top: {
				type: String,
				default: '0'
			}
		}
	}
</script>

<style lang="scss" scoped>
.empty-box {
	display: flex;
	align-items: center;
	flex-direction: column;
	background: #F6F9FC;
	position: fixed;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	.empty-image {
		margin-top: 25%;
		width: 300rpx;
	}
	.tips {
		color: #999;
		margin-top: 80rpx;
	}
}
</style>
