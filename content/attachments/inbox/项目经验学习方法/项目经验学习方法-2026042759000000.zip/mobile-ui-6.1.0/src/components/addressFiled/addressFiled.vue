<template>
  <view>
    <u-field
      v-if="!openI18n"
      v-model="addressText"
      :label="_label"
      placeholder="省市区县、乡镇等"
      placeholder-style="color: #CDCDCD"
      disabled
      required right-icon="arrow-right"
      @click="addressPickerShow = true"
      label-position="top"
    />
    <span v-else>
      <!-- 国家 -->
      <u-field
        v-model="regionForm.country_name"
        label="国家/地区"
        placeholder="请选择国家/地区"
        placeholder-style="color: #CDCDCD"
        maxlength="20"
        disabled
        required
        @click="countryPickerShow = true"
        label-position="top"
      />
      <u-picker
        v-if="countryList.length"
        v-model="countryPickerShow"
        mode="selector"
        :range="countryList"
        range-key="name"
        can-search
        @confirm="handleSelectCountry"
      />
      <!-- 中国地区 -->
      <u-field
        v-if="regionForm.country_code === 'CN'"
        v-model="addressText"
        label="所在地区"
        placeholder="省市区县、乡镇等"
        placeholder-style="color: #CDCDCD"
        disabled
        required
        right-icon="arrow-right"
        @click="addressPickerShow = true"
        label-position="top"
      />
      <template v-else>
        <!-- 省份/区域 -->
        <template v-if="regionList.length">
          <u-field
            v-model="regionForm.region_name"
            label="省份/区域"
            required
            placeholder="请选择省份/区域"
            placeholder-style="color: #CDCDCD"
            disabled
            @click="regionPickerShow = true"
            label-position="top"
          />
          <u-picker
            v-model="regionPickerShow"
            mode="selector"
            :range="regionList"
            range-key="name"
            can-search
            @confirm="handleSelectRegion"
          />
        </template>
        <u-field
          v-else
          v-model="regionForm.region_name"
          @input="handleInput"
          label="省份/区域"
          required
          placeholder="请输入省份/区域"
          placeholder-style="color: #CDCDCD"
          label-position="top"
        />
        <!-- 城市 -->
        <template v-if="cityList.length">
          <u-field
            v-model="regionForm.city_name"
            label="城市"
            required
            placeholder="请选择城市"
            placeholder-style="color: #CDCDCD"
            disabled
            @click="cityPickerShow = true"
            label-position="top"
          />
          <u-picker
            v-model="cityPickerShow"
            mode="selector"
            :range="cityList"
            range-key="name"
            can-search
            @confirm="handleSelectCity"
          />
        </template>
        <u-field
          v-else
          v-model="regionForm.city_name"
          label="城市"
          required
          placeholder="请填写城市"
          placeholder-style="color: #CDCDCD"
          @input="handleInput"
          label-position="top"
        />
      </template>
    </span>

    <u-popup v-model="addressPickerShow" mode="bottom" closeable close-icon-size="20" border-radius="20">
      <region-picke
        @addressSelectorChanged="addressSelectorChanged"
        @closeRegionpicke="addressPickerShow = false"
        :show="addressPickerShow"
      />
    </u-popup>
  </view>
</template>

<script>
import * as API_Address from '@/api/address.js'
import { i18n as openI18n } from '@/config/config'

export default {
  props: {
    defaultForm: {
      type: Object,
      default: () => ({})
    },
    // 地区数据前缀，比如shop_city_id，那prefix传shop_
    prefix: {
      type: String,
      default: ''
    },
    label: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      openI18n,
      countryList: [],
      regionList: [],
      cityList: [],
      regionForm: {
        country_code: '',
        country_name: '',
        region_id: '',
        region_name: '',
        city_id: '',
        city_name: ''
      },
      country_loading: false,
      region_loading: false,
      city_loading: false,
      selectedCountry: '',
      selectedRegion: '',
      selectedCity: '',
      addressObject: '',
      regionData: '',
      addressText: '',
      addressPickerShow: false,
      countryPickerShow: false,
      regionPickerShow: false,
      cityPickerShow: false
    }
  },
  mounted() {
    this.regionData = ''
    if (this.openI18n) {
      this.GET_Countries()
    }
  },
  watch: {
    defaultForm: {
      immediate: true,
      deep: true,
      handler: 'setDefaultData'
    }
  },
  computed: {
    _label() {
      return this.label || '地区'
    }
  },
  methods: {
    setDefaultData() {
      if (this.regionData) return
      const regions = this.MixinGetRegionDefaultData(this.defaultForm, this.prefix)
      if (this.openI18n && !Array.isArray(regions)) {
        const { country_code, country_name, region_id, region_name, city_id, city_name } = regions
        this.regionForm.country_code = country_code
        this.regionForm.country_name = country_name
        this.regionForm.region_id = region_id
        this.regionForm.region_name = region_name
        this.regionForm.city_id = city_id
        this.regionForm.city_name = city_name
        if (country_code) this.GET_Regions(country_code)
        if (region_id) this.GET_Cities(region_id)
      } else {
        const last_id = this.MixinLastRegionId(this.defaultForm, this.prefix)
        this.addressObject = { last_id }
        this.regionForm.country_code = 'CN'
        this.regionForm.country_name = '中国'
      }
      this.addressText = this.MixinFormatRegions(this.defaultForm, this.prefix)
      this.emitData()
    },
    /** 查询所有国家 */
    async GET_Countries() {
      this.country_loading = true
      try {
        this.countryList = await API_Address.getCountries()
      } finally {
        this.country_loading = false
      }
    },
    /** 查询国家下的省 */
    async GET_Regions(country_code) {
      this.region_loading = true
      try {
        this.regionList = await API_Address.getRegions(country_code)
      } finally {
        this.region_loading = false
      }
    },
    /** 查询国家下的省下的城市 */
    async GET_Cities(region_id) {
      this.city_loading = true
      try {
        this.cityList = await API_Address.getCities(region_id)
      } finally {
        this.city_loading = false
      }
    },
    handleSelectCountry(value) {
      const country = JSON.parse(JSON.stringify(value))
      const country_code = country.code
      this.regionForm.country_code = country_code
      this.regionForm.country_name = country.name
      this.regionForm.region_id = ''
      this.regionForm.region_name = ''
      this.regionForm.city_id = ''
      this.regionForm.city_name = ''
      this.selectedCountry = country
      this.selectedRegion = ''
      this.selectedCity = ''
      this.regionList = []
      this.cityList = []
      this.$emit('handleCountryChanged', country)
      if (country_code === 'CN') {
        this.initAddressSelect()
      } else {
        this.GET_Regions(country_code)
      }
      this.emitData()
    },
    handleSelectRegion(value) {
      const region = JSON.parse(JSON.stringify(value))
      const region_id = region.id
      this.regionForm.region_id = region.id
      this.regionForm.region_name = region.name
      this.regionForm.city_id = ''
      this.regionForm.city_name = ''
      this.selectedRegion = region
      this.selectedCity = ''
      this.cityList = []
      if (region.has_city === 1) {
        this.GET_Cities(region_id)
      }
      this.emitData()
    },
    handleSelectCity(value) {
      const city = JSON.parse(JSON.stringify(value))
      this.regionForm.city_id = city.id
      this.regionForm.city_name = city.name
      this.selectedCity = city
      this.emitData()
    },
    emitData() {
      if (this.openI18n && this.regionForm.country_code !== 'CN') {
        const data = { region_type: 1 }
        data.country_code = this.selectedCountry.code || this.regionForm.country_code || ''
        data.country_name = this.selectedCountry.name || this.regionForm.country_name || ''
        data.overseas_region = {
          state_id: this.selectedRegion.id || this.regionForm.region_id || '',
          state_name: this.selectedRegion.name || this.regionForm.region_name || '',
          city_id: this.selectedCity.id || this.regionForm.city_id || '',
          city_name: this.selectedCity.name || this.regionForm.city_name || ''
        }
        this.$emit('handlerRegionJson', data)
        this.regionData = data
      } else {
        const { last_id } = this.addressObject
        const data = { region_type: 0 }
        data.country_code = 'CN'
        data.country_name = '中国'
        data.internal_region_id = last_id
        this.$emit('input', last_id)
        this.$emit('handlerRegionJson', data)
        this.regionData = data
      }
    },
    handleInput() {
      this.emitData()
    },
    initAddressSelect() {
      this.addressPickerShow = true
    },
    /** 国内地区选择回调 */
    addressSelectorChanged(object, finished) {
      if (!finished) return
      this.addressObject = { last_id: object[object.length - 1].id }
      this.addressText = object.map(item => item.local_name).join('')
      this.emitData()
    }
  }
}
</script>

<style lang="scss">
</style>
