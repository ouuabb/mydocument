<template>
  <view class="custom-price">
    <div v-if="isNeg" class="neg-symbol">-</div>
    <view
      class="price-box"
      :class="{'line-through': lineThrough}"
      :style="{
        'flex-direction': row ? 'row' : 'column',
        'align-items': row ? 'flex-end' : 'flex-start'
      }"
    >
      <view class="base-price">
        <text class="price-icon" :style="'color: '+textColor+';font-size:'+(size/1.5)+'rpx;font-weight: '+fontWeight+';'">
          {{ MixinUnitOfCurrency }}
        </text>
        <text class="price-text price-text-pos" :style="'color:'+textColor+';font-size:'+size+'rpx;font-weight: '+fontWeight+';'">
          {{ _price | unitPrice('before') }}
        </text>
        <text class="price-text" :style="'color:'+textColor+';font-size:'+(size/1.5)+'rpx;font-weight: '+fontWeight+';'">
          .{{ _price | unitPrice('after') }}
        </text>
      </view>
      <view v-if="showI18nPrice" class="currency-price" :style="{fontSize: i18nPriceSize}">
        <text class="symbol">≈</text>{{ MixinI18nPrice(_price) }}
      </view>
    </view>
  </view>
</template>

<script>

/**
 * 价格展示组件
 *
 * ===== 使用场景 ======
 * 所有展示商品价格的地方
 *
 * ===== 参数 =====
 * price        展示金额
 * textColor    文字展示颜色（默认红色）
 * size         文字的大小(rpx，默认28rpx)
 * fontWeight   文字加粗(必须传数字)
 */
import { Foundation } from '@/app-utils/index.js'
import { i18n } from '@/config/config'

export default {
  props: {
    // 金额数值
    price: {
      type: [Number, String],
      default: 0
    },
    textColor: {
      type: String,
      default: '#fa3534'
    },
    size: {
      type: [Number, String],
      default: 28
    },
    fontWeight: {
      type: [Number, String],
      default: 400
    },
    lineThrough: {
      type: Boolean,
      default: false
    },
    isNeg: {
      type: Boolean,
      default: false
    },
    row: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    _price() {
      return Math.abs(this.price || 0)
    },
    showI18nPrice() {
      if (!i18n) return false
      const { baseCurrency, currentCurrency } = this.$store.state
      if (!currentCurrency) return false
      return baseCurrency.currency_code !== currentCurrency.currency_code
    },
    i18nPriceSize() {
      return Number(this.size) * 0.7 + 'rpx'
    }
  },
  filters: {
    unitPrice(val, location) {
      let price = Foundation.formatPrice(val)
      if (!price) return
      if (location === 'before') {
        return price.substr(0, price.length - 3)
      }
      if (location === 'after') {
        return price.substr(-2)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .custom-price {
    display: flex;
    align-items: center;
  }
.base-price {
  line-height: 1;
}
.currency-price {
  line-height: 1;
}

.price-box {
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: flex-start;
  flex-wrap: wrap;
  &.line-through {
    .price-text {
      text-decoration: line-through;
    }
  }
}
</style>
