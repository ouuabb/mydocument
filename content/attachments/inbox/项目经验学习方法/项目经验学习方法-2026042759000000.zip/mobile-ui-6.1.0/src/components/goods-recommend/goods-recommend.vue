<template>
  <view class="goods-container">
    <u-divider style="font-weight: 600;" height="80" bg-color="#f3f4f6" color="#000" fontSize="36">{{ title }}
    </u-divider>
    <view class="goods-list-view u-m-l-20 u-m-t-10 u-m-r-20 clearfix">
      <view v-for="(item, index) in goodsList" :key="index"
            :class="[(index + 1) % 2 == 0 ? 'list-b' : '', 'goods-list']">
        <view class="goods-view">
          <navigator :url="'/goods-module/goods?goods_id=' + item.goods_id" hover-class="none">
            <view class="goods-img">
              <u-image width="340" height="340" :src="item.thumbnail" :border-radius="10"></u-image>
            </view>
            <view class="goods-info">
              <view class="goods-title-view u-line-2">
                {{ item.name }}
              </view>
            </view>
            <!-- #ifdef MP -->
            <view class="goods-price-view" style="color: #ff0000; font-weight: 600;">
              <!-- <text class="u-font-12">{{MixinUnitOfCurrency}}</text> -->
              <!-- <text class="u-font-18">{{ item.price }}</text> -->
				<custom-price :price="item.price" :size="34" :fontWeight="600"></custom-price>
			</view>
            <!-- #endif -->
            <!-- #ifdef APP-PLUS || H5 -->
            <custom-price :price="item.price" :size="34" :fontWeight="600"></custom-price>
            <!-- #endif -->
          </navigator>
        </view>
      </view>
      <u-empty text="数据为空" mode="list" v-if="goodsList.length == 0"></u-empty>
    </view>
  </view>
</template>

<script>
/**
 * 为你推荐展示组件
 *
 * ===== 使用场景 ======
 * 所有展示为你推荐商品的地方
 *
 * ===== 参数 =====
 * title        标题
 */
import * as API_Goods from '@/api/goods.js'
import { Foundation } from '@/app-utils/index.js'

export default {
  data() {
    return {
      params: {
        page_no: 1,
        page_size: 10,
        recommend: 1
      },
      goodsList: [],
      //如果没有可读取的数据，则不在调用API。 true：可读
      isLoad: true

    }
  },
  props: {
    title: {
      type: String,
      default: ''
    }
  },
  created() {
    this.getGoodsList()
  },
  methods: {
    // ’为你推荐‘商品列表
    getGoodsList() {
      //如果不可读则直接返回
      if (!this.isLoad) {
        return
      }
      const params = this.params
      API_Goods.getRecommendGoodsList(this.params).then(response => {
        const { goods_data } = response
        if (!goods_data) return
        const data = goods_data.data

        if (data && data.length) {
          // #ifdef MP
          data.forEach(item => {
            item.price = Foundation.formatPrice(item.price)
          })
          // #endif
          this.goodsList.push(...data)
        } else {
          this.isLoad = false
        }
      })
    }
  }
}
</script>

<style lang="scss">
.goods-list-view {
  border-radius: 15rpx 15rpx 0rpx 0rpx;
  padding-bottom: 200rpx;
  &.clearfix::after {
    content: "";
    display: block;
    height: 0;
    clear: both;
    visibility: hidden;
  }
  .goods-list {
    width: 48%;
    float: left;
    background: #ffffff;
    overflow: hidden;
    margin: 10rpx 0;
    border-radius: 20rpx;
    &.list-b {
      margin-left: 24rpx;
    }
  }
}
.goods-view {
  // display: flex;
  // flex-direction: row;
  // padding: 10rpx 20rpx;
  // background-color: #FFFFFF;
  .goods-info {
    margin: 20rpx;
    .goods-price-view {
      margin: 10rpx 0;
    }
    .goods-title-view {
      height: 76rpx;
    }
    .goods-comments {
      font-size: 23rpx;
      color: #82848a;
      margin: 20rpx 0;
      display: flex;
    }
    .u-margin-left-10 {
      font-size: 28rpx;
      color: #000;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }
}
</style>

