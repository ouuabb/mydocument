<template>
  <view>
    <view class="swiper-item-input-i1" @click="showSortDialog = true" v-if="openI18n">
      <!-- <view class="swiper-item-input-i1-img">
      </view> -->
      <image class="icon-img" :src="'data:image/png;base64,' + `${flagBg_n}`" mode="aspectFill"></image>

      <view class="swiper-item-input-i1-img-path"></view>
      <text>+{{ areaCode_n }}</text>
    </view>
    <u-popup v-model="showSortDialog" length="80%" mode="bottom">
      <SortPickerList @clickData="clickData"/>
    </u-popup>
  </view>
</template>

<script>
import * as API_Address from '@/api/address'
import { i18n as openI18n } from '@/config/config'
import { RegExp } from '@/app-utils/index'
import SortPickerList from '@/components/International-sortPickerList/index.vue'

export default {
  components: { SortPickerList },
  props: {
    // 区号
    areaCode: {
      type: [Number, String],
      default: ''
    }
  },
  data() {
    return {
      flagBg_n: openI18n ? 'iVBORw0KGgoAAAANSUhEUgAAAGQAAABDCAMAAABdlVDoAAABR1BMVEXfKRD/ 3gDeKhDeKRDrcAreKxDiPQ7seQnfMA/fMQ/gMg/hOg7hPQ7iPA7eLBDiQA7i QQ7kSg3lTg3lUA3mVwznVwznWgzqagrfKxDfLw/uhAjwiwf1pgX5uwP6xQLf LRD8ygLseAnlUQzlUgzmUwzmVQziPg7mWAziPw7gNA/nWwznXQvoYAvoYQvo YgvpZAvpZQvhPA7qawrqbArrbgriQg7sdAnsdgnjQQ7jQg7kRw3tewntfAnt fgnufgjugQjuggjkSQ3vgwjvhQjvhgjviQjgNQ/wjAfxjgfxkQfylAfymAbz mQbzmwbznAbznwb0oAX0ogX0owXkSw31qAX1qgX2rAT2sAT3rwT3sgT3swT3 tAT4twP4uAPkTA36wwLgNw/7xQL7yAL7ygLtegn8zQL90QH90wH+2AH+2QD+ 2wD/3ADhOA9LVlgpAAAAAXRSTlPUwVjOqwAAAWJJREFUeF7t10VvAzEUBOCO vRBm5hSZmZmZmRn+/7lRmqi7SW95XlWVR7Lk26cnjaznOkvCLchfQbKikayT a1PCJ9k5xCw94jEjowAG4tSIrhoNtgk8Kxoxwu6DRsTX5b6pJ29XAMkKtt1H jizhjlUOVzguRoiwDHDAq9Mzn1VcVIgfwOIvSBBI1T7JeKiYMwD4vjb9lDk+ 8gJs1I44j2FOLmSonLsDSA/WjHB14t1opG65KSde7qFoVyCDct6GWWW1qdrl 2CobcwKf+qESkuACkckSciUSuUQpzVWA306EaMBHIhZ5AvQqZCFKhOTx0Fiw Po9wYRZiygywnlcpkPP95SLG9FenWdHSwKmNYpI2hZW56zA3px+YFr4SJRu8 a0w0YuNcFYnYOkWvRPaVlt1H0QjvBXKtopEIgO0xsUjf3iq6LVi4o2ELEOb4 N/8TiUhEIhKRiEQkIhGJSEQiXCJW5AtwbmROfE5QwQAAAABJRU5ErkJggg==' : '',
      areaCode_n: openI18n ? '86' : '',
      mobile_regex: openI18n ? '^(86){0,1}1\\d{10}$' : RegExp.mobile,
      openI18n: openI18n,
      showSortDialog: false
    }
  },
  watch: {
    areaCode: {
      handler(val) {
        if (val) {
          this.areaCode_n = val
          if (this.openI18n) {
            this.getCountries()
          }
        }
      },
      immediate: true
    }
  },
  methods: {
    /** 国家区号选择回调 */
    clickData(data) {
      this.flagBg_n = data.flag
      this.areaCode_n = data.value
      this.mobile_regex = data.mobile_regex
      this.showSortDialog = false
    },
    /** 获取对应国家国旗 */
    getCountries() {
      API_Address.getCountries().then(res => {
        res.forEach((v, i) => {
          if (v.tel === this.areaCode_n) {
            this.flagBg_n = v.flag
            this.mobile_regex = v.mobile_regex
          }
        })
      })
    },

    /** 手机号格式化 */
    formatValid(val) {
      if (this.openI18n && val.indexOf(',') !== -1) {
        const areaCode_n = val.split(',')[0]
        const mobile = val.split(',')[1]
        return areaCode_n + mobile
      } else {
        return this.areaCode_n + val
      }
    },

    mobileValue(mobile) {
      const { areaCode_n, openI18n } = this
      if (!openI18n) return mobile
      return areaCode_n + ',' + mobile
    }
  }
}
</script>

<style lang="scss">
.swiper-item-input-i1 {
  max-width: 200rpx;
  .swiper-item-input-i1-img-path {
    margin: 0 5rpx 0 4rpx;
    width: 18rpx;
    height: 12rpx;
    background-image: url("https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/icon-path.png");
    background-repeat: no-repeat;
    background-size: cover;
  }
  .icon-img {
      margin: 0 6rpx 0 0;
      width: 48rpx;
      height: 36rpx;
    }
  display: flex;
  align-items: center;
  margin-right: 10rpx;
}
</style>
