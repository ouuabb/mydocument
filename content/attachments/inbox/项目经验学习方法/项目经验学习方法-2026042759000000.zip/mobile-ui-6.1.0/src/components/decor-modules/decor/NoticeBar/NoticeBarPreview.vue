<template>
  <u-notice-bar
    v-if="show_notice"
    :list="[formData.content]"
    :close-icon="formData.closeable"
    :color="formData.content_color"
    padding="20rpx 32rpx"
    @close="show_notice = false"
  />
</template>

<script>
import decorMixin from '../decor-mixin'
export default {
  name: 'NoticeBarPreview',
  mixins: [decorMixin],
  data() {
    return {
      show_notice: true
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
