<template>
  <u-popup
    v-model="showPopup"
    closeable
    mode="bottom"
    border-radius="20"
    safe-area-inset-bottom
    @close="handleDialogClosed"
  >
    <div v-show="loading" class="loading-view">
      <u-loading mode="circle" size="50"/>
    </div>
    <div v-show="!loading" class="payment-form">
      <div id="link-authentication-element">
        <!--Stripe.js injects the Link Authentication Element-->
      </div>
      <div id="payment-element">
        <!--Stripe.js injects the Payment Element-->
      </div>
      <u-button
        v-if="!loading"
        :loading="payLoading"
        :disabled="disablePayBtn"
        @click="handleSubmit"
        class="pay-btn"
      >
        立即支付
      </u-button>
      <div v-if="payMessage" id="payment-message">{{ payMessage }}</div>
    </div>
  </u-popup>
</template>

<script>
import * as API_Common from '@/api/common'

export default {
  props: {
    getDepositBalance: {
      type: Function,
      required: false
    }
  },
  data() {
    return {
      stripeKey: window.stripeKey,
      stripe: null,
      loading: true,
      showPopup: false,
      clientSecret: '',
      elements: null,
      emailAddress: '',
      elementList: [],
      payLoading: false,
      payMessage: '',
      disablePayBtn: true
    }
  },
  mounted() {
    this.checkStripeStatus()
  },
  methods: {
    // 加载Stripe密钥和脚本
    loadStripeScriptAndKey() {
      return new Promise(resolve => {
        API_Common.getStripeKey().then((stripeKey) => {
          this.stripeKey = stripeKey
          window.stripeKey = stripeKey
          if (document.getElementById('stripeScript')) return
          const stripeScriptEle = document.createElement('script')
          stripeScriptEle.src = 'https://js.stripe.com/v3'
          stripeScriptEle.id = 'stripeScript'
          stripeScriptEle.onload = resolve
          document.body.appendChild(stripeScriptEle)
        })
      })
    },
    show(payParams) {
      this.clientSecret = payParams.clientSecret
      this.showPopup = true
      this.$nextTick(() => {
        this.initStripe()
      })
    },
    async initStripe() {
      let stripe = this.stripe
      if (!stripe) {
        if (!window.Stripe) {
          await this.loadStripeScriptAndKey()
        }
        stripe = window.Stripe(this.stripeKey)
        this.stripe = stripe
      }
      const appearance = { theme: 'stripe' }
      const elements = stripe.elements({ appearance, clientSecret: this.clientSecret })
      this.elements = elements
      const linkAuthenticationElement = elements.create('linkAuthentication')
      linkAuthenticationElement.mount('#link-authentication-element')
      linkAuthenticationElement.on('change', (event) => {
        this.emailAddress = event.value.email
      })
      this.elementList.push(linkAuthenticationElement)
      const paymentElementOptions = { layout: 'tabs' }
      const paymentElement = elements.create('payment', paymentElementOptions)
      paymentElement.mount('#payment-element')
      paymentElement.on('ready', () => {
        this.loading = false
      })
      paymentElement.on('change', (e) => {
        this.disablePayBtn = !e.complete
      })
      this.elementList.push(paymentElement)
    },
    async handleSubmit(e) {
      e.preventDefault()
      this.payLoading = true
      try {
        const { error } = await this.stripe.confirmPayment({
          elements: this.elements,
          confirmParams: {
            // Make sure to change this to your payment completion page
            return_url: window.location.href,
            receipt_email: this.emailAddress
          }
        })
        if (error.type === 'card_error' || error.type === 'validation_error') {
          this.payMessage = error.message
        } else {
          this.payMessage = '发生意外错误'
        }
      } finally {
        this.payLoading = false
      }
    },
    handleDialogClosed() {
      this.elementList.forEach(item => {
        if (typeof item.unmount === 'function') item.unmount()
      })
    },
    async checkStripeStatus() {
      const clientSecret = new URLSearchParams(window.location.search).get('payment_intent_client_secret')
      if (!clientSecret) return
      const isCashier = window.location.href.indexOf('/cashier') !== -1
      const isBalance = window.location.href.indexOf('/account-balance') !== -1
      uni.showModal({
        title: '提示',
        content: '请确认是否已完成支付？',
        confirmText: isCashier ? '查看订单' : '更新余额',
        cancelText: '重新支付',
        success: () => {
          if (isCashier) {
            uni.redirectTo({ url: '/order-module/order/order-list' })
          }
          if (isBalance && typeof this.getDepositBalance === 'function') {
            this.getDepositBalance()
          }
        }
      })
    }
  }
}
</script>

<style scoped lang="scss">
.loading-view {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 800rpx;
}
.payment-form {
  min-height: 800rpx;
  padding: 88rpx 44rpx 44rpx;
}
.pay-btn {
  width: 100%;
  margin-top: 20px;
  border-radius: 4px;
  &:not(.u-btn--default--disabled) {
    color: #ffffff;
    background-image: linear-gradient(90deg, #FA3534, #FF722E);
    background-color: #f42424;
  }
}
</style>
