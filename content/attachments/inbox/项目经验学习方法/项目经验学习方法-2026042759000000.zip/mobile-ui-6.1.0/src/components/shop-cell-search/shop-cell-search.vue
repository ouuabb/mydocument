<template>
	<view :class="'shop-view-single'">
		<view class="shop-view">
		    <view class="shop-img">
		        <u-image mode="widthFix" width="100rpx" :src="shopLogo" :border-radius="10"  ></u-image>
		    </view>
		    <view class="shop-info">
		        <view class="shop-title-view u-line-2">
		            {{shopName}}
		        </view>
                <!-- <u-line color="#F4F4F4" class="line"></u-line> -->
			 </view>
		</view>
	</view>
</template>

<script>
    /**
     * 店铺Cell组件
     *
     * ===== 使用场景 ======
     * 收藏店铺
     *
     * ===== 参数 =====
     * shopName        店铺名称
     * shopLogo         商品图片
     */
	export default {
		props:{
		    shopName: {
		        type: String,
		        default: ''
		    },
		    shopLogo: {
		        type: String,
		        default: ''
		    }

		},
	}
</script>

<style lang="scss">
    .shop-view-single {
        .shop-view {
            display: flex;
            flex-direction: row;
            line-height: 70rpx;
            background-color: #FFFFFF;
            .shop-img{
                width: 100rpx;
                height: 100rpx;
                display: flex;
                align-items: center;
                margin-top: 16px;
                padding-left: 10rpx;
            }
            .shop-info {
                flex: 1;
                margin-left: 20rpx;
                padding-bottom: 10rpx;
                border-bottom: 1px solid #f4f4f4;
                .shop-title-view{
                   margin-top: 45rpx;
                }
                .u-margin-left-10 {
                    float: left;
                    font-size: 28rpx;
                    color: #000;
                }
            }
        }
    }

</style>
