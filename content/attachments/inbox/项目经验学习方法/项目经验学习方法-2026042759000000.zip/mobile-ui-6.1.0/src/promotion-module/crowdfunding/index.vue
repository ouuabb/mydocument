<template>
  <view class="crowdfunding-container">
    <view class="list-container">
      <mescroll-body :down="down" @down="downCallback" @init="mescrollInit" @up="upCallback">
        <view v-for="(crowdfunding, index) in crowdfundingList" :key="index" class="goods-item">
          <view class="u-flex">
            <view class="goods-img">
              <image class="img" :src="crowdfunding.goods_sku.thumbnail"></image>
            </view>
            <view class="u-flex-1">
              <view class="u-line-2 u-m-b-30">
                {{ crowdfunding.goods_sku.goods_name }}
              </view>
              <view class="u-line-2 u-m-b-30">
                <view class="u-flex">
                  <view class="u-flex-9">
                    <progress activeColor="rgb(249, 93, 53)" :percent="crowdfunding.price_percent" stroke-width="10" />
                  </view>
                  <view class="u-flex-2" style="margin-left: 10rpx;color: rgb(249, 93, 53);font-weight: 700">
                    {{ formatProgressText(crowdfunding.price_percent_int) }}
                  </view>
                </view>

              </view>
              <view class="u-flex">
                <view class="u-flex-1">
                  <custom-price :price="crowdfunding.curr_price" textColor="black" :size="40" :fontWeight="700"></custom-price>
                </view>
                <navigator style="margin-bottom: 5rpx;margin-right: 10rpx" hover-class="none"
                           :url="'/goods-module/goods?goods_id=' + crowdfunding.goods_sku.goods_id + '&from_nav=crowdfunding&sku_id=' + crowdfunding.goods_sku.sku_id + '&crowdfundingId=' + crowdfunding.id">
                  <text class="crowdfunding-btn" v-if="crowdfunding.front_status === 0">立即支持</text>
                  <text class="crowdfunding-btn" v-else>查看详情</text>
                </navigator>
              </view>
            </view>
          </view>
          <view class="u-flex divide"></view>
          <view class="u-flex crowdfunding-data">
            <view class="u-flex-1 font">
              已筹{{ crowdfunding.already_goods_count }}个商品
            </view>
            <view class="u-flex-1 font" style="text-align: center">
              已筹{{ crowdfunding.already_price }}元
            </view>
            <view class="u-flex-1 font" style="text-align: right">
              <span v-if="crowdfunding.front_status === 0">剩余{{ formatRemainTime(crowdfunding.remain_second) }}</span>
              <span v-else>已结束</span>
            </view>
          </view>
        </view>
      </mescroll-body>
    </view>
    <loading-view v-if="loading"></loading-view>
  </view>
</template>

<script>
import * as API_Crowdfunding from '@/api/crowdfunding.js'
import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js"

export default {
  mixins: [MescrollMixin],
  data() {
    return {
      params: {
        page_no: 1,
        page_size: 10
      },
      crowdfundingList: [],
      down: {
        auto: false //是否在初始化完毕之后自动执行一次下拉刷新的回调
      },
      loading: true
    };
  },
  onLoad() {
  },
  methods: {
    //上拉加载数据
    upCallback(page) {
      this.params.page_no = page.num
      this.getCrowdfundingList();
    },
    //下拉刷新
    downCallback() {
      this.crowdfundingList = []
      this.params.page_no = 1
      this.mescroll.resetUpScroll(true)
    },
    //获取众筹活动列表
    getCrowdfundingList() {
      const params = JSON.parse(JSON.stringify(this.params))
      API_Crowdfunding.getList(params).then(response => {
        const {data} = response
        this.crowdfundingList.push(...data)
        this.loading = false
        this.mescroll.endBySize(data.length, response.data_total)
      })
    },
    formatRemainTime(second) {
      const days = Math.floor(second / 86400)
      const hours = Math.floor((second % 86400) / 3600)
      const minutes = Math.floor(((second % 86400) % 3600) / 60)
      const seconds = Math.floor(((second % 86400) % 3600) % 60)
      if (days > 0) {
        return days + '天'
      }
      if (hours > 0) {
        return hours + '小时'
      }
      if (minutes > 0) {
        return minutes + '分钟'
      }
      return seconds + '秒'
    },
    formatProgressText(percent) {
      if (percent > 999) {
        percent = 999
      }
      return percent + '%'
    }
  }
}
</script>

<style lang="scss" scoped>
.crowdfunding-container {
  ::v-deep.uni-progress-bar {
    border-radius: 20rpx;
    .uni-progress-inner-bar {
      background: linear-gradient(to right, rgb(255, 153, 22), rgb(247, 76, 63));
      border-radius: 20rpx;
    }
  }
  .list-container {
    background-color: #FFFFFF;

    .goods-item {
      padding: 20rpx;
      border: 2rpx solid #E4E7Ed;
      margin: 20rpx;
      border-radius: 20rpx;

      .goods-img {
        width: 200rpx;
        height: 200rpx;
        margin-right: 20rpx;
        border-radius: 10rpx;
        overflow: hidden;

        .img {
          width: 100%;
          height: 100%;
        }
      }

      .crowdfunding-btn {
        padding: 10rpx 22rpx;
        color: rgb(221, 188, 154);
        background-color: rgb(26, 25, 25);
        border-radius: 35rpx;
        font-size: 35rpx;
      }

      .divide{
        border-top: 2rpx solid #E4E7Ed;
        margin-top: 15rpx;
        margin-bottom: 20rpx;
      }

      .crowdfunding-data{
        .font{
          color: rgb(158, 147, 136);
          font-size: 28rpx;
        }
      }
    }
  }
}
</style>
