<template>
	<view class="coupons-container">
        <mescroll-body ref="mescrollRef" :down="down" @down="downCallback" @up="upCallback">
            <coupon-item
                v-for="(coupon, couponIndex) in couponsList"
                :key="couponIndex"
                :coupon="coupon"
                @handleReceiveCoupon="handleReceiveCoupon" />
        </mescroll-body>
        <u-tabbar v-model="tabbarCurrent" :list="tabbarList" active-color="#FA3534" :before-switch="beforeSwitch"></u-tabbar>
        <loading-view v-if="loading"></loading-view>
    </view>
</template>

<script>
    import * as API_Members from '@/api/members.js'
    import * as API_Promotions from '@/api/promotions.js'
    import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins.js'
    import CouponItem from '@/components/couponItem/couponItem'

	export default {
        mixins: [MescrollMixin],
        components: { CouponItem },
		data() {
			return {
                tabbarList: [
                    {
                        iconPath: "youhuiquan",
                        selectedIconPath: "youhuiquan",
                        text: '领优惠券',
                        customIcon: true
                    }, {
                        iconPath: "wode",
                        selectedIconPath: "wode",
                        text: '我的优惠券',
                        customIcon: true
                    }
                ],
                tabbarCurrent: 0,
                params: {
                    page_no: 1,
                    page_size: 10
                },
                loading: true,
                finished: false,
                couponsList: [], //优惠券列表
                down: {
                    auto: false //是否在初始化完毕之后自动执行一次下拉刷新的回调
                }
			}
		},
		methods: {
            //下拉刷新
            downCallback() {
                this.params.page_no = 1
                this.couponsList = []
                this.getAllCoupons()
            },
            //上拉加载
            upCallback(page) {
                this.params.page_no = page.num
                this.getAllCoupons()
            },
            // 底部tabbar切换
            beforeSwitch(index) {
                if (index === this.tabbarCurrent) return
                this.judgeLogin(() => {
                    uni.redirectTo({
                        url: "/mine-module/coupon"
                    })
                })
            },
            // 领取优惠券
            handleReceiveCoupon(coupon) {
                API_Members.receiveCoupons(coupon.coupon_id).then(response => {
                    uni.showToast({
                        title: '领取成功'
                    })
                })
            },
            // 获取优惠权列表
            getAllCoupons() {
                API_Promotions.getAllCoupons(this.params).then(response => {
                    const { data } = response
                    this.couponsList.push(...data)
                    this.loading = false
                    this.mescroll.endBySize(data.length, response.data_total)
                })
            }
		}
	}
</script>

<style lang="scss" scoped>
    .coupons-container {
        ::v-deep.u-empty {
            margin-top: 200rpx !important;
        }
        // .coupon-item {
        //     position: relative;
        //     z-index: 1;
        //     margin: 20rpx;
        //     background-color: #fff;
        //     mask-border-source: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAAApBAMAAABXfK/HAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAASUExURUxpcf////////////////////t7VQsAAAAFdFJOUwB5N+QXTLmpnQAAAHxJREFUSMft17sRgDAMA1A+GYCGHg4WoGAPSPD+q3AQdCwgddIAr7ALy008ORokKKnMBTQx1Qy1Y6on1JapFqg9U43hU0eqmqljhVqmV124at0XaVe/Gtua5p2uUmPVqlWrVq1a1V5uScvQNCJNe5M0TU0r1jR4zbfB/oxuVMRWrAgOtD4AAAAASUVORK5CYII=);
        //     mask-border-width: 20rpx 170rpx 20rpx 0;
        //     mask-border-slice: 20 168 20 1 fill;
        //     border-radius: 10rpx;
        //     &.brought-out {
        //         filter: grayscale(100%)
        //     }
        //     &::after {
        //         content: "";
        //         position: absolute;
        //         top: 10rpx;
        //         bottom: 10rpx;
        //         left: 0;
        //         right: 100rpx;
        //     }
        //     .coupon-info {
        //         padding: 25rpx 0;
        //         .coupon-img {
        //             width: 150rpx;
        //             height: 150rpx;
        //             .img {
        //                 width: 100%;
        //                 height: 100%;
        //             }
        //         }
        //         .coupon-left {
        //             width: 400rpx;
        //             overflow: hidden;
        //             .coupon-tips {
        //                 margin-left: 15rpx;
        //                 color: #FA3534;
        //             }
        //         }
        //         .coupon-right {
        //             width: 150rpx;
        //             position: absolute;
        //             right: 0;
        //             top: 0;
        //             bottom: 0;
        //             color: #FFFFFF;
        //             background-color: #FA3534;
        //             border-radius: 0 10rpx 10rpx 0;
        //             justify-content: center;
        //             .icon-receive-coupon, .icon-receive-coupon-out {
        //                 font-size: 24rpx;
        //                 width: 100rpx;
        //                 height: 100rpx;
        //                 border-radius: 50%;
        //                 display: flex;
        //                 align-items: center;
        //                 justify-content: center;
        //                 border: 4rpx solid #FFFFFF;
        //             }
        //         }
        //     }
        // }
    }
</style>
