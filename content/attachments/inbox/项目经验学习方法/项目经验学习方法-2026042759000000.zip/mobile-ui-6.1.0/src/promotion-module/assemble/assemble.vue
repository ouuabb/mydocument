<template>
	<view class="pin-tuan-container">
        <view class="tabs-view">
            <u-tabs :list="categories" :name="'cat_name'" :current="current" active-color="#FA3534" @change="handleClickCate"></u-tabs>
            <u-line></u-line>
        </view>
        <view class="goods-container">
            <mescroll-body ref="mescrollRef" top="80" @init="mescrollInit" :down="down" @down="downCallback" @up="upCallback">
                <view v-for="(goods, index) in assembleList" :key="index" class="goods-item u-flex">
                    <view class="goods-img">
                        <image class="img" :src="goods.thumbnail"></image>
                    </view>
                    <view class="u-flex-1">
                        <view class="u-line-2 u-m-b-30">
                            {{ goods.goods_name }}
                        </view>
                        <view class="u-flex">
                            <view class="u-flex-1">
                                <custom-price :price="goods.sales_price" :size="36" :fontWeight="600"></custom-price>
                            </view>
                            <navigator hover-class="none" :url="'/goods-module/goods?goods_id=' + goods.goods_id + '&from_nav=assemble&sku_id=' + goods.sku_id + '&pintuan_id=' + goods.pin_tuan_id">
                                <text class="to-pin-tuan-btn">去拼团</text>
                            </navigator>
                        </view>
                        <view class="original-price u-flex u-m-t-20">
                            <view class="u-flex-1 u-flex">
                                原价：
								<!-- {{ goods.origin_price | unitPrice }} -->
								<custom-price :price="goods.origin_price" textColor="#666" :size="24"></custom-price>
                            </view>
                            <view class="">
                                已出售：<text class="num">{{ goods.sold_quantity }}</text>件
                            </view>
                        </view>
                    </view>
                </view>
            </mescroll-body>
        </view>
        <loading-view v-if="loading"></loading-view>
    </view>
</template>

<script>
    import * as API_Promotions from '@/api/promotions.js'
    import * as API_Goods from '@/api/goods.js'
    import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js"
	export default {
        mixins: [MescrollMixin],
		data() {
			return {
                params: {
                  page_no: 1,
                  page_size: 10,
                  category_id: 0
                },
                categories: [], //拼团分类
                current: 0,
                assembleList: [], //拼团分类商品
                down: {
                    auto: false //是否在初始化完毕之后自动执行一次下拉刷新的回调
                },
                loading: true
			};
		},
        onLoad() {
            this.getAssembleCategorys()
        },
        methods: {
            //选择拼团分类
            handleClickCate(index) {
                this.current = index
                this.assembleList = []
                this.params.page_no = 1
                const cate = this.categories[index]
                this.params.category_id = cate.category_id
                this.mescroll.resetUpScroll(true)
            },
            //上拉加载数据
            upCallback(page){
                this.params.page_no = page.num
                this.getAssembleList();
            },
            //下拉刷新
            downCallback(){
                this.handleClickCate(this.current);
            },
            //获取拼团分类
            getAssembleCategorys() {
                API_Goods.getCategory().then(response => {
                    response.unshift({ category_id: 0, cat_name: '全部', cat_order: 0, active: true })
                    this.categories = response
                })
            },
            //获取拼团商品
            getAssembleList() {
                const params = JSON.parse(JSON.stringify(this.params))
                if (params.category_id == 0) delete params.category_id
                API_Promotions.getAssembleList(params).then(response => {
                    const { data } = response
                    this.assembleList.push(...data)
                    this.loading = false
                    this.mescroll.endBySize(data.length, response.data_total)
                })
            }
        }
	}
</script>

<style lang="scss" scoped>
    .pin-tuan-container {
        .goods-container {
            background-color: #FFFFFF;
            ::v-deep.u-empty {
                margin-top: 120rpx !important;
            }
            .goods-list {
                height: calc(100vh - 80rpx);
            }
            .goods-item {
                padding: 20rpx;
                border-bottom: 2rpx solid #E4E7Ed;
                .goods-img {
                    width: 200rpx;
                    height: 200rpx;
                    margin-right: 20rpx;
                    border-radius: 10rpx;
                    overflow: hidden;
                    .img {
                        width: 100%;
                        height: 100%;
                    }
                }
                .original-price {
                    color: #666;
                    font-size: 24rpx;
                    .num {
                        color: #FA3534;
                    }
                }
                .to-pin-tuan-btn {
                    color: #FFFFFF;
                    padding: 8rpx 20rpx;
                    border-radius: 8rpx;
                    background-color: #FA3534;
                }
            }
        }
    }
</style>
