<template>
	<view class="instructions-use u-p-20">
        <u-parse class="article-content" :html="article.content"></u-parse>
	</view>
</template>

<script>
    import * as API_Article from '@/api/article.js';
	export default {
		data() {
			return {
                article: ''
			}
		},
        onLoad() {
            this.getArticleDetail()
        },
		methods: {
            //获取新手必看
            getArticleDetail() {
                API_Article.getArticleDetail('116').then(response => {
                    this.article = response
                })
            }
		}
	}
</script>

<style>

</style>
