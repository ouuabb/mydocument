<template>
  <view class="distribution-goods-wrap">
    <mescroll-body ref="mescrollRef" auto="false" :down="down" @init="mescrollInit" @down="downCallback"
      @up="upCallback">
      <view class="goods-item" v-for="(item, index) in goodsList" :key="index">
        <image :src="item.small" class="goods-img" />
        <view class="goods-info">
          <view class="goods-name">{{item.goods_name}}</view>
          <view class="price">
            <!-- <text>{{item.price | unitPrice}}</text> -->
            <custom-price :price="item.price" textColor="#333"></custom-price>
          </view>
          <view class="footer">
            <view style="display: flex; line-height: 1;">
              <text>预计佣金：</text>
              <!--{{brokerage(item.price, item.ratio_lv1) | unitPrice}} -->
              <custom-price :price="brokerage(item.price, item.ratio_lv1)" textColor="rgb(77, 55, 255)" fontWeight="500"></custom-price>
            </view>
            <view size="mini" class="share-btn" @click="handleShareGoods(item)">分享赚</view>
          </view>
        </view>
      </view>
    </mescroll-body>

    <!-- 分享弹窗 -->
    <goods-distribution ref="distribution" :show="popupShow" :goods_id="shareGoods.goods_id"
      :goods_name="shareGoods.goods_name" :goods_img="shareGoods.goods_img" :goods_price="shareGoods.price"
      :disParams="shareDisParams" :minicode="miniCode" @close="handleClose"></goods-distribution>

  </view>
</template>

<script>
  import * as API_Distribution from '@/api/distribution'
  import goodsDistribution from '../components/goodsShare/index'
  import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
  import * as API_Common from '@/api/common.js'

  export default {
    mixins: [MescrollMixin], // 使用mixin
    components: {
      goodsDistribution
    },
    data() {
      return {
        params: {
          page_no: 1,
          page_size: 10
        },
        goodsList: [],
        down: {
          auto: false
        },
        loading: false,
        popupShow: false, //分享弹窗显隐
        disParams: '', // 分销query
        shareDisParams: '', // 分销参数
        miniCode: '', // 小程序码
        shareGoods: {} // 当前分享商品
      };
    },
    computed: {
      /** 预计佣金计算 */
      brokerage() {
        // 预计佣金为=商品价格 x 商品一级佣金比例
        return (price, ratio_lv1) => {
          return (price * (ratio_lv1 / 100)).toFixed(2)
        }
      }
    },
    onLoad() {
      this.getGenerateShortLink()
    },
    methods: {
      //上拉加载数据
      upCallback(page) {
        this.params.page_no = page.num;
        this.getDistributionGoods();
      },
      //下拉刷新
      downCallback() {
        this.goodsList = []
        this.params = {
          page_no: 1,
          page_size: 10
        }
        // this.getDistributionGoods()
        this.mescroll.resetUpScroll(true)
      },

      /** 关闭分享弹窗 */
      handleClose(show) {
        this.popupShow = show
      },
      /** 分享触发 */
      handleShareGoods(item) {
        this.shareGoods = item
        this.shareDisParams = `${this.disParams}&goods_id=${item.goods_id}`
        // #ifdef MP-WEIXIN
        API_Distribution.getMiniprogramCode(item.goods_id).then(response => {
          let miniCode = response.replace(/http\:\/\//, 'https://')
          this.miniCode = miniCode
        })
        // #endif

        // #ifdef H5
        API_Common.getBase64(item.thumbnail).then(base64 => {
          this.shareGoods.goods_img = 'data:image/jpg;base64,' + base64
          //商品图片转换为https
        })
        // #endif
        this.shareGoods.goods_img = item.thumbnail.replace(/http\:\/\//, 'https://')
        this.popupShow = true
      },

      /** 获取分销参数 */
      getGenerateShortLink() {
        API_Distribution.generateShortLink().then(response => {
          const _query = response.message.substring(response.message.indexOf('?'), response.message.length)
          this.disParams = `${_query}`
        })
      },
      /** 获取分销商品列表 */
      getDistributionGoods() {
        API_Distribution.getDistributionGoods(this.params).then(res => {
          if (res.data.length) {
            this.goodsList = this.goodsList.concat(res.data)
          }
          this.mescroll.endBySize(res.data.length, res.data_total);
        })
      }

    },
    async onShareAppMessage() {
      return {
        title: this.shareGoods.goods_name,
        imageUrl: this.shareGoods.goods_img,
        path: `/goods-module/goods?goods_id=${this.shareGoods.goods_id}&${this.disParams.replace('?', '')}`
      }
    }
  }
</script>

<style lang="scss" scoped>
  .distribution-goods-wrap {
    background: #fff;

    .goods-item {
      display: flex;
      align-items: center;
      padding: 20rpx;
      box-sizing: border-box;
      border-bottom: 1px solid #efefef;

      .goods-img {
        width: 200rpx;
        height: 200rpx;
      }

      .goods-info {
        width: calc(100% - 200rpx);
        padding: 0 30rpx;
      }

      .text-ellipsis {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .goods-name {
        font-size: 30rpx;
        font-weight: 500;
        color: #333;
        margin-bottom: 20rpx;
      }

      .price {
        color: #333;
        font-weight: 500;
        margin: 20rpx 0;
      }

      .footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        color: rgb(77, 55, 255);
        font-weight: 500;

        .share-btn {
          text-align: center;
          background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
          color: #fff;
          border-radius: 40rpx;
          margin: 0;
          height: 50rpx;
          line-height: 50rpx;
          min-width: 150rpx;
        }
      }
    }
  }
</style>