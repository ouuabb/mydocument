<template>
  <view class="address-container">
    <view class="add-info">
      <u-cell-group>
        <u-field
          v-model="addressForm.name"
          label="收货人"
          required
          placeholder="请填写收货人姓名"
          placeholder-style="color: #CDCDCD"
          maxlength="20"
        />
        <!-- 地区地址选择 -->
        <addressFiled
          :defaultForm="addressForm"
          @handleCountry="handleCountry"
          @handlerRegionJson="handlerRegionJson"/>

        <u-form-item
            labelPosition="left"
            label="手机号码"
            required
            labelWidth="150">
          <view class="u-flex">
            <area-select
              ref="areaSelect"
              :areaCode="addressForm.mobile_area_code"
            ></area-select>
            <u-input v-model="addressForm.mobile" placeholder="请填写收货人手机号"/>
          </view>
        </u-form-item>

        <u-field
            labelPosition="top"
          v-model="addressForm.addr"
          type="textarea"
          label="详细地址"
          required
          placeholder="街道、楼牌号等"
          placeholder-style="color: #CDCDCD"
          maxlength="50"
        />
        <u-cell-item title="标签" :arrow="false" hover-class="noen" class="add-tags">
          <u-tag
            class="u-m-l-20"
            v-for="(tag, index) in tags"
            :key="index" :text="tag"
            :type=" addressForm.ship_address_name === tag ? 'primary' : 'info'"
            shape="circle"
            @click="handleTags(tag)"
          />
        </u-cell-item>
        <u-cell-item title="设置默认地址" :arrow="false" hover-class="none">
          <u-switch active-color="#FA3534" v-model="addressForm.def_addr"></u-switch>
        </u-cell-item>
      </u-cell-group>
    </view>
    <view class="big-btn" @click="$u.throttle(submitAddressForm, 1000)">
      <view class="btn">
        <text class="u-m-l-10">保存</text>
      </view>
    </view>
  </view>
</template>

<script>
import * as API_Address from '@/api/address'
import { i18n as openI18n } from '@/config/config'
import areaSelect from '@/components/areaSelect/areaSelect'
import addressFiled from '@/components/addressFiled/addressFiled'
import { Foundation } from '@/app-utils'

export default {
  components: {
    areaSelect,
    addressFiled
  },
  data() {
    return {
      openI18n,
      // 地址表单数据
      addressForm: {
        mobile_area_code: '',
        name: '',
        mobile: '',
        addrs: '',
        addr: '',
        region: '',
        ship_address_name: '',
        def_addr: false
      },
      //标签
      tags: ['家', '公司', '学校'],
      regionJSon: ''
    }
  },
  onLoad(options) {
    this.addressForm.addr_id = options.addr_id || ''
    this.addressForm.addr_id && this.getAddressDetail()
    uni.setNavigationBarTitle({ title: options.addr_id ? '编辑收货人' : '新建收货人' })
  },
  methods: {
    /** 国家选择切换 */
    handleCountry(item) {
        this.$set(this.addressForm, 'mobile_area_code', item.tel)
    },
    //标签选择
    handleTags(tag) {
      this.addressForm.ship_address_name = tag
    },
    //保存收货地址
    submitAddressForm() {
      const params = this.$u.deepClone(this.addressForm)
      const { mobile_regex, formatValid } = this.$refs.areaSelect
      const mobileReg = new RegExp(mobile_regex)

      if (!params.name || !params.name.trim()) {
        this.$u.toast(`请输入收货人姓名`)
      } else if (!params.mobile) {
        this.$u.toast(`请输入手机号码`)
      } else if (!mobileReg.test(formatValid(params.mobile))) {
        this.$u.toast(`手机号格式不对，请重新输入`)
      } else if (!params.addr || !params.addr.trim()) {
        this.$u.toast(`请输入详细地址`)
      } else {
        params.region = this.regionJSon
        const addr_id = params.addr_id
        params.def_addr = params.def_addr ? 1 : 0
        params.mobile_area_code = this.$refs.areaSelect.areaCode_n ? this.$refs.areaSelect.areaCode_n : params.mobile_area_code
        params.mobile = this.$refs.areaSelect.mobileValue(params.mobile)
        if (addr_id) {
          API_Address.editAddress(addr_id, params).then(() => {
            this.$u.toast(`修改成功`)
            uni.navigateBack()
          })
        } else {
          API_Address.addAddress(params).then(() => {
            this.$u.toast(`添加成功`)
            uni.navigateBack()
          })
        }
      }
    },
    //地址详情
    getAddressDetail() {
      API_Address.getAddressDetail(this.addressForm.addr_id).then(res => {
        const params = JSON.parse(JSON.stringify(res))
        params.def_addr = !!params.def_addr
        params.addrs = `${params.province}${params.city}${params.county}${params.town}`
        params.region = params.town_id && params.town_id != 0 ? params.town_id : params.county_id
        const { areaCode, mobileValue } = Foundation.formatIn18Mobile(res.mobile)
        params.mobile = mobileValue
        params.mobile_area_code = areaCode
        this.addressForm = params
      })
    },
    handlerRegionJson(json) {
      this.regionJSon = json
    }
  }
}
</script>

<style lang="scss" scoped>
.address-container {
  background-color: #FFFFFF;
  height: 100%;
  position: relative;
  ::v-deep .u-form-item {
    padding: 20rpx 30rpx;
  }
  ::v-deep .add-info {
    .add-tags {
      .u-cell__value {
        text-align: left;
        margin-left: 60rpx;
      }
      .u-size-default {
        font-size: 24rpx;
        background-color: #FFFFFF;
        padding: 10rpx 30rpx;
      }
    }
    .u-cell__label {
      font-size: 24rpx;
    }
    .u-switch {
      margin-top: 20rpx;
    }
  }
}
</style>
