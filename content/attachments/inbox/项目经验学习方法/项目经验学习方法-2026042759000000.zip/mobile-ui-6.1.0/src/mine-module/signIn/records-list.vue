<template>
	<view class="records-container">
      <view class="records-content">
				<div class="records-item" v-for="item in records" :key="item.id">
					<div class="info">
						<image v-if="item.prize_type === 'POINT'" class="icon" src="@/static/images/member/point.png" mode="widthFix" lazy-load="false" />
						<image v-else class="icon" src="@/static/images/member/coupon.png" mode="widthFix" lazy-load="false" />

						<div class="record-info">
							<p>{{item.prize_type === 'POINT' ? '积分奖励' : '优惠券奖励'}}</p>
							<p class="value">{{item.description}}</p>
						</div>
					</div>
					<p class="time">{{item.sign_in_date | unixToDate}}</p>
				</div>
			</view>
	</view>
</template>

<script>
	import * as API_Promotions from '@/api/promotions.js'
   
	export default {
		data() {
			return {
				records: []
			}
		},
		onLoad() {
			this.getSignActivity()
		},
		methods: {
			/** 获取签到活动数据 */
			getSignActivity() {
				API_Promotions.getSignActivity().then(res => {
					if (res) {
						this.records = res.records
					}
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
.records-content {
	border-radius: 14rpx;
	background: #fff;
	margin: 25rpx;
	padding: 20rpx;
	.records-item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin: 0  0 30rpx 0;
		.record-info {
			width: 300rpx;
		}
		.time {
			color: #424242;
			font-size: 24rpx;
		}
		.info {
			display: flex;
			align-items: center;
			font-size: 28rpx;
			color: #333;
			.value {
				color: #999;
				font-size: 23rpx;
				margin-top: 20rpx;
			}
			.icon {
				width: 64rpx;
				height: 64rpx;
				margin-right: 25rpx;
			}
		}
	}
}
</style>
