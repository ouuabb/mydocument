<template>
	<view class="sign-in-container">
		<div class="bg-box">
			<image class="sign-bg" src="@/static/images/bg/sign_bg.png" mode="widthFix" lazy-load="false" />
			<image class="sign-calendar" src="@/static/images/bg/sign01.png" mode="widthFix" lazy-load="false" />
			<div class="text-box">
				<p>每日签到</p>
				<p class="big-font">有惊喜</p>
			</div>
			<div class="rule-text" @click="handleShowRule" v-if="activityData.description">
				规则
				<u-icon class="sign-icon" name="arrow-right" color="#E1B072" />
			</div>
		</div>
		<div class="calendar-box">
			<div class="week-box">
				<p class="item week" v-for="week in weekList" :key="week">{{week}}</p>
			</div>
			<div class="week-box">
				<p class="item last-item" v-for="day in lastMonthDay" :key="day">{{day}}</p>
				<div class="item" v-for="(item, index) in monthDay" :key="`${item.day}-${index}`">
					<image v-if="item.sign_prize" class="prize-icon" src="@/static/images/B0081.png" mode="widthFix" lazy-load="false"/>
					<p v-else :class="{'item-sign': item.sign}">{{item.day}}</p>
					<u-icon class="sign-icon" v-if="item.sign" name="checkmark-circle-fill" color="#E1B072" />
				</div>
			</div>
			<div v-if="activityData.rewards && activityData.rewards.length > 1">
				<p class="activity-tips">连续签到有机会获得以下奖励</p>
				<scroll-view class="activity-box"  scroll-x >
					<div class="activity-item" v-for="item in activityData.rewards" :key="item.id">
						<p class="title">{{item.sign_day}}天</p>
						<div class="info">
							<image v-if="item.icon" class="point-icon" :src="item.icon" mode="heightFix" lazy-load="false" />
							<image v-else class="point-icon" src="@/static/images/point-icon.png" mode="widthFix" lazy-load="false" />
							<p class="text" v-if="item.description">{{item.description}}</p>
							<p class="text" v-else>{{item.points}}积分</p>
						</div>
					</div>
				</scroll-view>
			</div>
		</div>
		<div class="records-box" v-if="activityData.records.length">
			<div class="title">
				我的签到记录
				<p class="right-box" @click="handlerRecords" v-if="activityData.records.length > 5">
					查看更多
					<u-icon name="arrow-right" />
				</p>
			</div>

			<div v-for="(item, index) in activityData.records" :key="item.id">
				<div class="records-item" v-if="index < 5">
					<div class="info">
						<image v-if="item.prize_type === 'POINT'" class="icon" src="@/static/images/member/point.png" mode="widthFix" lazy-load="false" />
						<image v-else class="icon" src="@/static/images/member/coupon.png" mode="widthFix" lazy-load="false" />

						<div class="record-info">
							<p>{{item.prize_type === 'POINT' ? '积分奖励' : '优惠券奖励'}}</p>
							<p class="value">{{item.description}}</p>
						</div>
					</div>
					<p class="time">{{item.sign_in_date | unixToDate}}</p>
				</div>
			</div>

		</div>
		<div class="divider-box" v-if="activityData.goods && activityData.goods.length">
			<image class="divider-icon" src="@/static/images/member/divider.png" mode="widthFix" lazy-load="false" />
			热销商品
			<image class="divider-icon icon-transition" src="@/static/images/member/divider.png" mode="widthFix" lazy-load="false" />
		</div>

		<div class="goods-box">
			<div
				class="goods-item"
				@click="handleGoodsInfo(goods.goods_id)"
				v-for="goods in activityData.goods" :key="goods.goods_id">
				<image class="goods-img" :src="goods.goods_img" lazy-load="false" />
				<p class="title">{{goods.goods_name}}</p>
				<p class="price-text"><span class="price">￥{{goods.goods_price}}</span></p>
			</div>
		</div>
		<u-popup
			v-model="showSuccess"
			mode="center"
			length="70%"
			border-radius="10"
			:safe-area-inset-bottom="true"
			closeable
			close-icon-size="20"
			@close="closePop('showSuccess')">
			<div class="success-pop">
				<div class="title">签到成功</div>
				<div class="success-icon">
					<u-icon size="100rpx" name="checkmark"></u-icon>
				</div>
				<p class="tips">连续签到可获得额外的奖励哦</p>
			</div>
		</u-popup>
		<u-popup
			v-model="showPopup"
			mode="center"
			length="80%"
			border-radius="20"
			:safe-area-inset-bottom="true"
			closeable
			close-icon-size="20"
			@close="closePop('showPopup')">
				<scroll-view scroll-y class="pop-content">
					<div class="title">签到规则</div>
					<p>{{activityData.description}}</p>
				</scroll-view>
				<div class="close-box" @click="closePop('showPopup')">我知道了</div>
		</u-popup>
		<loading-view v-if="loading"></loading-view>
	</view>
</template>

<script>
import * as API_Promotions from '@/api/promotions.js'
export default {
	data() {
		return {
			params: {
				page_no: 1,
				page_size: 10
			},
			//是否已加载完毕
			finished: false,
			//页面滚动高度
			scrollHeight: '',
			loading: false,
			// 签到规则
			showPopup: false,
			// 签到成功
			showSuccess: false,
			activityData: {
				description: '',
				records: [],
				sign_days: [],
				goods: []
			},
			monthDay: '',
			lastMonthDay: [],
			weekList: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
			signInit: false
		}
	},
	onLoad() {
		this.scrollHeight = uni.getSystemInfoSync().windowHeight + 'px'
		this.getSignActivity()
	},
	methods: {
		closePop(type) {
			this[type] = false
		},
		handleShowRule() {
			this.showPopup = true
		},
		/** 查看商品详情 */
		handleGoodsInfo(goods_id) {
			this.navigateTo(`/goods-module/goods?goods_id=${goods_id}`)
		},
		/** 签到操作 */
		signActivity() {
			API_Promotions.signActivity().then(res => {
				this.showSuccess = true
				this.signInit = true
				// 更新签到数据
				this.getSignActivity(false)
			})
		},
		/** 查看签到记录 */
		handlerRecords() {
			uni.navigateTo({
				url:"/mine-module/signIn/records-list"
			})
		},

		/** 获取签到活动数据 */
		getSignActivity(init = true) {
			API_Promotions.getSignActivity().then(res => {
				if (res) {
					if (res.rewards) {
						res.rewards.sort(function(a,b){
							return a.sign_day - b.sign_day
						})
						if (res.rewards[0].sign_day === 1) {
							res.rewards.shift()
						}
					}
					this.activityData = res
					if (init && !this.signInit) {
						this.signActivity()
					}
				}
				this.initCalendar()
			})
		},
		initCalendar() {
			const sign_days = this.activityData.sign_days
			const date = new Date(),
						year = date.getFullYear(),
						month = date.getMonth()+1,
						// 当月天数
						day = new Date(year, month, 0).getDate(),
						// 上月天数
						lastMonthDay = new Date(year, date.getMonth(), 0).getDate(),

						dataVal = `${year}-${month.length === 1 ? month : '0' + month}-01`,
						// 当月1号是星期几
						weekIndex = new Date(dataVal).getDay();

			const dayArr = Array.from({length: lastMonthDay}, (x, i) => i + 1)
			this.lastMonthDay = dayArr.splice(-weekIndex)
			let monthDay = Array.from({length: day}, (x, i) => {
				return {day: i + 1}
			})
			monthDay.map(item => {
				sign_days.forEach(day => {
					if (day.sign_day === item.day) {
						item.sign = day.sign
						item.sign_prize = day.sign_prize
					}
				})
			})
			this.monthDay = monthDay
		},

		// 滚动加载更多数据
		onScrolltolower() {
			if (this.finished) return
			this.params.page_no += 1
			this.getPointsData()
		}
	}
}
</script>

<style lang="scss" scoped>
.sign-in-container {
	padding-bottom: 50rpx;
	.success-pop {
		height: 400rpx;
		.success-icon {
			color: #FFB635;
			margin: 30rpx 0;
			text-align: center;
		}
		.tips {
			margin-top: 20rpx;
			text-align: center;
			color: #999;
			font-size: 26rpx;
		}
		.title {
			height: 100rpx;
			background: #FFB635;
			color: #fff;
			font-size: 40rpx;
			text-align: center;
			line-height: 100rpx;
		}
	}
	.pop-content {
		padding: 30rpx;
		color: #333;
		line-height: 55rpx;
		height: 50vh;
		box-sizing: border-box;
		font-size: 26rpx;
		.title {
			font-size: 40rpx;
			text-align: center;
			margin-bottom: 20rpx;
		}
	}
	.close-box {
		height: 95rpx;
		background: #FEE7E7;
		color: #F04045;
		text-align: center;
		line-height: 95rpx;

	}
	.bg-box {
		position: relative;
		.rule-text {
			position: absolute;
			top: 20rpx;
			right: 20rpx;
			color: #C77C3D;
			font-size: 24rpx;
		}
		.text-box {
			color: #C77C3D;
			font-size: 54rpx;
			line-height: 70rpx;
			position: absolute;
			left: 90rpx;
			top: 100rpx;
			.big-font {
				font-size: 74rpx;
				margin-top: 20rpx;
			}
		}
		.sign-bg {
			width: 100%;
			height: 400rpx;
		}
		.sign-calendar {
			width: 50%;
			position: absolute;
			top: 60rpx;
			right: 0rpx;
			overflow: hidden;
		}
	}
	.goods-box {
		margin: 32rpx;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		.goods-item {
			width: 336rpx;
			background: #fff;
			border-radius: 24rpx;
			padding-bottom: 20rpx;
			margin-bottom: 20rpx;
			.goods-img {
				border-radius: 24rpx 24rpx 0 0;
				width: 100%;
				height: 336rpx;
			}
			.title {
				padding: 0 18rpx;
				margin-top: 10rpx;
				font-size: 30rpx;
				color: #3A3A3A;
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 2;
				-webkit-box-orient: vertical;

			}
			.price-text {
				padding: 0 18rpx;
				color: #F04045;
				font-size: 22rpx;
				margin-top: 30rpx;
			}
			.price {
				font-size: 34rpx;
			}

		}
	}
	.divider-box {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 60rpx;
		.divider-icon {
			width: 80rpx;
			margin: 0 20rpx;
		}
		.icon-transition {
			transform: rotateY(180deg);
		}
	}
	.records-box {
		margin: 60rpx 30rpx;
		border-radius: 24rpx;
		background: #fff;
		padding: 30rpx;
		.records-item {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin: 20rpx 0;
			.record-info {
				width: 300rpx;
			}
			.time {
				color: #424242;
				font-size: 24rpx;
			}
			.info {
				display: flex;
				align-items: center;
				font-size: 28rpx;
				color: #333;
				.value {
					color: #999;
					font-size: 23rpx;
					margin-top: 20rpx;
				}
				.icon {
					width: 64rpx;
					height: 64rpx;
					margin-right: 25rpx;
				}
			}
		}
		.title {
			font-size: 30rpx;
			color: #333;
			display: flex;
			justify-content: space-between;
			.right-box {
				font-size: 22rpx;
				color: #666;
			}
		}
	}
	.calendar-box {
		position: relative;
		background: #fff;
		margin: -30rpx 26rpx;
		border-radius: 24rpx;
		.activity-tips {
			color: #666;
			font-size: 22rpx;
			padding: 0 30rpx 30rpx;
		}
		.activity-box {
			padding: 0 10rpx 30rpx 30rpx;
			box-sizing: border-box;
			display: flex;
			white-space:nowrap;
			width: 100%;
			overflow-y: hidden;
			overflow-x: scroll;
			.activity-item {
				display: inline-block;
				width: 200rpx;
				border-radius: 20rpx;
				border: 1px solid #FFEADC;
				height: 166rpx;
				font-size: 20rpx;
				margin-right: 20rpx;
				.title {
					border-radius: 20rpx 20rpx 0 0;
					height: 45rpx;
					line-height: 45rpx;
					text-align: center;
					color: #DD6719;
					font-size: 22rpx;
					background-color: #FFEADC;
				}
				.info {
					height: 120rpx;
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: center;
					font-size: #666;
					.text {
						margin-top: 10rpx;
					}
				}
				.point-icon {
					width: 52rpx;
					height: 52rpx;
					border-radius: 50%;
				}
			}
		}
	}

	.week-box {
		display: flex;
		flex-wrap: wrap;
		width: 100%;
		.last-item {
			color: #CDCDCD !important;
		}
		.week {
			color: #666;
			font-size: 20rpx;
		}
		.item-sign {
			height: 52rpx;
			line-height: 55rpx;
			width: 52rpx;
			color: #fff;
			text-align: center;
			border-radius: 50%;
			border: 2px solid #FFD094;
			background: linear-gradient(136deg, #FC8677 0%, #FF4E4E 82%);
		}
		.item {
			width: calc(100% / 7);
			height: 100rpx;
			color: #333;
			line-height: 100rpx;
			position: relative;
			.prize-icon {
				width: 44rpx;
				height: 55rpx;
			}
			.sign-icon {
				position: absolute;
				bottom: -12rpx;
				left: 40%;
			}
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
		}
	}
  ::v-deep.uni-calendar__header {
    display: none;
  }
}
</style>
