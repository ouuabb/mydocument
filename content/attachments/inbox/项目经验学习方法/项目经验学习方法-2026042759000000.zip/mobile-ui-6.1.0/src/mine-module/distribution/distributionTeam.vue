<template>
	<view class="distribution-team-wrap">
        <view class="header-content">
            <view class="team-info u-flex u-col-center u-row-between">
                <view
                    class="team-item u-flex-col u-col-center"
                    v-for="(item, index) in teamCount"
                    :key="index">
                    <view class="item-label">{{item.label}}</view>
                    <view class="number">{{item.count}}</view>
                </view>
            </view>
        </view>
        <scroll-view
            class="info-list"
            scroll-y
            scroll-with-animation
            >
            <view class="list-item u-flex u-col-center" v-for="item in teamList" :key="item.member_id">
                <image :src="item.face" alt="" class="user-img" v-if="item.face"/>
                <image src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-noface.jpg" alt="" class="user-img" v-else/>
                <view class="item-info ">
                    <view class="name" v-if="item.uname">{{item.uname}}</view>
                    <view class="name" v-else>{{item.name}}</view>
                    <view class="detail">
                        <text style="margin-right: 30rpx;">{{item.level}}</text>
                        <text>{{item.name === null ? '普通会员' : '分销商'}}</text>
                    </view>
                    <view class="detail">
                        <text style="margin-right: 30rpx;">{{item.bind_time | unixToDate()}}</text>
                        <text>下级成员：{{item.number === null ? 0 : item.number}}人</text>
                    </view>
                </view>
            </view>
        </scroll-view>
	</view>
</template>

<script>
    import * as API_Distribution from '@/api/distribution'

	export default {
        data() {
        	return {
                teamCount: [
                    { label: '团队总人数', count: 0 },
                    { label: '一级成员', count: 0 },
                    { label: '二级成员', count: 0 },
                ],
                teamList: []
        	};
        },
        onShow() {
            this.getDistributionUserInfo()
            this.getDistributionChildren()
        },
		methods: {
            /** 获取分销商数据 */
            getDistributionUserInfo() {
                API_Distribution.getDistributionUserInfo().then(res => {
                    this.teamCount[0].count = res.child_team_count_lv1 + res.child_team_count_lv2 + 1
                    this.teamCount[1].count = res.child_team_count_lv1
                    this.teamCount[2].count = res.child_team_count_lv2
                })
            },
            /** 获取下级分销商数据 */
            getDistributionChildren() {
                API_Distribution.getDistributionChildren().then(res => {
                    this.teamList = res.data
                    console.log(this.teamList)
                })
            }

		}
	}
</script>

<style lang="scss" scoped>
.distribution-team-wrap {
    .info-list {
        background: #fff;
        padding: 30rpx;
        box-sizing: border-box;
        .list-item {
            margin-bottom: 40rpx;
            .user-img {
                width: 80rpx;
                height: 80rpx;
                border-radius: 50%;
                margin-right: 40rpx;
            }
            .name {
                font-weight: 500;
                color: #333;
                font-size: 30rpx;
                line-height: 60rpx;
            }
            .detail {
                color: #999;
            }
        }

    }
    .header-content {
        // height: 300rpx;
        padding: 60rpx 30rpx;
        box-sizing: border-box;
        background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
        .team-info {
            background: #fff;
            padding: 60rpx 0rpx;
            box-sizing: border-box;
            border-radius: 10rpx;
            font-weight: 500;
            .team-item {
                width: calc(100% / 3);
            }
            .item-label {
                color: #999;
                margin-bottom: 20rpx;
            }
            .number {
                font-size: 32rpx;
            }
        }
    }
}
</style>
