<template>
  <view class="invoice-address-container">
	<u-cell-group :border="false">
	  <u-field required label="收票人" v-model="addressForm.member_name" placeholder="请输入收票人姓名" :maxlength="20" />
	  <addressFiled
		  :defaultForm="addressForm"
      @handleCountry="handleCountry"
      @handlerRegionJson="handlerRegionJson"
    />
	  <u-form-item required labelPosition="left" label="手机号码" labelWidth="150" style="margin-left: 30rpx;">
		<view class="u-flex">
		  <area-select
			ref="areaSelect"
			:areaCode="addressForm.mobile_area_code">
		  </area-select>
		  <u-input v-model="addressForm.member_mobile" placeholder="请填写收货人手机号" />
		</view>
	  </u-form-item>
	  <u-field required label="详细地址" v-model="addressForm.detail_addr" placeholder="请输入详细地址" :maxlength="20" />
	</u-cell-group>
	<view class="big-btn" @click="handleSaveAddress">
	  <view class="btn">
		<text class="u-m-l-10">保存</text>
	  </view>
	</view>
  </view>
</template>

<script>
import * as API_Members from '@/api/members'
import { i18n as openI18n } from '@/config/config'
import areaSelect from '@/components/areaSelect/areaSelect'
import addressFiled from '@/components/addressFiled/addressFiled'
import { Foundation } from '@/app-utils/index.js'

export default {
	components: {
		areaSelect,
		addressFiled
	},
	data() {
		return {
			openI18n: openI18n,
			/** 收票地址 表单 */
			addressForm: {
        member_name: '',
        member_mobile: '',
        detail_addr: ''
			},
			regionJSon: ''
		};
	},
	mounted() {
		this.GET_InvoiceAddress()
	},
	methods: {
    /** 国家选择切换 */
    handleCountry(item) {
      this.$set(this.addressForm, 'mobile_area_code', item.tel)
    },
		/** 增加/修改收票人地址 */
		async handleSaveAddress() {
			// 数据处理
			const params = this.$u.deepClone(this.addressForm)
			const { mobile_regex, formatValid } = this.$refs.areaSelect
			const mobileReg = new RegExp(mobile_regex)
			params.member_mobile = this.$refs.areaSelect.mobileValue(params.member_mobile)
			params.region = this.regionJSon
			if (!params.member_name || !params.member_name.trim()) {
				this.$u.toast(`请输入收票人姓名`)
			} else if(!this.regionJSon) {
        this.$u.toast(`请选择收票人地区`)
      } else if(!params.member_mobile){
				this.$u.toast(`请输入收票人手机号码`)
			} else if (!mobileReg.test(formatValid(params.member_mobile))) {
				this.$u.toast(`请输入正确的手机号码`)
			} else if (!params.region && params.country_name === 'China') {
				this.$u.toast(`请选择所在地区`)
			} else if (!params.detail_addr || !params.detail_addr.trim()) {
				this.$u.toast(`请输入详细地址`)
			} else {
        if (params.id) {
          await API_Members.changeTicketAdress(params, params.id)
        } else {
          await API_Members.ticketAdressApply(params)
        }
        this.$u.toast(`保存成功`)
        setTimeout(() => {
          uni.navigateBack()
        }, 300)
			}
		},
		/** 查询收票人地址 */
		GET_InvoiceAddress() {
			API_Members.queryTicketAdress().then(res => {
				if (res) {
          const addressForm = this.$u.deepClone(Object.assign(this.addressForm, res))
					addressForm.addrs = `${res.province} ${res.city} ${res.county} ${res.town}`
					addressForm.region = res.town_id && res.town_id != 0 ? res.town_id : res.county_id
					const { areaCode, mobileValue } = Foundation.formatIn18Mobile(res.member_mobile)
					addressForm.member_mobile = mobileValue
					addressForm.mobile_area_code = areaCode
          this.addressForm = addressForm
				}
			}
		)},
    handlerRegionJson(obj) {
      this.regionJSon = obj
    }
	}
}

</script>

<style lang="scss" scoped>
::v-deep {
  .u-error-message {
	padding-left: 165rpx !important;
  }
}
</style>
