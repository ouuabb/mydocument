<template>
  <view class="distribution-team-wrap">
    <view class="header-content">
      <view class="header-box">
        <view class="count-box u-flex u-row-between">
          <view class="u-flex u-col-center">
            <text>总收益</text>
            <u-icon :name="showPrice ? 'eye-fill' : 'eye-off'" size="40" @click="showPrice = !showPrice"/>
          </view>
          <view class="withdrawal-btn" @click="handleWithdraw">提现</view>
        </view>
        <view class="price-count">{{ showPrice ? distributionDetail.total_commission : '****' }}</view>
        <view class="u-flex u-row-between">
          <view class="price-box">
            <view>待入账佣金</view>
            <view class="price">{{ showPrice ? distributionDetail.wait_commission : '****' }}</view>
          </view>
          <view class="price-box">
            <view>可提现佣金</view>
            <view class="price">{{ showPrice ? distributionDetail.total_income : '****' }}</view>
          </view>
        </view>
      </view>
    </view>


    <view class="filter-date u-flex u-col-center u-row-between">
      <view @click="showDatePicker = true" class="data-item">
        {{ dateText }}
        <u-icon name="arrow-down-fill" color="#999" style="margin-left: 20rpx;"/>
      </view>
      <view v-if="showListTotal">全部 <custom-price :price="listBrokerageTotal" textColor="#666" fontWeight="500"></custom-price><!-- {{ MixinUnitOfCurrency }}{{ listBrokerageTotal }} --></view>
    </view>

    <u-tabs
      :list="tabList"
      @change="changeTab"
      barWidth="60"
      fontSize="28"
      :current="currentTabIndex"
      itemWidth="calc(100% / 4)"
      activeColor="#5441bc"></u-tabs>

    <mescroll-uni
      class="list-content"
      ref="mescrollRef"
      :auto="false"
      top="560"
      isFixed
      @up="upCallback"
      @init="mescrollInit">
      <view class="list-item u-flex u-col-center u-row-between"
            v-for="item in listData"
            :key="item.id">
        <view
          class="user-info u-flex u-col-center">
          <image :src="item.member_avatar" alt="" class="user-img" v-if="item.member_avatar"/>
          <image src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-noface.jpg" alt="" class="user-img" v-else/>
          <view>
            <view class="name">{{ item.member_name }}</view>
            <view class="time">{{ item.create_time | unixToDate('yyyy.MM.dd') }}</view>
          </view>
        </view>
        <view>
          <view class="status">{{ item.commission_status | filterStatus }}</view>
          <view class="price-color" v-if="item.commission_status === 'CONFIRM'">+{{ item.commission }}</view>
          <view class="price" v-else-if="item.commission_status === 'WAIT'">+{{ item.commission }}</view>
          <view class="return-color" v-else-if="item.commission_status === 'RETURN'">-{{ item.commission }}</view>
          <view class="return-color" v-else-if="item.commission_status !== 'RETURN' && item.return_commission !== 0">
            -{{ item.return_commission }}
          </view>
        </view>
      </view>
    </mescroll-uni>
    <u-calendar v-model="showDatePicker" mode="range" @change="changeDate"></u-calendar>
  </view>
</template>

<script>
import * as API_Distribution from '@/api/distribution'
import { Foundation } from '@/app-utils/index.js'
import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins.js'

export default {
  mixins: [MescrollMixin],
  data() {
    return {
      tabList: [
        { name: '全部', code: '' },
        { name: '待入账', code: 'WAIT' },
        { name: '已入账', code: 'CONFIRM' },
        { name: '已退回', code: 'RETURN' }
        // { name: '已取消', code: 'CANCEL' },
      ],
      params: {
        commission_status: '',
        page_no: 1,
        page_size: 10,
        start_time: '',
        end_time: ''
      },
      showPrice: true, // 是否显示金额
      dateText: '', // 当前选择日期
      distributionDetail: {}, // 分销商详情
      showDatePicker: false, // 日期选择器显隐
      currentTabIndex: 0, // tab 选中索引
      listData: [], // 分佣列表
      listBrokerageTotal: 0,// 列表佣金金额统计
      showListTotal: false //是否展示列表金额总和
    }
  },
  onLoad() {
    this.initPage()
  },
  filters: {
    // 状态过滤器
    filterStatus(status) {
      switch (status) {
        case 'WAIT':
          return '待入账'
        case 'CONFIRM':
          return '已入账'
        case 'RETURN':
          return '已退回'
      }
    }
  },
  methods: {
    initPage() {
      const date = Foundation.getDateRange(new Date(), 6)
      this.dateText = `${date.startDate}-${date.endDate}`
      this.params.start_time = date.startTime
      this.params.end_time = date.endTime
      this.getDistributionUserInfo()
      this.getBrokerageTotal()
    },
    //上拉加载数据
    upCallback(page) {
      this.params.page_no = page.num
      this.getBrokerageList()
    },

    /** 提现 */
    handleWithdraw() {
      uni.navigateTo({
        url: '/mine-module/distribution/brokerageWithdraw'
      })
    },
    /** tab 切换 */
    changeTab(index) {
      this.showListTotal = index === 0 ? false : true
      this.currentTabIndex = index
      this.params.commission_status = this.tabList[index].code
      this.params.page_no = 1
      this.listData = []
      this.getBrokerageList()
      this.getBrokerageTotal()
    },

    /** 日期选中回调 */
    changeDate(data) {
      const { startYear, startMonth, startDay, endYear, endMonth, endDay } = data
      // 起始日期为当日00:00
      const start = (new Date(`${startYear}/${startMonth}/${startDay}`).getTime() / 1000)
      // 结束日期为当日23:59
      const end = (new Date(`${endYear}/${endMonth}/${endDay}`).getTime() / 1000) + 24 * 3600 - 1

      this.dateText = `${startYear}.${startMonth}.${startDay}.${endYear}.${endMonth}.${endDay}`

      this.params = {
        page_no: 1,
        page_size: 10,
        start_time: start,
        end_time: end
      }
      this.listData = []
      this.getBrokerageList()
      this.getBrokerageTotal()
    },
    /** 获取列表金额统计 */
    getBrokerageTotal() {
      const params = this.$u.deepClone(this.params)
      params.status = params.commission_status
      delete params.commission_status
      API_Distribution.getBrokerageTotal(params).then(res => {
        this.listBrokerageTotal = res
      })
    },
    /** 获取分销商数据 */
    getDistributionUserInfo() {
      API_Distribution.getDistributionUserInfo().then(res => {
        res.allCount = res.order_count_lv1 + res.order_count_lv2
        res.allAmount = (res.order_amount_lv1 + res.order_amount_lv2)
        this.distributionDetail = res
      })
    },
    /** 获取分销订单数据 */
    getBrokerageList() {
      API_Distribution.getBrokerageList(this.params).then(res => {
        if (res.data.length) {
          this.listData = this.listData.concat(res.data)
        }
        this.mescroll.endBySize(res.data.length, res.data_total)
      })
    }

  }
}
</script>

<style lang="scss" scoped>
.distribution-team-wrap {
  .list-content {
    margin-top: 30rpx;
    background: #fff;
    .list-item {
      height: 160rpx;
      padding: 0 30rpx;
      box-sizing: border-box;
      border-bottom: 1px solid #efefef;
      font-weight: 500;
      .user-img {
        width: 50rpx;
        height: 50rpx;
        border-radius: 50%;
        margin-right: 20rpx;
      }
      .name {
        color: #333;
        margin-bottom: 10rpx;
      }
      .time {
        font-size: 26rpx;
        color: #999;
      }
      .price {
        font-size: 28rpx;
        color: #5ccb81;
      }
      .price-color {
        color: rgb(77, 55, 255) !important;
      }
      .return-color {
        color: rgb(252, 80, 81) !important;
      }
      .status {
        color: #333;
        margin-bottom: 10rpx;
      }
    }
  }
  .filter-date {
    height: 100rpx;
    padding: 0 30rpx;
    color: #666;
    font-weight: 500;
    .data-item {
      background: #fff;
      border-radius: 20rpx;
      padding: 0 20rpx;
      height: 50rpx;
      line-height: 50rpx;
    }
  }
  .header-content {
    padding: 30rpx 30rpx;
    box-sizing: border-box;
    background: #fff;
    .header-box {
      padding: 30rpx 30rpx;
      box-sizing: border-box;
      color: #fff;
      border-radius: 20rpx;
      box-shadow: 0 10rpx 20rpx rgba(0, 0, 0, 0.3);;
      background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
    }
    .count-box {
      font-size: 26rpx;
      font-weight: 500;
    }
    .withdrawal-btn {
      color: rgb(77, 55, 255);
      background: #fff;
      padding: 10rpx 36rpx;
      border-radius: 30rpx;
      margin-right: 10rpx;
    }
    .price-count {
      font-size: 46rpx;
      font-weight: 500;
      margin: 20rpx 0;
    }
    .price-box {
      width: 50%;
      font-weight: 500;
      font-size: 26rpx;
      .price {
        font-size: 30rpx;
        margin-top: 10rpx;
      }
    }
  }
}
</style>
