<template>
	<view class="distribution-user-add">
        <u-form :model="userInfo" ref="userInfoRef" :rules="rules">
            <u-form-item label="姓名：" label-width="100" prop="name">
                <u-input v-model="userInfo.name" placeholder="请输入姓名"/>
            </u-form-item>
            <u-form-item label="手机号码：" label-width="160" prop="phone">
                <area-select ref="areaSelect"></area-select>
                <u-input v-model="userInfo.phone" maxlength="11"  placeholder="请输入手机号码"/>
            </u-form-item>
        </u-form>
        <view class="btn" @click="submit">确认提交</view>
        <u-toast ref="uToast" />
	</view>
</template>

<script>
    import * as API_Distribution from '@/api/distribution'
    import areaSelect from '@/components/areaSelect/areaSelect'
    import Cache, { Keys } from '@/utils/cache.js'

	export default {
        components: {
            areaSelect
        },
        data() {
        	return {
                userInfo: {},
                rules: {
                    name: {
                        type: 'string',
                        required: true,
                        message: '请填写姓名',
                        trigger: ['blur', 'change']
                    },
                    phone: {
                        type: 'string',
                        max: 11,
                        required: true,
                        message: '请填写电话',
                        trigger: ['blur', 'change']
                    }
                }
        	};
        },
        onReady() {
            this.$refs.userInfoRef.setRules(this.rules)
        },
        onShow() {

        },
		methods: {
            /** 分销商注册 */
            submit() {
                const userInfo = JSON.parse(JSON.stringify(this.userInfo))
                const { mobile_regex, formatValid } = this.$refs.areaSelect
                 const mobileReg = new RegExp(mobile_regex)

                if (!userInfo.name || !userInfo.phone) {
                    this.$refs.uToast.show({
                        title: '请完善表单信息'
                    })
                    return
                }
                if (!mobileReg.test(formatValid(userInfo.phone))) {
                    this.$u.toast(`手机号格式不对，请重新输入`)
                    return
                }

                userInfo.phone = this.$refs.areaSelect.mobileValue(userInfo.phone)

                API_Distribution.distributionRegister(userInfo).then(res => {
                    this.$refs.uToast.show({
                        title: '提交成功',
                        type: 'success'
                    })
                    setTimeout(() => {
                        uni.navigateBack()
                    }, 1500)
                })
            }
		}
	}
</script>

<style lang="scss" scoped>
.distribution-user-add {
    background: #fff;
    padding: 80rpx 40rpx;
    box-sizing: border-box;
    height: 100%;
    .btn {
        width: 100%;
        height: 80rpx;
        border-radius: 40rpx;
        text-align: center;
        color: #fff;
        font-size: 30rpx;
        line-height: 70rpx;
        margin: 40rpx 0 20rpx;
        background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
    }
}
</style>
