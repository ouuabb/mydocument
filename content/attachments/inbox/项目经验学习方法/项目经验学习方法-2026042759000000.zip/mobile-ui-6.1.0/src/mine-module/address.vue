<template>
  <view class="address-container">
    <mescroll-body ref="mescrollRef" @init="mescrollInit" :down="down" @down="downCallback" @up="upCallback">
      <u-empty v-if="!addressList.length" imageName="not-address.png" text="暂无收货地址" mode="list" marginTop="200"></u-empty>
      <uni-swipe-action>
        <uni-swipe-action-item
          v-for="(item, index) in addressList"
          :key="index"
          :right-options="item.def_addr ? optionsOne : optionsTwo"
          @click="handleAddress($event, index, item.def_addr)"
        >
          <addr
            style="width: 100%;"
            :name="item.name"
            :mobile="item.mobile"
            :addr_id="item.addr_id"
            :addr="item.addr"
            :addrs="MixinFormatRegions(item)"
            :def_addr="item.def_addr"
            :tag_name="item.ship_address_name"
            :right_icon="'edit-pen'"
            @editAddress="handleEditAddress"
            @selectAddress="handleSelectAddress(item)"
          ></addr>
        </uni-swipe-action-item>
      </uni-swipe-action>
    </mescroll-body>
    <view class="big-btn add-address address">
      <navigator class="btn" hover-class="none" url="/mine-module/addressAdd">
        <u-icon name="plus" size="32"></u-icon>
        <text class="u-m-l-10">新建收货地址</text>
      </navigator>
    </view>
  </view>
</template>

<script>
import * as API_Address from '@/api/address.js'
import * as API_Trade from '@/api/trade.js'
import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins.js'

export default {
  mixins: [MescrollMixin],
  data() {
    return {
      addressList: [], //地址列表
      from: '', //页面来源
      optionsOne: [
        {
          text: '删除',
          style: {
            backgroundColor: '#fa3534',
            'font-size': '22rpx',
            'font-weight': '600'
          }
        }
      ],
      optionsTwo: [
        {
          text: '设为默认',
          style: {
            backgroundColor: '#f6f6f6',
            color: '#3a3a3a',
            'font-size': '22rpx',
            'font-weight': '600'
          }
        },
        {
          text: '删除',
          style: {
            backgroundColor: '#fa3534',
            'font-size': '22rpx',
            'font-weight': '600'
          }
        }
      ],// 操作列表
      down: {
        auto: false //是否在初始化完毕之后自动执行一次下拉刷新的回调
      } //下拉刷新的配置参数
    }
  },
  onLoad(options) {
    this.from = options.from
  },
  onShow() {
    this.downCallback()
  },
  methods: {
    downCallback() {
      this.addressList = []
      this.getAddressList()
    },
    upCallback(page) {
      this.mescroll.endErr()
    },
    //获取地址列表
    getAddressList() {
      API_Address.getAddressList().then(response => {
        this.addressList = response
        this.mescroll.endSuccess(response.length)
      })
    },
    //编辑地址
    handleEditAddress(addr_id) {
      uni.navigateTo({
        url: '/mine-module/addressAdd?addr_id=' + addr_id
      })
    },
    //选择地址
    handleSelectAddress(item) {
      if (this.from === 'checkout') {
        API_Trade.setAddressId(item.addr_id).then(() => {
          uni.navigateBack()
        })
      }
    },
    //左滑设置默认，删除地址事件
    handleAddress($event, index, defaddr) {
      const addr_id = this.addressList[index].addr_id
      if (defaddr) {
        API_Address.deleteAddress(addr_id).then(() => {
          uni.showToast({ title: '成功' })
          this.getAddressList()
        })
      } else {
        if ($event.index === 0) {
          API_Address.setDefaultAddress(addr_id).then(() => {
            uni.showToast({ title: '设置成功' })
            this.getAddressList()
          })
        } else {
          API_Address.deleteAddress(addr_id).then(() => {
            uni.showToast({ title: '成功' })
            this.getAddressList()
          })
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.address-container {
  position: relative;
  .add-address {
    position: absolute;
    bottom: 60rpx;
    width: 100%;
  }
}
.address {
  margin-bottom: -45rpx;
}
::v-deep.mescroll-body {
  padding-bottom: 60px !important;
}
</style>
