<template>
	<view class="footprint-container">
        <view class="footprint-edit" v-if="footPrintsList && footPrintsList.length">
          <text v-if="!isEdit" class="u-m-r-15" @click="handleClearFootPrints">清空</text>
          <text v-if="!isEdit" class="u-m-r-15" style="color: #f40; margin-left: 20rpx;" @click="handleEditFootPrints">编辑</text>
          <text v-if="isEdit" @click="handleFinishedFootPrints">完成</text>
        </view>
        <mescroll-body ref="mescrollRef" :down="down" @init="mescrollInit" @down="downCallback" @up="upCallback">
            <view v-for="(item, index) in footPrintsList" :key="index" >
                <view class="u-border-bottom footprint-item">
                    <view class="footDate">{{ item.time | unixToDate('MM-dd') }}</view>
                    <view class="goods-box">
                        <view
                            class="goods-item"
                            v-for="(goods, _index) in item.history" :key="_index">
                            <view class="img-box" @click="toGoodsInfo(goods.goods_id)">
                                <image class="goods-img" :src="goods.goods_img" alt=""/>
                            </view>
                            <view class="goods-name">{{goods.goods_name}}</view>

                            <view class="good-check u-flex u-row-between">
                                <custom-price :price="goods.goods_price" :size="32" :fontWeight="600"></custom-price>
                                <u-icon
                                    v-if="isEdit"
                                    @click="handleChangeCheck(goods)"
                                    :color="goods.checked ? '#FA3534' : '#999'"
                                    size="38" :name="goods.checked ? 'xuanze' : 'choose'"
                                    custom-prefix="custom-icon"></u-icon>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </mescroll-body>
        <view class="settlement u-flex u-row-between" v-if="isEdit">
            <view class="u-flex" @click="handleCheckAll">
                <u-icon :color="checkedAll ? '#FA3534' : ''" size="38" :name="checkedAll ? 'xuanze' : 'choose'" custom-prefix="custom-icon"></u-icon>
                <text class="u-m-l-10">全选</text>
            </view>
            <view class="del-btn" @click="handleDeleteAll">删除</view>
        </view>
        <loading-view v-if="loading"></loading-view>
	</view>
</template>

<script>
	// 引入mescroll-mixins.js
	import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";
	import * as API_Members from '@/api/members.js';
	export default {
		mixins: [MescrollMixin], // 使用mixin
		data() {
			return {
				footPrintsList: [],
				down: {
				    auto: false //是否在初始化完毕之后自动执行一次下拉刷新的回调
				},
				params: {
					page_no: 0,
					page_size: 10
				},
                isEdit: false, // 是否是编辑状态
                checkedAll: false, // 是否全选
                loading: true
			};
		},
		onLoad() {
			// 页面返回刷新
			uni.$on('goodsback', () => {
			    this.downCallback()
			});
		},
		methods:{
            /** 查看商品详情 */
            toGoodsInfo(goods_id) {
                uni.navigateTo({
                    url: `/goods-module/goods?goods_id=${goods_id}`
                })
            },
			// 下拉刷新
			downCallback() {
				this.params.page_no = 1
				this.footPrintsList = []
				this.mescroll.resetUpScroll(true)
			},
			// 上拉加载
			upCallback(page) {
				this.params.page_no = page.num
				this.getFootprints()
			},
			// 获取我的足迹列表
			getFootprints(){
				API_Members.queryHistoryList(this.params).then(res => {
					const { data } = res
					data.forEach(key => {
						key.history.forEach(item => {
                            item.checked = false
						})
					})
                    this.loading = false
					this.footPrintsList.push(...data)
					this.mescroll.endBySize(data.length, res.data_total)
				})
			},
            // 清空我的足迹
            handleClearFootPrints() {
                API_Members.clearHistoryList().then(_ => {
                    this.footPrintsList = []
                    this.downCallback()
                })
            },
            // 编辑我的足迹
            handleEditFootPrints() {
                this.isEdit = true
            },
            // 编辑完成
            handleFinishedFootPrints() {
                this.isEdit = false
                this.checkedAll = false
            },
            // 点击勾选/不勾选
            handleChangeCheck(goods) {
                goods.checked = !goods.checked
                // 检测是否全选
                const isCheckedAll = this.footPrintsList.every(key => {
                  return key.history.every(item => item.checked)
                })
                // 如果是全选
                this.checkedAll = isCheckedAll
            },
            // 执行全选
            handleCheckAll() {
                this.checkedAll = !this.checkedAll
                this.footPrintsList.forEach(key => {
                    key.history.forEach(item => {
                        item.checked = this.checkedAll
                    })
                })
            },
            // 删除选择
            handleDeleteAll() {
                this.footPrintsList.forEach(key => {
                    key.history.forEach(item => {
                        if(item.checked) {
							API_Members.deleteHistoryListId(item.id).then( res => {
								this.downCallback()
                            })
                        }
                    })
                })
                this.handleFinishedFootPrints()
            }
		}
	}
</script>

<style lang="scss">
.footprint-container {
    background: #f5f5f5;
    .footprint-item {
        background: #fff;
        border-radius: 30rpx;
        margin-bottom: 30rpx;
        padding: 30rpx;
        .goods-box {
            display: flex;
            flex-wrap: wrap;
        }
        .goods-item {
            width: calc(100% / 3 - 20rpx);
            margin: 0 10rpx 20rpx;
            .goods-name {
                min-height: 80rpx;
                display: -webkit-box;
                overflow: hidden;
                text-overflow: ellipsis;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
            }
            .img-box {
                width: 100%;
                padding-bottom: 100%;
                height: 0;
                position: relative;
            }

            .goods-img {
                width: 100%;
                height: 100%;
                position: absolute;
                top:0;
                left:0;
            }
        }
    }
}

.footDate {
    padding: 20rpx;
    color: #333;
    font-weight: 600;
}
.del-sku {
    background-color: #FA3534;
    width: 150rpx;
    color: #FFFFFF;
    font-weight: 600;
    justify-content: center;
}
.footprint-edit {
    background: #f5f5f5;
    text-align: right;
    padding-right: 20rpx;
    width: 100%;
    z-index: 99;
    height: 70rpx;
    line-height: 70rpx;
}
.settlement {
    position: fixed;
    z-index: 99;
    bottom: 0;
    left: 0;
    margin-top: 100rpx;
    background-color: #ffffff;
    height: 100rpx;
    width: 100%;
    padding-left: 20rpx;
    box-shadow: 0 10rpx 20rpx 0rpx #999;
    .del-btn {
        color: #FFFFFF;
        font-size: 30rpx;
        padding: 0 80rpx;
        height: 70rpx;
        border-radius: 40rpx;
        line-height: 70rpx;
        margin-right: 10rpx;
        background-color: #FA3534;
    }
}
</style>
