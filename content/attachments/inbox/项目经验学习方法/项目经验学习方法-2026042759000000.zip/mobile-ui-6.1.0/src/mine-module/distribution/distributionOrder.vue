<template>
  <view class="distribution-team-wrap">
    <!-- <view class="fix-top">

    </view> -->
    <view class="header-content u-flex u-col-center u-row-between">
      <view class="team-info">
        <view
          class="team-item">
          <view class="item-label">团队订单数量</view>
          <view class="number number-big">{{ distributionDetail.child_order_count }}</view>
        </view>
        <view class="u-flex u-col-center u-row-between item-box">
          <view
            class="team-item">
            <view class="item-label">一级订单</view>
            <view class="number">{{ distributionDetail.order_count_lv1 }}</view>
          </view>
          <view
            class="team-item">
            <view class="item-label">二级订单</view>
            <view class="number">{{ distributionDetail.order_count_lv2 }}</view>
          </view>
        </view>
      </view>
      <view class="team-info">
        <view
          class="team-item ">
          <view class="item-label">团队订单金额</view>
          <view class="number number-big">{{ distributionDetail.child_order_money }}</view>
        </view>
        <view class="u-flex u-col-center u-row-between item-box">
          <view
            class="team-item">
            <view class="item-label">一级订单</view>
            <view class="number">{{ distributionDetail.order_amount_lv1 }}</view>
          </view>
          <view
            class="team-item">
            <view class="item-label">二级订单</view>
            <view class="number">{{ distributionDetail.order_amount_lv2 }}</view>
          </view>
        </view>
      </view>
    </view>
    <view class="filter-date u-flex u-col-center u-row-between">
      <view @click="showDatePicker = true" class="data-item">
        {{ dateText }}
        <u-icon name="arrow-down-fill" color="#999" style="margin-left: 20rpx;"/>
      </view>
      <view v-if="showListTotal">全部 <custom-price :price="orderListTotal" textColor="#666" fontWeight="500"></custom-price><!-- {{ MixinUnitOfCurrency }}{{ orderListTotal }} --></view>
    </view>

    <u-tabs
      :list="tabList"
      @change="changeTab"
      barWidth="60"
      :current="currentTabIndex"
      itemWidth="calc(100% / 4)"
      activeColor="#5441bc"
    ></u-tabs>

    <mescroll-uni
      class="order-list"
      ref="mescrollRef"
      :auto="false"
      @up="upCallback"
      top="500"
      isFixed
      @init="mescrollInit">
      <view class="list-item" v-for="item in orderList" :key="item.order_sn">
        <view class="order-header u-flex u-col-center u-row-between">
          <text @click.stop="Foundation.copyText(item.order_sn)">
            订单编号：{{ item.order_sn }}
            <u-icon name="file-text"/>
          </text>
          <text class="order-status">{{ item.commission_status | filterStatus }}</text>
        </view>
        <view class="order-user u-flex u-col-center u-row-between">
          <view class="u-flex u-col-center">
            <text class="user-label">下单人：</text>
            <image :src="item.member_avatar" alt="" class="user-img" v-if="item.member_avatar"/>
            <image src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-noface.jpg" alt="" class="user-img" v-else/>
            <text>{{ item.member_name }}</text>
          </view>
          <text class="order-time">{{ item.order_create_time | unixToDate }}</text>
        </view>
        <view class="goods-info u-flex u-col-top">
          <image :src="item.goods_image" alt="" class="goods-img"/>
          <view class="right-box">
            <view class="goods-name">{{ item.goods_name }}</view>
            <view class="detail">
				<custom-price :price="item.goods_price" textColor="#666"></custom-price>
              <!--{{ item.goods_price | unitPrice }}--> x {{ item.goods_num }}
            </view>
            <view class="good-price u-flex u-col-center u-row-between">
              <view class="u-flex u-col-center">
                <view class="unit-label" style="display: flex;">实付
                  <!-- <text class="order-price">{{ item.goods_total_amount | unitPrice }}</text> -->
				  <custom-price class="order-price" :price="item.goods_total_amount" textColor="#999" :size="26"></custom-price>
                </view>
              </view>
              <view class="unit-label" style="display: flex;">佣金
                <!-- <text class="take-price">{{ item.commission | unitPrice }}</text> -->
				<custom-price class="take-price" :price="item.goods_total_amount" textColor="#5ccb81" :size="34" fontWeight="500"></custom-price>
              </view>
            </view>
            <view class="unit-label" style="display: flex; text-align: right;"
                  v-if="item.return_commission && item.return_commission !== 0">
              已退
              <!-- <text class="return-price">{{ item.return_commission | unitPrice }}</text> -->
			  <custom-price class="take-price" :price="item.return_commission" textColor="#d81e06" :size="34" fontWeight="500"></custom-price>
            </view>
          </view>
        </view>
      </view>
    </mescroll-uni>

    <u-calendar v-model="showDatePicker" mode="range" @change="changeDate"></u-calendar>
  </view>
</template>

<script>
import * as API_Distribution from '@/api/distribution'
import { Foundation } from '@/app-utils/index.js'
import MescrollMixin from '@/components/mescroll-uni/mescroll-mixins.js'

export default {
  mixins: [MescrollMixin],
  data() {
    return {
      Foundation,
      tabList: [
        { name: '全部', code: '' },
        { name: '待入账', code: 'WAIT' },
        { name: '已入账', code: 'CONFIRM' },
        { name: '已退回', code: 'RETURN' }
      ],
      params: {
        commission_status: '',
        page_no: 1,
        page_size: 10,
        start_time: '',
        end_time: ''
      },
      dateText: '', // 当前选择日期
      distributionDetail: {}, // 分销商详情
      showDatePicker: false, // 日期选择器显隐
      currentTabIndex: 0, // tab 选中索引
      orderList: [], // 订单列表
      orderListTotal: 0, // 当前查询列表佣金统计
      showListTotal: false //是否展示列表金额总和
    }
  },
  onLoad() {
    this.initPage()
  },
  filters: {
    // 状态过滤器
    filterStatus(status) {
      switch (status) {
        case 'WAIT':
          return '待入账'
        case 'CONFIRM':
          return '已入账'
        case 'RETURN':
          return '已退回'
      }
    }
  },
  methods: {
    initPage() {
      const date = Foundation.getDateRange(new Date(), 6)
      this.dateText = `${date.startDate}-${date.endDate}`
      this.params.start_time = date.startTime
      this.params.end_time = date.endTime
      this.getDistributionUserInfo()
      // this.getDistributionOrderList()
      this.getOrderListTotal()
    },
    /** tab 切换 */
    changeTab(index) {
      this.showListTotal = index === 0 ? false : true
      this.currentTabIndex = index
      this.params.commission_status = this.tabList[index].code
      this.params.page_no = 1
      this.orderList = []
      this.getDistributionOrderList()
      this.getOrderListTotal()
    },

    /** 日期选中回调 */
    changeDate(data) {
      const { startYear, startMonth, startDay, endYear, endMonth, endDay } = data
      // 起始日期为当日00:00
      const start = (new Date(`${startYear}/${startMonth}/${startDay}`).getTime() / 1000)
      // 结束日期为当日23:59
      const end = (new Date(`${endYear}/${endMonth}/${endDay}`).getTime() / 1000) + 24 * 3600 - 1

      this.dateText = `${startYear}.${startMonth}.${startDay}.${endYear}.${endMonth}.${endDay}`

      this.params = {
        page_no: 1,
        page_size: 10,
        start_time: start,
        end_time: end
      }
      this.orderList = []
      this.getDistributionOrderList()
      this.getOrderListTotal()
    },
    //上拉加载数据
    upCallback(page) {
      this.params.page_no = page.num
      this.getDistributionOrderList()
    },

    /** 获取列表佣金金额统计 */
    getOrderListTotal() {
      const params = this.$u.deepClone(this.params)
      params.status = params.commission_status
      delete params.commission_status

      API_Distribution.getOrderListTotal(params).then(res => {
        this.orderListTotal = res
      })
    },
    /** 获取分销商数据 */
    getDistributionUserInfo() {
      API_Distribution.getDistributionUserInfo().then(res => {
        this.distributionDetail = res
      })
    },
    /** 获取分销订单数据 */
    getDistributionOrderList() {
      API_Distribution.getDistributionOrderList(this.params).then(res => {
        if (res.data.length) {
          this.orderList = this.orderList.concat(res.data)
        }
        this.mescroll.endBySize(res.data.length, res.data_total)
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.distribution-team-wrap {
  .fix-top {
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
  }
  .order-list {
    margin-top: 20rpx;
    .list-item {
      margin-bottom: 30rpx;
      .order-header {
        color: #999;
        height: 80rpx;
        padding: 0 20rpx;
        background: #fff;
        font-weight: 500;
        .order-status {
          color: #5ccb81;
        }
      }
      .order-user {
        font-weight: 500;
        color: #999;
        height: 80rpx;
        padding: 0 20rpx;
        font-size: 26rpx;
        background: #f8f8f8;
        .user-label {
          color: #666;
        }
        .user-img {
          width: 40rpx;
          height: 40rpx;
          border-radius: 50%;
          margin-right: 10rpx;
        }
      }
      .goods-info {
        background: #fff;
        padding: 20rpx;
        box-sizing: border-box;
        width: 100%;
        .right-box {
          width: calc(100% - 180rpx);
        }
        .goods-img {
          width: 180rpx;
          height: 180rpx;
          margin-right: 20rpx;
        }
        .goods-name {
          color: #333;
          font-size: 30rpx;
          font-weight: 500;
        }
        .detail {
          color: #666;
          margin: 10rpx 0;
        }
        .good-price {
          color: #333;
          font-size: 34rpx;
          font-weight: 500;
        }
        .price-tag {
          margin-left: 20rpx;
          background: rgba(239, 235, 255, 1);
          color: #5441bc;
          font-size: 20rpx;
          border: 1px solid #5441bc;
          border-radius: 20rpx;
          padding: 0 10rpx;
        }
        .unit-label {
          font-weight: 400;
          color: #999;
          font-size: 26rpx;
          .order-price {
            font-weight: 500;
            font-size: 34rpx;
            color: #000000;
          }
          .take-price {
            font-weight: 500;
            font-size: 34rpx;
            color: #5ccb81;
          }
          .return-price {
            font-weight: 500;
            font-size: 34rpx;
            color: #d81e06;
          }
        }
      }
    }
  }
  .filter-date {
    height: 100rpx;
    padding: 0 30rpx;
    color: #666;
    font-weight: 500;
    .data-item {
      background: #fff;
      border-radius: 20rpx;
      padding: 0 20rpx;
      height: 50rpx;
      line-height: 50rpx;
    }
  }
  .header-content {
    padding: 40rpx 30rpx;
    box-sizing: border-box;
    height: 300rpx;
    background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
    .team-info {
      background: #fff;
      width: calc((100% / 2) - 20rpx);
      padding: 20rpx 20rpx;
      box-sizing: border-box;
      border-radius: 20rpx;
      .item-box {
        width: 100%;
      }
      .item-label {
        font-size: 26rpx;
        color: #999;
        font-weight: 500;
      }
      .number {
        font-size: 30rpx;
        margin: 10rpx 0 0;
        font-size: 30rpx;
      }
      .number-big {
        font-weight: 500;
        font-size: 36rpx;
      }
    }
  }
}
</style>
