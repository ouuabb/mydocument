<template>
  <view class="list-item none">
    <view class="contanier flex">
      <view class="flex u-font-20">
        [推荐人数] {{ model.downline }}
      </view>
      <view class="body-panel flex u-m-t-20 u-m-b-20">
        <view class="title">
          <text v-if="HasChild" class="arrow" :class="isOpenOrClose" @click="openExpand(model, num)"></text>
          <text class="t-icon m-dep"></text>
          {{ model.name }}
        </view>
        <view class="time" @click="handlelookDetails(model)">详情</view>
      </view>
      <view class="flex u-m-b-10 u-font-20">
        [返利]
        <!-- <text class="rebate_total u-m-t-2">{{ MixinUnitOfCurrency }}{{ model.rebate_total }}</text> -->
        <view class="rebate_total u-m-t-2">
			<custom-price :price="model.rebate_total"></custom-price>
		</view>
      </view>
    </view>
    <view class="box" v-if="HasChild && model.isExpand">
      <treeItem
        v-for="(m, i) in model.item"
        :num="i"
        @openExpand="openExpand"
        :model="m"
        :key="i">
      </treeItem>
    </view>
  </view>
</template>

<script>
import treeItem from './tree.vue'

export default {
  props: {
    model: {
      type: Object,
      default() {
        return {}
      }
    },
    num: {
      type: String,
      default: ''
    }
  },
  components: {
    treeItem
  },
  computed: {
    HasChild() {
      return this.model.item.length > 0
    },
    isOpenOrClose() {
      return this.model.isExpand ? 'open' : 'close'
    }
  },
  methods: {
    //打开下一级
    openExpand(m, i) {
      this.$emit('openExpand', m, i)
    },
    //详情
    handlelookDetails(m) {
      uni.navigateTo({
        url: '/mine-module/distribution/my-performance?member_id=' + m.id
      })
    }
  }
}
</script>

<style lang="scss">
.list-item {
  padding-right: 0;
  position: relative;
  .flex {
    display: flex;
    justify-content: flex-start;
  }
  .contanier {
    padding-left: 52rpx;
    padding-right: 20rpx;
    flex-direction: column;
    .body-panel {
      flex-direction: row;
      justify-content: space-between;
      .title {
        position: relative;
        .arrow {
          position: absolute;
          width: 0;
          height: 0;
          top: 8rpx;
          left: -26rpx;
          border-style: solid;
          z-index: 1;
          &.close {
            border-width: 12rpx 0 12rpx 12rpx;
            border-color: transparent transparent transparent #aaa;
          }
          &.open {
            top: 8rpx;
            border-width: 12rpx 12rpx 0;
            border-color: #aaa transparent transparent;
          }
        }
        .t-icon {
          display: inline-block;
          width: 36rpx;
          height: 36rpx;
          background-size: 100% 100% !important;
          vertical-align: middle;
          margin: -6rpx 4rpx 0 0;
          &.m-dep {
            background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAEa0lEQVRYR8WXbYhUZRTH//9xRGYyw+xDm4YLCRViQWJB9EYipVIEplaIHwLrQzTSuPd5ZnbZvEkv9z53WmFLaEtKiCIy+lCESUKkfojQrKAPkoJURiaWW+7MtrvznHiGOzFuOy/XXeh8unDP+Z/fPed5OZf4n41J8g8NDc0eHh5+SETWArgFwHUkL4jICZIHAexVSn2dRLNjAGPMZhEJSHa1SCAisjuTyfTkcrk/OwHpCCCKou0i4tcFRWQYgPvSYySvBHATgGUAZjsfETkFYL3W+kg7iLYAYRgWSb4YC4+S7Pc872WS0iheKpWusta+BmBd7HtuYmJiaV9f35lWEC0BSqXSCmvtV7HAaWvtfYVC4ftWgkEQbEmlUq/HPgeUUqsuGcAY4xbWnSJiZ82adWtPT8/RdiV1740xLwDodc8kH/Q87+NmcU0rsHPnzq7x8fFf4nK+r7Xe2Ely5+P7fjqbzZ4AsFhEPtRa19oylTUFMMY8CuBdF2StXVMoFPZ1CuD8wjB06yQvImWl1NzJa6au1QqgB0DkHNPp9IJ8Pv97EgBjzBMAhuL4Rfl8/nTSCrgeul6iXC7P9n1/IglAFEWbROTtOGaJUupkUoB/WyAiN2itjycBCMOwn+QOANXu7u45GzZsqCYCKJVKy621tYNERJTWutaOTs0Y47bvCgDfKaVuTrwIRYRRFP3gznsROVetVm/s7e092wlAEAR3pVKpL2LfnFLqlcQALsAY8xSAV+MqHK5UKqt83x9tBTE4ODivUqkcJbkEwPlyubzQ9/3yJQHEt99nAO6OIY6TfKzZjRcEwTKSe0le73oPYKVSql6JZOdA3Tv+osMk3WXj1oMl+QmAIySPAfjLWjuP5D0i8jTJtEsuIlu01m+1a1nby8gJRFF0mbV2D8mH2wmKyFmS65RSh9r5uvcdAQwMDGSq1epma+0AyWwrYRG5AGBPOp0227Zt+6kdRFuAIAjWknxjikHkPIBTbgIB0E1y/qRk5621jxQKhf2tIFoCGGOeA/BsXUBEvgXgttR+rfXPjcJhGC4SkdUkt5Jc2rBetiil3ky8CxqvVBFxg8hWz/NcJS4aRCYL+76fymazT4pISPLy+H2fUqo21Ey2KSsQRdEDIvJR7PxrtVpdUywW3Yrv2MIwvIak01geB7lK7G4LEATBFSRPklwAoALgdqXUNx1nbnB0M8XY2Jg7lLpExG3XxcVi8Y9Grf9UwBgzAOCZuIePd7KXW8E1VlNEXtJa1yalul0EMDg4OGd0dPQ3APNE5KDWunYCTtfCMDxE8g53p2QymYW5XO7vKQGMMfcDqE0+IrJJa/3OdJO7+EmzwWql1KdTAoRhuMON3S6/tXZ+oVBw8/+0bdeuXXNHRkbcj4qreEkp5TWrwHsANorIGa311dPO3CBgjPkRwLUi8oHWen2zChwgudL99Sil6ttnRjiMMV8CuE1EPtda39sMoDZGkfQ9z3On4IxZGIY+ye0A+pVSz08JMGPZEgj9Ax+gBD/Qa+wWAAAAAElFTkSuQmCC);
          }
        }
      }
      .time {
        font-size: 28rpx;
        color: #ff853f;
      }
    }
    .rebate_total {
      color: #df3a01;
    }
  }
  .box {
    display: block;
    padding-left: 108rpx;
    box-shadow: none;
    .list-item {
      &.node:not(:last-child) .line {
        content: '';
        display: block;
        background-color: #ddd;
        position: absolute;
        width: 1rpx;
        height: 100%;
        left: -72rpx;
        top: -76rpx;
      }
      &::after, &::before {
        content: '';
        display: block;
        background-color: #ddd;
        position: absolute;
      }
      &::before {
        width: 2rpx;
        height: 140rpx;
        left: -72rpx;
        top: -80rpx;
      }
      &::after {
        width: 96rpx;
        height: 2rpx;
        left: -70rpx;
        top: 60rpx;
      }
    }
  }
}
</style>
