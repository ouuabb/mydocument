<template>
  <view class="help-center-details-container">
    <rich-text :nodes="content" class="help-center-details"></rich-text>
  </view>
</template>

<script>
import * as API_Article from "@/api/article.js";
export default {
  data() {
    return {
      help_id: null,
      details_title: "帮助中心",
      content: "",
    };
  },
  onLoad(options) {
    if (options.help_id != null) {
      this.help_id = options.help_id;
      this.details_title = options.details_title;
      this.getHelpCenterDetails(this.help_id);
      uni.setNavigationBarTitle({
        title: this.details_title
      })
    }
  },
  methods: {
    //获取帮助中心文章
    getHelpCenterDetails(id) {
      API_Article.getArticleDetail(id).then((response) => {
        this.content = response.content || ''
      });
    },
  },
};
</script>

<style lang="scss">
</style>