<template>
    <view class="change-password-container">
        <u-gap height="40" bg-color="#FFFFFF"></u-gap>
        <view class="valid-mobile" v-show="step === 1">
            <u-form :model="validMobileForm" ref="validMobileForm">
                <u-form-item label-position="top">
                    <u-input v-model="bindMobile" disabled label="已验证手机" placeholder="请输入手机号" maxlength="11" />
                </u-form-item>
                <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
                    <u-input v-model="validMobileForm.captcha" placeholder="请输入图片验证码" maxlength="4" clearable />
                    <u-image slot="right" width="150" height="70" :src="valid_img_url" @click="getValidImgUrl"></u-image>
                </u-form-item>
                <u-form-item label-position="top">
                    <u-input v-model="validMobileForm.sms_code" placeholder="请输入短信验证码" maxlength="6" clearable />
                    <u-button slot="right" type="error" size="mini" @click="getCode">{{codeTips}}</u-button>
                    <u-verification-code seconds="60" ref="uCode" @change="codeChange"></u-verification-code>
                </u-form-item>
            </u-form>
            <u-button :disabled="val_disabled_mobile" class="u-m-20" type="error" shape="circle" @click="submitValMobileForm">提交校验</u-button>
        </view>
        <view class="change-password" v-show="step === 2">
            <u-form :model="changePasswordForm" ref="changePasswordForm">
                <u-form-item label-position="top">
                    <u-input v-model="changePasswordForm.password" placeholder="请输入6-20位英文或数字密码" type="password"
                        maxlength="20" clearable />
                </u-form-item>
                <u-form-item label-position="top">
                    <u-input v-model="changePasswordForm.rep_password" placeholder="请确认密码" type="password" maxlength="20"
                        clearable />
                </u-form-item>
                <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
                    <u-input v-model="changePasswordForm.captcha" placeholder="请输入图片验证码" maxlength="4" clearable />
                    <u-image slot="right" width="150" height="70" :src="valid_img_url" @click="getValidImgUrl"></u-image>
                </u-form-item>
            </u-form>
            <u-button :disabled="val_disabled_password" class="u-m-20" type="error" shape="circle" @click="submitChangeForm">修改密码</u-button>
        </view>
        <u-toast ref="uToast" />
        <!-- 腾讯天御验证码-小程序 -->
        <!-- #ifdef MP-WEIXIN -->
        <t-captcha
            id="captcha"
            :app-id="validator.tencent.mini_captcha_app_id"
            @verify="handlerVerify"
            @ready="handlerReady"
            @close="handlerClose"
            @error="handlerError" />
        <!-- #endif -->
    </view>
</template>

<script>
    import * as API_Common from '@/api/common.js'
    import * as API_Safe from '@/api/safe.js'
    import Cache, {
        Keys
    } from '@/utils/cache.js';
    import {
        Foundation,
        RegExp
    } from '@/app-utils/index.js'
    import md5Libs from '@/uview-ui/libs/function/md5.js'


    export default {
        data() {
            return {
                uuid: Cache.getItem('uuid'),
                step: 1,
                codeTips: '获取验证码',
                validMobileForm: {
                    captcha: '',
                    sms_code: ''
                },
                valid_img_url: '',
                changePasswordForm: {
                    password: '',
                    rep_password: '',
                    captcha: ''
                },
                // 验证类型
                validator: {}
            };
        },
        onLoad() {
            this.$nextTick(this.getValidImgUrl)
			const mobile = Foundation.secrecyMobile(Cache.getItem('user').mobile);
			if(mobile == 'null'){
				this.step = 2;
			}
            this.getValidator()
        },
        computed: {
            bindMobile() {
                const mobile = Foundation.secrecyMobile(Cache.getItem('user').mobile);
                return mobile=='null'?"":mobile;
            },
            /** 校验手机号 按钮是否禁用 */
            val_disabled_mobile() {
                const {
                    captcha,
                    sms_code
                } = this.validMobileForm
                if (this.validator.validator_type === 'IMAGE') {
                    return !(captcha && sms_code)
                }
                return !sms_code
            },
            /** 修改密码 按钮是否禁用 */
            val_disabled_password() {
                const {
                    password,
                    rep_password,
                    captcha
                } = this.changePasswordForm
                if (this.validator.validator_type === 'IMAGE') {
                    return !(password && rep_password && captcha)
                }
                return !(password && rep_password)
            }
        },
        methods: {
            /** 获取验证码方式 */
            getValidator(){
                API_Common.getValidator().then(res => {
                    this.validator = res
                })
            },
            /** 获取图片验证码URL */
            getValidImgUrl() {
                this.valid_img_url = API_Common.getValidateCodeUrl(this.uuid, this.step === 1 ? 'VALIDATE_MOBILE' :
                    'MODIFY_PASSWORD')
            },
            /** 发送验证码  */
            sendMobileSms() {
                const { uuid } = this
                const { captcha, randstr, ticket } = this.validMobileForm
                const validator_type = this.validator.validator_type

                if (validator_type === 'IMAGE' && !captcha) {
                    this.$u.toast('请填写图片验证码')
                    return
                }
                const params = {
                    uuid,
                    scene: 'VALIDATE_MOBILE'
                }
                if (validator_type === 'IMAGE') {
                    params.captcha = captcha
                } else if (validator_type === 'TENCENT') {
                    params.randstr = randstr
                    params.ticket = ticket
                }
                API_Safe.sendMobileSms(params).then(res => {
                    this.$u.toast('验证码已发送')
                    this.$refs.uCode.start()
                }).catch(this.getValidImgUrl);
            },
            /** 获取验证码 */
            getCode() {
                if (this.$refs.uCode.canGetCode) {
                    const validator_type = this.validator.validator_type
                    //如果是图片验证码
                    if (validator_type === 'IMAGE') {
                        this.sendMobileSms()
                    } else if(validator_type === 'TENCENT') {
                        //如果是腾讯验证码
                        this.handlerTenCent(this.sendMsgCallback)
                    }
                } else {
                    this.$u.toast('倒计时结束后再发送')
                }
            },
            handlerTenCent(callback){
                // #ifdef H5
                try {
                    const captcha = new TencentCaptcha(this.validator.tencent.captcha_app_id, callback, {})
                    // 调用方法，显示验证码
                    captcha.show()
                } catch (error) {
                // 加载异常，调用验证码js加载错误处理函数
                this.loadErrorCallback()
                }
                // #endif

                // #ifdef MP-WEIXIN
                this.selectComponent('#captcha').show()
                // #endif
            },
            /** 图片滑动验证回调 */
            sendMsgCallback(res) {
                if (res.ret === 0) {
                    this.validMobileForm.randstr = res.randstr
                    this.validMobileForm.ticket = res.ticket
                    this.sendMobileSms()
                }
            },
            codeChange(text) {
                this.codeTips = text
            },
            /** 手机验证 */
            submitValMobileForm() {
                const {
                    sms_code
                } = this.validMobileForm
                if (!sms_code) {
                    this.$u.toast('请填写短信验证码')
                    return
                }
                API_Safe.validChangePasswordSms(sms_code).then(() => {
                    this.step = 2
                    this.getValidImgUrl()
                }).catch(this.getValidImgUrl)
            },
            /** 图片滑动验证回调 */
            submitCallback(res) {
                if (res.ret === 0) {
                    this.changePasswordForm.randstr = res.randstr
                    this.changePasswordForm.ticket = res.ticket
                    this.changePassword()
                }
            },
            /** 修改密码提交 */
            changePassword() {
                const { uuid } = this
                const validator_type = this.validator.validator_type
                const {
                    password,
                    captcha,
                    randstr,
                    ticket
                } = this.changePasswordForm
                const params = {
                    uuid,
                    password: md5Libs.md5(password),
                    scene: 'MODIFY_PASSWORD'
                }
                if (validator_type === 'IMAGE') {
                    params.captcha = captcha
                } else if (validator_type === 'TENCENT') {
                    params.randstr = randstr
                    params.ticket = ticket
                }

                API_Safe.changePassword(params).then(() => {
                    this.$refs.uToast.show({
                        title: '修改密码成功',
                        type: 'success',
                        callback: function(){
                            Cache.removeItem(Keys.user)
                            Cache.removeItem(Keys.uid)
                            Cache.removeItem(Keys.accessToken)
                            Cache.removeItem(Keys.refreshToken)
                            Cache.removeItem(Keys.wxauth)
                            Cache.removeItem(Keys.loginResult)
                            uni.reLaunch({ url: '/pages/auth/login' })
                        }
                    })
                }).catch(this.getValidImgUrl)
            },
            /** 修改密码 */
            submitChangeForm() {
                const {
                    password,
                    rep_password,
                    captcha
                } = this.changePasswordForm
                if (!RegExp.password.test(password)) {
                    this.$u.toast('密码格式不正确')
                    return
                }
                if (password !== rep_password) {
                    this.$u.toast('两次密码输入不一致')
                    return
                }

                const validator_type = this.validator.validator_type
                //如果是图片验证码
                if (validator_type === 'IMAGE') {
                    if (!captcha) {
                        this.$u.toast('请填写图片验证码')
                        return
                    }
                    this.changePassword()
                } else if(validator_type === 'TENCENT') {
                    //如果是腾讯验证码
                    this.handlerTenCent(this.submitCallback)
                }

            }
        }
    }
</script>

<style lang="scss" scoped>
    .change-password-container {

        .valid-mobile,
        .change-password {
            background-color: #FFFFFF;
            margin: 30rpx;
            border-radius: 20rpx;
            padding: 20rpx 40rpx;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
        }
    }
</style>
