<template>
	<view class="record-wrap">
        <mescroll-body
            class="order-list"
            ref="mescrollRef"
            :auto="false"
            @up="upCallback"
            @init="mescrollInit" >
            <view class="record-item" v-for="item in listData" :key="item.id">
                <view class="title u-flex u-col-center u-row-between">
                    <text>提现单号</text>
                    <text>{{item.withdraw_sn}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between" v-if="item.transfer_sn">
                    <text>转账单号</text>
                    <text>{{item.transfer_sn}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between">
                    <text>提现金额</text>
                    <!-- <text class="price">{{item.price | unitPrice}}</text> -->
					<custom-price class="price" :price="item.price" :size="26" textColor="rgb(77, 55, 255)"></custom-price>
                </view>
                <view class="text-item u-flex u-col-center u-row-between">
                    <text>提现状态</text>
                    <text style="font-weight: 500;">{{recordStatus(item.state)}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between">
                    <text>提现方式</text>
                    <text style="font-weight: 500;">{{withdrawWay(item.way)}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between">
                    <text>申请时间</text>
                    <text>{{item.create_time | unixToDate}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between" v-if="item.complete_time">
                    <text>完成时间</text>
                    <text>{{item.complete_time | unixToDate}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between" v-if="item.close_remark">
                    <text>关闭原因</text>
                    <text>{{item.close_remark}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between" v-if="item.fail_reason">
                    <text>失败原因</text>
                    <text>{{item.fail_reason}}</text>
                </view>
                <view class="text-item u-flex u-col-center u-row-between" v-if="item.audit_remark">
                    <text>审核备注</text>
                    <text>{{ item.audit_remark }}</text>
                </view>
            </view>
        </mescroll-body>
	</view>
</template>

<script>
    import * as API_Distribution from '@/api/distribution'
    import MescrollMixin from "@/components/mescroll-uni/mescroll-mixins.js";

	export default {
        mixins: [MescrollMixin],
        data() {
        	return {
                params: {
                    page_no: 1,
                    page_size: 10
                },
                listData: []
        	};
        },
        computed: {
            /** 账户详情 */
            accountInfo() {
                return (info) => {
                    return JSON.parse(info)
                }
            },
            recordStatus() {
                return (status) => {
                    switch(status) {
                        case ('WAIT_AUDIT'):
                            return '待审核'
                        case ('TRANSFERRING'):
                            return '转账中'
                        case ('AUDIT_PASS'):
                            return '待转账'
                        case ('AUDIT_FAIL'):
                            return '审核未通过'
                        case ('FINISHED'):
                            return '已完成'
                        case ('CLOSED'):
                            return '已关闭'
                        case ('TRANSFER_FAILED'):
                            return '提现失败'
                    }
                }
            },
            withdrawWay() {
                return (way) => {
                    switch(way) {
                        case ('ALIPAY'):
                            return '支付宝'
                        case ('WECHAT'):
                            return '微信'
                    }
                }
            }
        },

		methods: {
            /** 上拉加载数据 */
            upCallback (page){
                this.params.page_no = page.num;
                this.getWithdrawRecord()
            },

            /** 获取提现记录 */
            getWithdrawRecord() {
                API_Distribution.getWithdrawRecord(this.params).then(res => {
                    if (res.data.length) {
                        this.listData = this.listData.concat(res.data)
                    }
                    this.mescroll.endBySize(res.data.length, res.data_total)
                })
            }

		}
	}
</script>

<style lang="scss" scoped>
.record-wrap {
    .record-item {
        background: #fff;
        .title {
            padding: 10rpx 20rpx;
            box-sizing: border-box;
            border-top: 1px solid #efefef;
            color: #333;
            font-weight: 500;
        }
        .text-item {
            padding: 10rpx 20rpx;
            box-sizing: border-box;
            color: #999;
            font-size: 26rpx;
            .price {
                color: rgb(77, 55, 255);
            }
        }
    }
}
</style>
