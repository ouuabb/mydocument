<template>
  <view class="brokerage-wrap">
    <view class="header-content u-flex u-col-top u-row-between">
      <view class="total-price-content">
        <view>可提现金额</view>
        <view class="price">{{ distributionUserInfo.total_income }}</view>
      </view>
      <view class="log-btn" @click="handleRecord">提现记录</view>
    </view>
    <view class="brokerage-content">
      <view class="choose-type basic-box">
        <view>提现金额</view>
        <view class="u-flex u-col-center input-box">
          <text>{{ MixinUnitOfCurrency }}</text>
          <u-input placeholder="请输入提现金额" class="price-input" type="number" v-model="withdrawParams.price"/>
        </view>
        <view class="type-box">
          <view class="u-flex u-col-center u-row-between">
            <text>提现至</text>
            <view class="u-flex u-col-center" style="height: 70rpx;" @click="showTypeDialog = true">
              <text class="no-choice" v-if="!withdrawParams.way">请选择提现方式</text>
              <view v-else class="u-flex">
                <image src="./images/alipay.png" alt="" style="width: 50rpx; height: 50rpx; margin-right: 10rpx"
                       v-if="withdrawParams.way === 'ALIPAY'"/>
                <image src="./images/wechat.png" alt="" style="width: 40rpx; height: 50rpx; margin-right: 10rpx"
                       v-if="withdrawParams.way === 'WECHAT'"/>
                <text class="label">{{ withdrawParams.way === 'WECHAT' ? '微信零钱' : '支付宝账户' }}</text>
              </view>
              <u-icon name="arrow-right" size="24"/>
            </view>
          </view>
          <view class="u-flex u-col-center u-row-between account-box" v-if="withdrawParams.way === 'ALIPAY'">
            <text @click="handleShowSwitchAlipay" sf-text-rule="alipay_account">{{ selectAliPay ?
              `支付宝账号[${selectAliPay.account}]` : '暂无支付宝账号信息' }}
            </text>
            <view class="add-account" @click="showAddAccount = true">添加</view>
          </view>
        </view>
        <view class="withdraw-btn" @click="submitWithdraw">确认提现</view>
      </view>
      <view class="basic-box">
        <view>提现说明</view>
        <view v-for="item in ExplainContent" :key="item" class="explain-item">{{ item }}</view>
      </view>
    </view>

    <u-popup mode="bottom" border-radius="20" length="35%" v-model="showAddAccount">
      <view class="account-dialog-content ">
        <view class="title u-flex u-col-center u-row-center">添加支付宝</view>
        <view class="u-flex u-col-center input-box">
          <text>真实姓名：</text>
          <u-input placeholder="请输入真实姓名" class="price-input" v-model="aliPayParams.real_name"/>
        </view>
        <view class="u-flex u-col-center input-box">
          <text>支付宝账号：</text>
          <u-input placeholder="请输入支付宝账号" class="price-input" v-model="aliPayParams.account"/>
        </view>
        <view class="btn-box u-flex u-col-center u-row-around">
          <view class="close-btn btn u-flex u-col-center u-row-center" @click="showAddAccount = false">取消</view>
          <view class="confirm-btn btn u-flex u-col-center u-row-center" @click="addAccount">确定</view>
        </view>
      </view>
    </u-popup>

    <u-popup mode="bottom" border-radius="20" length="35%" v-model="showTypeDialog">
      <view class="dialog-content ">
        <view class="title u-flex u-col-center u-row-center"> 选择提现方式</view>
        <view class="radio-content">
          <u-radio-group v-model="radioValue" placement="column">
            <u-radio name="ALIPAY" activeColor="#9360ff">
              <view class="u-flex">
                <view class="img-box">
                  <image src="./images/alipay.png" alt="" style="width: 50rpx; height: 50rpx;"/>
                </view>
                <text class="label">支付宝账户</text>
              </view>
            </u-radio>
            <u-radio name="WECHAT" activeColor="#9360ff" v-if="isWechat">
              <view class="u-flex">
                <view class="img-box">
                  <image src="./images/wechat.png" style="width: 40rpx; height: 50rpx;" alt=""/>
                </view>
                <text class="label">微信零钱</text>
              </view>
            </u-radio>
          </u-radio-group>
        </view>
        <view class="btn-box">
          <view class="confirm-btn u-flex u-col-center u-row-center" @click="changeAccount">确定</view>
        </view>
      </view>
    </u-popup>

    <u-popup mode="bottom" border-radius="20" length="40%" v-model="showSwitchAlipay">
      <view class="dialog-content ">
        <view class="title u-flex u-col-center u-row-center"> 选择支付宝账号</view>
        <view class="radio-content">
          <u-radio-group v-model="selectAlipayValue" placement="column">
            <u-radio v-for="item in aliPayList" :key="item.id" :name="item.account" activeColor="#9360ff">
              <view class="u-flex">
                <text class="label">{{ item.real_name }}【{{ item.account }}】</text>
              </view>
            </u-radio>
          </u-radio-group>
        </view>
        <view class="btn-box">
          <view class="confirm-btn u-flex u-col-center u-row-center" @click="changeAlipayAccount">确定</view>
        </view>
      </view>
    </u-popup>
    <u-toast ref="uToast"/>
  </view>
</template>

<script>
import * as API_Distribution from '@/api/distribution'
import * as Openid from '@/api/openid'

const ExplainContent = [
  '1.单次最低提现1元，最高提现500元；',
  '2.每日最多可提现次数: 不限；每日最多提现金额: 20000元；',
  '3.提现结果请查收对应渠道服务通知；',
  '4.如有疑问请及时联系客服；'
]
export default {
  data() {
    return {
      ExplainContent,
      showTypeDialog: false, // 提现方式选择
      showAddAccount: false, // 添加支付宝账号
      radioValue: '',
      withdrawParams: {
        price: '', // 申请提现金额
        way: '' // 当前选择提现方式
      },
      aliPayList: [], // 当前用户已有支付宝提现方式
      aliPayParams: { // 添加支付宝账号参数
        account: '',
        real_name: ''
      },
      distributionUserInfo: {}, // 分销商数据
      showSwitchAlipay: false, // 支付宝账号切换弹窗
      selectAlipayValue: '', // 当前选中支付宝账号
      selectAliPay: null,
      openid: '' // 微信openId
    }
  },
  computed: {
    isWechat() {
      let isWechat = false
      // #ifdef H5
      isWechat = navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1
      // #endif

      // #ifdef MP-WEIXIN
      isWechat = true
      // #endif

      return isWechat
    }
  },
  onLoad(options) {
    this.getAliPayAccount()
    this.getDistributionUserInfo()
    let code = options.code || ''

    // #ifdef H5
    if (code) {
      // 根据微信授权回调code 获取openid
      this.loadH5OpenId(code)
    }
    // #endif

  },
  methods: {
    handleShowSwitchAlipay() {
      if (!this.selectAliPay) return
      this.showSwitchAlipay = true

    },
    /** 获取wei */
    loadMiniOpenId() {
      return new Promise((resolve, reject) => {
        Openid.fetchWeixinMiniOpenId().then(openid => {
          this.openid = openid
          resolve(openid)
        }).catch(e => {
          reject(null)
          this.$u.toast(`获取openid出现意外错误`)
        })
      })

    },
    loadH5OpenId(code = '') {
      if (code === '') {
        Openid.createRedirectUri().then(url => {
          location.href = url
        })
      } else {
        Openid.fetchWeiXinH5OpenId(code).then(openid => {
          this.openid = openid
        }).catch(e => {
          return this.$u.toast(`获取openid出现意外错误`)
        })
      }
    },
    /** 切换支付宝账号 */
    changeAlipayAccount() {
      this.selectAliPay = this.aliPayList.find(item => {
        if (item.account === this.selectAlipayValue) {
          return item
        }
      })
      this.showSwitchAlipay = false
    },
    /** 查看明细 */
    handleRecord() {
      uni.navigateTo({
        url: '/mine-module/distribution/withdrawRecord'
      })
    },
    /** 提现申请提交 */
    async submitWithdraw() {
      const { withdrawParams, selectAliPay, radioValue } = this
      if (!withdrawParams.price) {
        this.$u.toast('提现金额不能为空或0')
        return
      } else if (parseInt(withdrawParams.price) < 1) {
        this.$u.toast(`单次提现金额最少${this.MixinUnitOfCurrency}1`)
        return
      } else if (parseFloat(withdrawParams.price) > 500) {
        this.$u.toast(`单次提现不得超过${this.MixinUnitOfCurrency}500`)
        return
      } else if (parseFloat(withdrawParams.price) > parseFloat(this.distributionUserInfo.total_income)) {
        this.$u.toast('已超可提现金额')
        return
      }
      if (!withdrawParams.way) {
        this.$u.toast('请选择提现方式')
        return
      }
      if (radioValue === 'ALIPAY' && (!selectAliPay || !Object.keys(selectAliPay).length)) {
        this.$u.toast('请选择支付宝账号')
        return
      }
      let isWechatH5 = false
      // #ifdef H5
      isWechatH5 = navigator.userAgent.toLowerCase().indexOf('micromessenger') !== -1
      // #endif
      let client_type = ''
      // #ifdef APP-PLUS
      client_type = 'APP'
      // #endif
      // #ifdef H5
      client_type = 'H5'
      //如果微信内则传递 WECHAT_H5
      if (isWechatH5) {
        client_type = 'WECHAT_H5'
      }
      // #endif
      // #ifdef MP
      client_type = 'MINI'
      // #endif
      withdrawParams.client_type = client_type
      if (radioValue === 'ALIPAY') {
        withdrawParams.real_name = selectAliPay.real_name
        withdrawParams.account_info = selectAliPay.account
      } else if (radioValue === 'WECHAT') {
        let openid = this.openid
        // #ifdef H5
        if (!openid) {
          this.loadH5OpenId()
          return
        }
        // #endif

        // #ifdef MP-WEIXIN
        // 小程序获取openid
        openid = await this.loadMiniOpenId()
        // #endif

        withdrawParams.open_id = openid
      }
      API_Distribution.applyWithDraw(withdrawParams).then(res => {
        this.$refs.uToast.show({
          title: '提现成功',
          type: 'success'
        })
        this.getDistributionUserInfo()
        this.withdrawParams.price = ''
      })

    },
    /** 添加支付宝账号 */
    addAccount() {
      const aliPayParams = this.aliPayParams

      if (!aliPayParams.account || !aliPayParams.real_name) {
        this.$u.toast('请完善账户信息')
        return
      }
      API_Distribution.addAliPayAccount(aliPayParams).then(res => {
        this.$u.toast('添加成功')
        this.showAddAccount = false
        this.getAliPayAccount()
      })

    },
    /** 提现方式选中 */
    changeAccount() {
      this.withdrawParams.way = this.radioValue
      this.showTypeDialog = false
    },
    /** 获取用户支付宝账号 */
    getAliPayAccount() {
      API_Distribution.getAliPayAccount().then(res => {
        this.aliPayList = res
        this.selectAliPay = res[0]
        this.selectAlipayValue = res[0].account
      })
    },
    /** 获取分销商数据 */
    getDistributionUserInfo() {
      API_Distribution.getDistributionUserInfo().then(res => {
        if (res) {
          this.distributionUserInfo = res
        }
      })
    }

  }
}
</script>

<style lang="scss" scoped>
::v-deep {
  .u-radio {
    width: 100% !important;
    padding: 15px 10px;
    border-bottom: 1px solid #efefef;
  }
}
.brokerage-wrap {
  .input-box {
    border-bottom: 1px solid #efefef;
    padding: 20rpx 0;
    margin-bottom: 20rpx;
    ::v-deep .price-input {
      padding: 0 20rpx !important;
    }
  }
  .account-dialog-content {
    padding: 30rpx;
    .title {
      width: 100%;
      padding: 20rpx;
      font-weight: 500;
    }
    .btn-box {
      margin: 50rpx 0 0;
      .btn {
        width: 40%;
        height: 70rpx;
        border-radius: 30rpx;
      }
      .close-btn {
        border: 1px solid #efefef;
        color: #999;
      }
      .confirm-btn {
        color: #fff;
        background: linear-gradient(to left, rgb(77, 55, 255), rgb(148, 97, 255));
      }
    }
  }
  .dialog-content {
    .btn-box {
      padding: 0 30rpx;
      box-sizing: border-box;
      margin: 60rpx 0;
    }
    .confirm-btn {
      width: 100%;
      height: 75rpx;
      border-radius: 40rpx;
      color: #fff;
      background: linear-gradient(to left, rgb(77, 55, 255), rgb(148, 97, 255));
    }
    .title {
      width: 100%;
      padding: 20rpx;
      border-bottom: 1px solid #efefef;
      font-weight: 500;
    }
    .radio-content {
      padding: 20rpx;
      box-sizing: border-box;
    }
    .u-radio-group {
      width: 100% !important;
      .u-radio {
        width: 100% !important;
        padding: 30rpx 20rpx;
        border-bottom: 1px solid #efefef;
        .label {
          font-size: 26rpx !important;
        }
        .img-box {
          width: 50rpx;
          height: 50rpx;
          margin: 0 20rpx;
        }
      }
    }
  }
  .brokerage-content {
    padding: 0 20rpx;
    box-sizing: border-box;
    position: relative;
    top: -60rpx;
    .basic-box {
      background: #fff;
      border-radius: 10rpx;
      padding: 30rpx;
      box-shadow: 0 0 10rpx rgba(0, 0, 0, .1);
    }
    .explain-item {
      color: #999;
      font-size: 24rpx;
      margin-top: 20rpx;
    }
    .choose-type {
      margin-bottom: 20rpx;
      .type-box {
        font-size: 26rpx;
        height: 200rpx;
        .account-box {
          color: #999;
          margin-top: 20rpx;
          .add-account {
            padding: 10rpx 30rpx;
            background: #efefef;
            border-radius: 20rpx;
            text-align: center;
          }
        }
        .no-choice {
          color: #999;
        }
      }
      .withdraw-btn {
        text-align: center;
        line-height: 75rpx;
        height: 75rpx;
        width: 100%;
        border-radius: 40rpx;
        color: rgba(255, 255, 255, .7);
        box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, .2);
        background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
      }
    }
  }
  .header-content {
    height: 280rpx;
    padding: 60rpx 40rpx 0;
    box-sizing: border-box;
    background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
    color: #fff;
    .total-price-content {
      font-size: 26rpx;
    }
    .price {
      font-size: 46rpx;
      // font-weight: 500;
      margin-top: 20rpx;
    }
    .log-btn {
      background: rgba(255, 255, 255, .1);
      padding: 10rpx 30rpx;
      border: 1px solid #fff;
      border-radius: 30rpx;
      font-size: 26rpx;
    }
  }
}
</style>
