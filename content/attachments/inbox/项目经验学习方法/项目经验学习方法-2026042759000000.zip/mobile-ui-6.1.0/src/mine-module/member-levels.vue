<template>
  <view class="member-levels">
    <view v-for="item in memberLevels" :key="item.id" class="level-item">
      <view class="level-info">
        <view class="level-label">等级</view>
        <view class="level-value">
          <view class="level-box">
            <image mode="widthFix" class="level-icon" v-if="item.level_icon" :src="item.level_icon" alt="" />
            <image mode="widthFix" class="level-icon" v-else src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/level.png" alt="" />
            {{ item.level_name }}
          </view>
        </view>
      </view>
      <view class="level-info">
        <view class="level-label">升级条件</view>
        <view class="level-value">
          <view v-for="cond in item.upgrade_conditions" :key="item.id" class="condition-item">
            <view v-if="cond.condition_type === 'POINTS'">
              {{ cond.condition_value_min }} - {{ cond.condition_value_max }} 积分
            </view>
          </view>
        </view>
      </view>
      <view class="level-info">
        <view class="level-label">权益</view>
        <view class="level-value">
          <view v-for="ben in item.benefits" :key="item.id" class="benefit-item">
            <view v-if="ben.benefit_type === 'DISCOUNT'">消费折扣{{ ben.benefit_value }}%</view>
          </view>
        </view>
      </view>
      <view class="level-info">
        <view class="level-label">等级说明</view>
        <view class="level-value">
          <u-button
            type="error"
            size="mini"
            shape="circle"
            class="desc-btn"
            @click="viewDesc(item)"
          >查看</u-button>
        </view>
      </view>
    </view>
    <u-popup
      v-model="descPopupShow"
      mode="bottom"
      safe-area-inset-bottom
      closeable
      :border-radius="20"
    >
      <view class="content">
        <view class="level-popup-title">等级详情</view>
        <scroll-view scroll-y="true" class="level-popup-scroll-view">
          <view class="level-popup-content">
            <u-parse :html="currenLevel.description"/>
          </view>
          <view class="bottom-place"/>
        </scroll-view>
      </view>
    </u-popup>
  </view>
</template>

<script>
import * as API_Members from '@/api/members'

export default {
  name: 'member-levels',
  data() {
    return {
      memberLevels: '',
      descPopupShow: false,
      currenLevel: ''
    }
  },
  onLoad() {
    this.getMemberLevels()
  },
  methods: {
    async getMemberLevels() {
      uni.showLoading({ title: '请稍后...', mask: true })
      this.memberLevels = await API_Members.getMemberLevels()
    },
    viewDesc(item) {
      this.currenLevel = item
      this.descPopupShow = true
    }
  }
}
</script>

<style scoped lang="scss">
.member-levels {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 24rpx;
  padding-top: 24rpx;
}
.level-item {
  width: calc(100% - 24rpx);
  background-color: #ffffff;
  padding: 0 24rpx;
  border-radius: 20rpx;
}
.level-info {
  display: flex;
  align-items: center;
  min-height: 88rpx;
  .level-label {
    width: 200rpx;
    flex-shrink: 0;
  }
  .level-value {
    flex: 1;
  }
  .desc-btn {
    min-width: 150rpx;
  }
}
.level-box {
  padding: 0 22rpx 0 15rpx;
  font-size: 24rpx;
  background: rgb(255, 191, 0);
  border-radius: 32rpx;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 80px;
  color: #ffffff;
  .level-icon {
    width: 35rpx;
    height: 35rpx;
    margin-right: 10rpx;
  }
}
.level-popup-title {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 80rpx;
  font-size: 28rpx;
  font-weight: bold;
}
.level-popup-scroll-view {
  min-height: 300rpx;
  max-height: 50vh;
}
.level-popup-content {
  width: 100%;
  padding: 0 24rpx;
  box-sizing: border-box;
}
</style>