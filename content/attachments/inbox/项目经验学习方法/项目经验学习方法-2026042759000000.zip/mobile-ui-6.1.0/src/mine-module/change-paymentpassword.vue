<template>
    <view class="change-paymentpassword-container">
        <u-gap height="40" bg-color="#FFFFFF"></u-gap>
        <view class="valid-mobile" v-show="step === 1">
            <u-form :model="validMobileForm" ref="validMobileForm">
                <u-form-item label-position="top">
                    <u-input v-model="validMobileForm.mobile" disabled label="已验证手机" placeholder="请输入手机号" maxlength="11" />
                </u-form-item>
                <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
                    <u-input v-model="validMobileForm.captcha" placeholder="请输入图片验证码" maxlength="4" clearable />
                    <u-image slot="right" width="150" height="70" :src="valid_img_url" @click="getValidImgUrl"></u-image>
                </u-form-item>
                <u-form-item label-position="top">
                    <u-input v-model="validMobileForm.sms_code" placeholder="请输入短信验证码" maxlength="6" clearable />
                    <u-button slot="right" type="error" size="mini" @click="getCode">{{codeTips}}</u-button>
                    <u-verification-code seconds="60" ref="uCode" @change="codeChange"></u-verification-code>
                </u-form-item>
            </u-form>
            <u-button :disabled="val_disabled_mobile" class="u-m-20" type="error" shape="circle" @click="submitValMobileForm">提交校验</u-button>
        </view>
        <view class="change-password" v-show="step === 2">
            <u-form :model="changePayMentPasswordForm" ref="changePayMentPasswordForm">
                <u-form-item label-position="top">
                    <u-input v-model="changePayMentPasswordForm.password" placeholder="请输入6位数字密码" type="password"
                        maxlength="6" clearable />
                </u-form-item>
                <u-form-item label-position="top">
                    <u-input v-model="changePayMentPasswordForm.rep_password" placeholder="请确认密码" type="password" maxlength="6"
                        clearable />
                </u-form-item>
            </u-form>
            <u-button :disabled="val_disabled_password" class="u-m-20" type="error" shape="circle" @click="submitChangeForm">修改密码</u-button>
        </view>
        <!-- 腾讯天御验证码-小程序 -->
        <!-- #ifdef MP-WEIXIN -->
        <t-captcha
            id="captcha"
            :app-id="validator.tencent.mini_captcha_app_id"
            @verify="handlerVerify"
            @ready="handlerReady"
            @close="handlerClose"
            @error="handlerError" />
        <!-- #endif -->
    </view>
</template>

<script>
    import * as API_Common from '@/api/common'
    import * as API_Safe from '@/api/safe'
    import * as API_Deposit from '@/api/deposit'
    import Cache, { Keys } from '@/utils/cache'
    import { Foundation, RegExp } from '@/app-utils/index'
    export default {
        data() {
            return {
                uuid: Cache.getItem('uuid'),
                step: 1,
                codeTips: '获取验证码',
                validMobileForm: {
                    scene: 'SET_PAY_PWD',
                    mobile: '',
                    uuid: '',
                    captcha: '',
                    sms_code: ''
                },
                valid_img_url: '',
                changePayMentPasswordForm: {
                    password: '',
                    rep_password: ''
                },
                // 验证类型
                validator: {}
            };
        },
        onLoad() {
            this.GET_MemberAccount()
            this.getValidator()
        },
        computed: {
            /** 校验手机号 按钮是否禁用 */
            val_disabled_mobile() {
                const { captcha, sms_code } = this.validMobileForm
                if (this.validator.validator_type === 'IMAGE') {
                    return !(captcha && sms_code)
                }
                return !sms_code

            },
            /** 修改密码 按钮是否禁用 */
            val_disabled_password() {
                const { password, rep_password } = this.changePayMentPasswordForm
                return !(password && rep_password)
            }
        },
        methods: {
            /** 获取验证码方式 */
            getValidator(){
                API_Common.getValidator().then(res => {
                    this.validator = res
                })
            },
            /** 获取图片验证码URL */
            getValidImgUrl() {
                this.valid_img_url = API_Common.getValidateCodeUrl(this.validMobileForm.uuid, 'SET_PAY_PWD')
            },
            /** 获取账户信息 **/
            GET_MemberAccount() {
                API_Deposit.getMemberAccount().then(response =>{
					const mobile = Foundation.secrecyMobile(response.mobile);
                    this.validMobileForm.mobile = mobile
                    this.validMobileForm.uuid = response.uuid
                    this.getValidImgUrl()
                }).catch(error => {
                    if (error.data.code === '153') {
                        uni.showModal({
                            title: '提示',
                            content: '未绑定手机号，去绑定？',
                            cancelText: '取消',
                            confirmColor: '#FA3534',
                            confirmText: '去绑定',
                            success(res) {
                                if (res.confirm) {
                                     uni.redirectTo({url:"/pages/auth/bind-phone"})
                                } else {
                                    uni.navigateBack({
                                        delta:1
                                    })
                                }
                            }
                        })
                    }
                })
            },
            /** 验证码发送 */
            sendMobileSmsForPayment() {
                const {
                    captcha,
                    scene,
                    uuid,
                    randstr,
                    ticket
                } = this.validMobileForm
                const params = {
                    scene,
                    uuid,
                }
                const validator_type = this.validator.validator_type

                if (validator_type === 'IMAGE' && !captcha) {
                    this.$u.toast('请填写图片验证码')
                    return
                }
                if (validator_type === 'IMAGE') {
                    params.captcha = captcha
                } else if (validator_type === 'TENCENT') {
                    params.randstr = randstr
                    params.ticket = ticket
                }
                API_Safe.sendMobileSmsForPayment(params).then(res => {
                    this.$u.toast('验证码已发送')
                    this.$refs.uCode.start()
                });
            },
            /** 获取验证码 */
            getCode() {
                if (this.$refs.uCode.canGetCode) {
                    const validator_type = this.validator.validator_type
                    //如果是图片验证码
                    if (validator_type === 'IMAGE') {
                        this.sendMobileSmsForPayment()
                    } else if(validator_type === 'TENCENT') {
                        //如果是腾讯验证码
                        this.handlerTenCent(this.sendMsgCallback)
                    }
                } else {
                    this.$u.toast('倒计时结束后再发送')
                }
            },
            handlerTenCent(callback){
                // #ifdef H5
                try {
                    const captcha = new TencentCaptcha(this.validator.tencent.captcha_app_id, callback, {})
                    // 调用方法，显示验证码
                    captcha.show()
                } catch (error) {
                // 加载异常，调用验证码js加载错误处理函数
                this.loadErrorCallback()
                }
                // #endif

                // #ifdef MP-WEIXIN
                this.selectComponent('#captcha').show()
                // #endif
            },
            /** 图片滑动验证回调 */
            sendMsgCallback(res) {
                if (res.ret === 0) {
                    this.validMobileForm.randstr = res.randstr
                    this.validMobileForm.ticket = res.ticket
                    this.sendMobileSmsForPayment()
                }
            },
            codeChange(text) {
                this.codeTips = text
            },
            /** 手机验证 */
            submitValMobileForm() {
                const { sms_code } = this.validMobileForm
                if (!sms_code) {
                    this.$u.toast('请填写短信验证码')
                    return
                }
                API_Safe.validChangePaymentPasswordSms(sms_code).then(() => {
                    this.step = 2
                    this.getValidImgUrl()
                }).catch(this.getValidImgUrl)
            },
            /** 修改密码 */
            submitChangeForm() {
                const { password, rep_password } = this.changePayMentPasswordForm
                const { uuid } = this.validMobileForm
                const params = {
                    uuid,
                    password
                }
                if (!/^\d{6}$/g.test(password)) {
                    this.$u.toast('密码格式不正确')
                    return false
                }
                if (password !== rep_password) {
                    this.$u.toast('两次密码输入不一致')
                    return false
                }
                API_Safe.bindPaymentPassword(params).then(() => {
                    this.$u.toast('密码修改成功')
                    uni.navigateBack()
                }).catch(this.getValidImgUrl)
            }
        }
    }
</script>

<style lang="scss" scoped>
    .change-paymentpassword-container {

        .valid-mobile,
        .change-password {
            background-color: #FFFFFF;
            margin: 30rpx;
            border-radius: 20rpx;
            padding: 20rpx 40rpx;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
        }
    }
</style>
