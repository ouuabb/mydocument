<template>
  <view class="account-security">
    <u-cell-group>
      <u-cell-item title="账户密码" value="修改" @click="handlePassword"></u-cell-item>
      <u-cell-item title="手机号码" value="修改" @click="handleMobile"></u-cell-item>
      <u-cell-item title="邮箱验证" :value="hasEmail ? '修改' : '绑定'" @click="handleEmail"></u-cell-item>
      <u-cell-item title="支付密码" :value="hasPassword ? '修改' : '设置'" @click="handlePaymentPassword"></u-cell-item>
      <u-cell-item title="账号注销" @click="handleLogout"></u-cell-item>
      <!-- <u-cell-item title="第三方登录" value="查看" @click="handleBinding"></u-cell-item> -->
    </u-cell-group>
  </view>
</template>

<script>
import * as API_Deposit from '@/api/deposit'
import Cache from '@/utils/cache'

export default {
  data() {
    return {
      hasPassword: false,
      hasEmail: false
    }
  },
  mounted() {
    this.hasEmail = !!(Cache.user() || {}).email
    API_Deposit.checkPassword().then(response => {
      this.hasPassword = response
    })
  },
  methods: {
    //账号注销
    handleLogout() {
      uni.navigateTo({
        url: '/mine-module/close-account'
      })
    },
    //账号密码
    handlePassword() {
      uni.navigateTo({
        url: '/mine-module/change-password'
      })
    },
    //手机号码
    handleMobile() {
      uni.navigateTo({
        url: '/mine-module/change-mobile'
      })
    },
    //支付密码
    handlePaymentPassword() {
      uni.navigateTo({
        url: '/mine-module/change-paymentpassword'
      })
    },
    //邮箱
    handleEmail() {
      uni.navigateTo({
        url: '/mine-module/change-email'
      })
    },
    //第三方登录
    handleBinding() {
      uni.navigateTo({
        url: '/mine-module/account-binding'
      })
    }
  }
}
</script>

<style lang="scss" scoped>

</style>
