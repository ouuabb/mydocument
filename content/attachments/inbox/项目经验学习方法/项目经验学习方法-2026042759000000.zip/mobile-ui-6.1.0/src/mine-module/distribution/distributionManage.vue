<template>
	<view class="distribution-manage" catchtouchmove="true">
        <view>
            <view class="user-content">
                <view class="info">
                    <view class="left">
                        <image :src="distributionUserInfo.avatar" alt="" class="user-img" v-if="distributionUserInfo.avatar"/>
                        <image src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-noface.jpg" alt="" class="user-img" v-else/>
                        <text>{{distributionUserInfo.name}} </text>
                    </view>
                    <view class="right">
                        <view class="detail-btn" @click="handleDetail">明细</view>
                        <u-icon :name="showPrice ? 'eye-fill' : 'eye-off'" size="50" @click="showPrice = !showPrice" />
                    </view>
                </view>
                <view class="income">
                    <view class="item">
                        <view>总收益</view>
                        <view class="price">{{showPrice ? distributionUserInfo.total_commission : '****'}}</view>
                    </view>
                    <view class="item">
                        <view>待入账佣金</view>
                        <view class="price">{{showPrice ? distributionUserInfo.wait_commission : '****'}}</view>
                    </view>
                </view>
            </view>
            <scroll-view
                scroll-y
                class="message-content"
                style="height: calc(100vh - 600rpx);"
                @scrolltolower="scrollToLower">
                <view
                    class="message-item"
                    v-for="item in messageList"
                    :key="item.id">
                    <view class="message">
                        <view class="message-img">
                            <image v-if="item.oper_avatar" :src="item.oper_avatar" alt=""  class="img-item"/>
                            <image v-else src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-noface.jpg" alt="" class="user-img img-item"/>
                        </view>
                        <text>{{item.content}}</text>
                    </view>
                    <view>{{item.create_time | unixToDate()}}</view>
                </view>
            </scroll-view>
        </view>

        <view class="menu-content">
            <view
                class="menu-item"
                v-for="item in menuList"
                :key="item.icon"
                @click="menuNavigateTo(item)">
                <view class="menu-img">
                    <image class="img-item" :src="require(`./images/${item.icon}.png`)" alt="" />
                </view>
                <view class="menu-text">{{item.title}}</view>
            </view>
        </view>
        <u-popup
            mode="center"
            border-radius="20"
            length="90%"
            :maskCloseAble="false"
            v-model="showDialog">
            <view class="dialog-content">
                <image src="./images/record2.png"  alt=""/>
                <view class="title">待完善信息</view>
                <view class="text">请前往完善您的信息</view>
                <view class="doing-btn" @click="toAddUser">去完善</view>
                <view class="close-btn" @click="toBackMine">返回</view>
            </view>
		</u-popup>
	</view>
</template>

<script>
    import * as API_Distribution from '@/api/distribution'

	export default {
        data() {
        	return {
                menuList: [
                    { title: '我的团队', icon: 'team', url: '/mine-module/distribution/distributionTeam' },
                    { title: '佣金明细', icon: 'wallet', url: '/mine-module/distribution/brokerageDetail' },
                    { title: '分销订单', icon: 'order', url: '/mine-module/distribution/distributionOrder' },
                    { title: '推广商品', icon: 'package', url: '/mine-module/distribution/distributionGoods' },
                    // { title: '我的资料', icon: 'mine' },
                    // { title: '分销排行', icon: 'ranking' },
                    // { title: '邀请海报', icon: 'posters' },
                    // { title: '分享记录', icon: 'record' }
                ],
                showDialog: false,
                showPrice: true, // 显示金额
                distributionUserInfo: {}, // 分销商信息
                messageList: [], // 动态消息数据
                messageParams: {
                    page_no: 1,
                    page_size: 10,
                    data_total: 0
                }
        	};
        },
        onShow() {
            this.messageList = []
            this.messageParams.page_no = 1
            this.checkDistribution()
        },
		methods: {
            /** menu跳转 */
            menuNavigateTo(item) {
                uni.navigateTo({
                    url: item.url
                })
            },
            /** 查看明细 */
            handleDetail() {
                uni.navigateTo({
                    url: '/mine-module/distribution/brokerageDetail'
                })
            },
            /** 检查是否为分销商 */
            checkDistribution() {
                API_Distribution.checkDistribution().then(res => {
                    if (res) {
                        this.getDistributionUserInfo()
                        this.getDistributionMessage()
                    } else {
                        this.showDialog = true
                    }
                })
            },
            /** 消息分页 */
            scrollToLower() {
                if (Number(this.messageParams.data_total) === this.messageList.length) {
                    return
                }
                this.messageParams.page_no++
                this.getDistributionMessage()
            },
            /** 获取分销动态信息 */
            getDistributionMessage() {
                API_Distribution.getDistributionMessage(this.messageParams).then(res => {
                    this.messageList = this.messageList.concat(res.data)
                    this.messageParams.data_total = res.data_total
                })
            },

            /** 获取分销商数据 */
            getDistributionUserInfo() {
                API_Distribution.getDistributionUserInfo().then(res => {
                    if (res) {
                        this.distributionUserInfo = res
                    }
                })
            },
            /** 返回个人中心 */
            toBackMine() {
                uni.switchTab({
                    url: '/pages/tabs/mine/mine'
                })
            },

            /** 跳转完善信息 */
            toAddUser() {
                this.showDialog = false
                uni.navigateTo({
                    url: '/mine-module/distribution/addDistributionUser'
                })
            }


		}
	}
</script>

<style lang="scss" scoped>
.distribution-manage {
    min-height: 100%;
    padding: 30rpx;
    box-sizing: border-box;
    background: linear-gradient(to bottom, rgb(67, 31, 152), rgb(175, 205, 232));
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    .dialog-content {
        background: #fff;
        padding: 40rpx;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        color: #999;
        align-items: center;
        img {
            width: 180rpx;
        }
        .title {
            font-weight: 500;
            font-size: 34rpx;
            color: #333;
            margin: 40rpx 0;
        }
        .close-btn {
            color: rgb(148, 97, 255);
            margin-top: 40rpx;

        }
        .doing-btn {
            width: 100%;
            height: 70rpx;
            border-radius: 40rpx;
            text-align: center;
            color: #fff;
            font-size: 30rpx;
            line-height: 70rpx;
            margin: 40rpx 0 0;
            box-shadow: 0 10rpx 12rpx 0 rgba(0, 0, 0, .1);
            background: linear-gradient(to right, rgb(77, 55, 255), rgb(148, 97, 255));
        }
    }
    .menu-content {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        height: 150rpx;
        .menu-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            // margin: 0 0rpx 60rpx;
            color: #fff;
            font-size: 24rpx;
            width: calc(100% / 4);
            .menu-text {
                text-align: center;
            }
            .menu-img {
                width: 80rpx;
                height: 80rpx;
                background: #fff;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-bottom: 20rpx;
                .img-item {
                    width: 46rpx;
                    height: 46rpx;
                }
            }
        }
    }

    .message-content {
        padding: 30rpx 0;
        box-sizing: border-box;
        .message-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: #fff;
            font-size: 26rpx;
            margin-bottom: 30rpx;

            .message {
                display: flex;
                align-items: center;
                background: rgba(102, 110, 155, .3);
                border-radius: 20rpx;
                padding: 10rpx 20rpx;
                max-width: 60%;
                font-size: 12px;
	            box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
                .message-img {
                    .img-item {
                        border-radius: 50%;
                        width: 60rpx;
                        height: 60rpx;
                        margin-right: 10rpx;
                    }
                }
            }
        }
    }
    .user-content {
        width: 100%;
        height: 320rpx;
        border-radius: 20rpx;
        color: #fff;
        background: linear-gradient(to left, rgb(107, 93, 208), rgb(85, 69, 193));
        .income {
            display: flex;
            padding: 20rpx 40rpx;
            box-sizing: border-box;
            .item {
                font-size: 24rpx;
                width: 50%;
                .price {
                    font-size: 38rpx;
                    font-weight: 500;
                    margin-top: 10rpx;
                }
            }
        }
        .info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 40rpx;
            box-sizing: border-box;
            border-bottom: 1px solid rgba(255,255,255, .2);
            .left {
                display: flex;
                align-items: center;
            }
            .right {
                display: flex;
                flex-direction: column;
                align-items: center;
            }
            .detail-btn {
                border: 1px solid #fff;
                padding: 0 20rpx;
                font-size: 12px;
                box-sizing: border-box;
                border-radius: 20rpx;
                margin-bottom: 20rpx;
            }
            .user-img {
                width: 80rpx;
                height: 80rpx;
                background: #fff;
                margin-right: 30rpx;
                border-radius: 50%;
            }
        }
    }
}
</style>
