<template>
  <view class="change-mobile-container">
    <u-gap height="40" bg-color="#FFFFFF"></u-gap>
    <view class="valid-mobile" v-show="step === 1">
      <u-form :model="validMobileForm" ref="validMobileForm">
        <u-form-item label-position="top">
          <u-input
            v-model="bindMobile"
            disabled
            label="已验证手机"
            placeholder="请填写手机号"
            maxlength="11"
            clearable
          />
        </u-form-item>
        <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
          <u-input v-model="validMobileForm.img_code" placeholder="请填写图片验证码" maxlength="4" clearable/>
          <u-image slot="right" width="150" height="70" :src="valid_img_url" @click="getValidImgUrl"></u-image>
        </u-form-item>
        <u-form-item label-position="top">
          <u-input v-model="validMobileForm.sms_code" placeholder="请填写短信验证码" maxlength="6" clearable/>
          <u-button slot="right" type="error" size="mini" @click="sendValidMobileSms">{{ validMobilecodeTips }}
          </u-button>
          <u-verification-code seconds="60" ref="vCode" @change="validEmailCode"></u-verification-code>
        </u-form-item>
      </u-form>
      <u-button :disabled="val_disabled_mobile" class="u-m-20" type="error" shape="circle" @click="submitValMobileForm">
        提交校验
      </u-button>
    </view>
    <view class="change-mobile" v-show="step === 2">
      <u-form :model="changeMobileForm" ref="changeMobileForm">
        <u-form-item label-position="top">
          <view class="u-flex">
            <u-input v-model="changeMobileForm.email" placeholder="请填写邮箱地址" clearable/>
          </view>
        </u-form-item>
        <u-form-item label-position="top" v-if="validator.validator_type === 'IMAGE'">
          <u-input v-model="changeMobileForm.img_code" placeholder="请填写图片验证码" maxlength="4" clearable/>
          <u-image slot="right" width="150" height="70" :src="valid_img_url" @click="getValidImgUrl"></u-image>
        </u-form-item>
        <u-form-item label-position="top">
          <u-input v-model="changeMobileForm.email_code" placeholder="请填写邮箱验证码" maxlength="6" clearable/>
          <u-button slot="right" type="error" size="mini" @click="sendChangeMobileSms">{{ changeEmailCodeTips }}</u-button>
          <u-verification-code seconds="60" ref="uCode" @change="changeEmailCode"></u-verification-code>
        </u-form-item>
      </u-form>
      <u-button :disabled="val_disabled_change" class="u-m-20" type="error" shape="circle" @click="submitChangeForm">
        确认修改
      </u-button>
    </view>
    <view class="change-success u-flex" v-show="step === 3">
      <image class="icon-success" src="https://shoptnt-statics.oss-cn-beijing.aliyuncs.com/demo/uniapp/images/member/icon-success.png"></image>
      <view class="success-title">
        <text>您的邮箱地址已成功设为：</text>
        <text style="color: green">{{ changeMobileForm.email }}</text>
        <u-button type="error" size="mini" @click="handleBack" class="back-btn">返回</u-button>
      </view>
    </view>
    <!-- 腾讯天御验证码-小程序 -->
    <!-- #ifdef MP-WEIXIN -->
    <t-captcha
      id="captcha"
      :app-id="validator.tencent.mini_captcha_app_id"
      @verify="handlerVerify"
      @ready="handlerReady"
      @close="handlerClose"
      @error="handlerError"/>
    <!-- #endif -->
  </view>
</template>

<script>
import * as API_Common from '@/api/common'
import * as API_Safe from '@/api/safe'
import areaSelect from '@/components/areaSelect/areaSelect'
import Cache, { Keys } from '@/utils/cache'
import { Foundation, RegExp } from '@/app-utils'

export default {
  data() {
    return {
      uuid: Cache.getItem('uuid'),
      step: 1,
      validMobilecodeTips: '获取验证码',
      changeEmailCodeTips: '获取验证码',
      validMobileForm: {
        img_code: '',
        sms_code: ''
      },
      valid_img_url: '',
      changeMobileForm: {
        email: '',
        img_code: '',
        email_code: ''
      },
      // 验证类型
      validator: {}
    }
  },
  components: { areaSelect },
  onLoad() {
    this.$nextTick(this.getValidImgUrl)
    const mobile = Foundation.secrecyMobile(Cache.getItem('user').mobile)
    if (mobile == 'null') {
      this.step = 2
    }
    this.getValidator()
  },
  computed: {
    bindMobile() {
      const mobile = Foundation.secrecyMobile(Cache.getItem('user').mobile)
      return mobile == 'null' ? '' : mobile
    },
    /** 校验手机号 按钮是否禁用 */
    val_disabled_mobile() {
      const { img_code, sms_code } = this.validMobileForm
      if (this.validator.validator_type === 'IMAGE') {
        return !(img_code && sms_code)
      }
      return !sms_code
    },
    /** 修改提交 按钮是否禁用 */
    val_disabled_change() {
      const { email, img_code, email_code } = this.changeMobileForm
      if (this.validator.validator_type === 'IMAGE') {
        return !(email && img_code && email_code)
      }
      return !(email && email_code)
    }
  },
  methods: {
    /** 获取验证码方式 */
    getValidator() {
      API_Common.getValidator().then(res => {
        this.validator = res
      })
    },
    /** 获取图片验证码URL */
    getValidImgUrl() {
      this.valid_img_url = API_Common.getValidateCodeUrl(this.uuid, this.step === 1 ? 'VALIDATE_MOBILE' : 'BIND_EMAIL')
    },
    /** 发送验证码  */
    sendMobileSms() {
      const { uuid } = this
      const { img_code, randstr, ticket } = this.validMobileForm
      const validator_type = this.validator.validator_type

      if (validator_type === 'IMAGE' && !img_code) {
        this.$u.toast('请填写图片验证码')
        return
      }
      const params = { uuid, scene: 'VALIDATE_MOBILE' }
      if (validator_type === 'IMAGE') {
        params.captcha = img_code
      } else if (validator_type === 'TENCENT') {
        params.randstr = randstr
        params.ticket = ticket
      }
      API_Safe.sendMobileSms(params).then(res => {
        this.$u.toast('验证码已发送')
        this.$refs.vCode.start()
      }).catch(this.getValidImgUrl)
    },
    /** 发送手机验证码 */
    sendValidMobileSms() {
      if (this.$refs.vCode.canGetCode) {
        const validator_type = this.validator.validator_type
        //如果是图片验证码
        if (validator_type === 'IMAGE') {
          this.sendMobileSms()
        } else if (validator_type === 'TENCENT') {
          //如果是腾讯验证码
          this.handlerTenCent(this.sendMsgCallback)
        }
      } else {
        this.$u.toast('倒计时结束后再发送')
      }
    },
    handlerTenCent(callback) {
      // #ifdef H5
      try {
        const captcha = new TencentCaptcha(this.validator.tencent.captcha_app_id, callback, {})
        // 调用方法，显示验证码
        captcha.show()
      } catch (error) {
        // 加载异常，调用验证码js加载错误处理函数
        this.loadErrorCallback()
      }
      // #endif

      // #ifdef MP-WEIXIN
      this.selectComponent('#captcha').show()
      // #endif
    },
    /** 图片滑动验证回调 */
    sendMsgCallback(res) {
      if (res.ret === 0) {
        this.validMobileForm.randstr = res.randstr
        this.validMobileForm.ticket = res.ticket
        this.sendMobileSms()
      }
    },
    /**手机号绑定验证回调 */
    sendBindCallback(res) {
      if (res.ret === 0) {
        this.changeMobileForm.randstr = res.randstr
        this.changeMobileForm.ticket = res.ticket
        this.sendBindEmailCode()
      }
    },
    /** 修改邮箱 发送验证码 */
    sendChangeMobileSms() {
      const { email } = this.changeMobileForm
      if (!RegExp.email.test(email)) {
        return this.$u.toast('邮箱地址格式有误')
      }
      if (this.$refs.uCode.canGetCode) {
        const validator_type = this.validator.validator_type
        //如果是图片验证码
        if (validator_type === 'IMAGE') {
          this.sendBindEmailCode()
        } else if (validator_type === 'TENCENT') {
          //如果是腾讯验证码
          this.handlerTenCent(this.sendBindCallback)
        }

      } else {
        this.$u.toast('倒计时结束后再发送')
      }
    },
    /** 修邮箱验证码发送 */
    sendBindEmailCode() {
      const { uuid } = this
      const { email, img_code, randstr, ticket } = this.changeMobileForm
      const validator_type = this.validator.validator_type

      if (validator_type === 'IMAGE' && !img_code) {
        this.$u.toast('请填写图片验证码')
        return
      }
      const params = { uuid, email, scene: 'BIND_EMAIL' }
      if (validator_type === 'IMAGE') {
        params.captcha = img_code
      } else if (validator_type === 'TENCENT') {
        params.randstr = randstr
        params.ticket = ticket
      }
      API_Safe.sendBindEmailCode(params).then(() => {
        this.$u.toast('验证码已发送')
        /** 通知验证码组件内部开始倒计时 */
        this.$refs.uCode.start()
      }).catch(this.getValidImgUrl)
    },
    validEmailCode(text) {
      this.validMobilecodeTips = text
    },
    changeEmailCode(text) {
      this.changeEmailCodeTips = text
    },
    /** 手机验证 */
    submitValMobileForm() {
      const { sms_code } = this.validMobileForm
      API_Safe.validChangeMobileSms(sms_code).then(() => {
        this.step = 2
        this.getValidImgUrl()
      }).catch(this.getValidImgUrl)
    },
    /** 修改邮箱 */
    submitChangeForm() {
      const { email, email_code } = this.changeMobileForm
      if (!RegExp.email.test(email)) {
        return this.$u.toast('邮箱地址格式有误！')
      }
      API_Safe.bindEmail(email, email_code).then(() => {
        this.$u.toast('更换成功')
        this.step = 3
        this.changeMobileForm.email = mobile
        var user = Cache.getItem(Keys.user)
        user.email = email
        Cache.setItem(Keys.user, user)
      }).catch(this.getValidImgUrl)
    },
    handleBack() {
      uni.reLaunch({ url: '/pages/tabs/home/home' })
    }
  }
}
</script>

<style lang="scss" scoped>
.change-mobile-container {
  .valid-mobile,
  .change-mobile {
    background-color: #ffffff;
    margin: 30rpx;
    border-radius: 20rpx;
    padding: 20rpx 40rpx;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
    ::v-deep.u-label {
      flex: 0 0 180rpx !important;
    }
  }
  .change-success {
    padding-top: 100rpx;
    width: 100%;
    justify-content: center;
    padding-bottom: 58rpx;
    .icon-success {
      width: 100rpx;
      height: 100rpx;
      margin-right: 30rpx;
    }
    .success-title {
      display: flex;
      flex-direction: column;
      gap: 10rpx;
      font-size: 32rpx;
      color: #333;
    }
    .back-btn {
      margin: 0;
      margin-top: 16rpx;
      width: 180rpx;
      height: 60rpx;
    }
  }
}
</style>
